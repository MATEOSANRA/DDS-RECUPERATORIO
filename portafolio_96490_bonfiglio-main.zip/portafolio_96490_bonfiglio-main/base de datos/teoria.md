# Taller de Bases de Datos

## Estructura de consulta SQL para generar una tabla
*CREATE TABLE* "NombreTable ("Atributo1" *TIPOATRIBUTO1*, "Atributo2", *TIPOATRIBUTO2 not NULL*, *PRIMERY KEY* ("Atributo1 *AUTOINCREMENT*))

Se crea una tabla con las columnas "Atributo1" y "Atributo2" de TIPOATRIBUTO1 y TIPOATRIBUTO2 respectivamente, que tiene como clave principal "Atributo1" y el mismo sera autogestionado por el motor (se incrementará como si fuera un id)

### Ejemplo

*CREATE TABLE* "CLASIFICACIONES" (
    "IdClasificaciones" *INTEGER*
    ,"NombreClasificacion" *VARCHAR*(100) *not NULL*
    ,"Descripcion" *VARCHAR*(200)
    ,*PRIMARY KEY* ("IdClasificaciones" *AUTOINCREMENT*)
)

## Para insertar valores en una tabla

*INSERT INTO* "NombreTabla" ("Attr1", "Attr2", "Attr3") *VALUES* {valorAttr1, "valorAttr2", "valorAttr3"}

Se inserta una fila (tupla) en la tabla "NombreTabla" con los valores valorAttr1, "valorAttr2", "valorAttr3" para los atributos "Attr1", "Attr2", "Attr3" suponindo que cada valor pertenece al tipo indicado para el atributo al que corresponden.

## Para buscar un dato
*SELECT* X.Atributo1, Y.Atributo2 *as* "Nuevo nombre Attr1", "NuevoTituloAttr2"
*FROM* NombreTablaX X *JOIN* NombreTablaY Y *ON* X.AttributoComun = Y.AtributoComun
*WHERE* Y.AtributoCondicion = "ValorCondicion"

Realiza un JOIN (une segun un atributo) las tablas NombreTablaX (renombrada como X) y NombreTablaY (renombrada como Y) y de aquellas tuplas que tengan el atributo original de la tabla Y AtributoCondicion con el valor "ValorCondicion" y se queda solo con las columnas Atributo1 (original de la tabla Y) y Atributo2 (original de la tabla Y)

## En el WHERE se pueden incluir varios condicionales

WHERE Pelicula.Titulo == "EL caballero de la noche"
AND time(Pelicula.HoraInicio) < time ('17:00')

Devolvería todas las funciones de El caballero de la noche que son anteriores a las 17hs

## ORDER BY

ORDER BY F.Fecha asc, F.HoraInicio DESC

Ordenara por fecha de forma ascendente y por hora de forma descendente (primero fecha y luego en cada fecha ordenará por hora)

## Extras
Para borrar filas usamos DELETE tal como usamos INSERT INTO
Para actualizar filas usamos UPDATE tal como usamos INSERT INTO