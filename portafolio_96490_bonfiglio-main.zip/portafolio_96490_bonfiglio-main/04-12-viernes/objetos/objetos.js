// Hay tres formas de crear objetos:

// Objetos literales
let objeto = { nombre: 'Franco', apellido: 'Bonfiglio', edad: 20 };

// acceso:
console.log(objeto.nombre);
objeto.edad++;

// Funcion constructora
// Depercated

// Bloque class
class NombreClase {
    constructor (att1, att2, att3) {
        this.att1 = att1;
        this.att2 = att2;
        this.att3 = att3;
    }

    metodo1() {
        console.log('Este es el metodo 1. El valor del atributo 1 es: ', this.att1);
    }
    
    toString() {
        return `- Attr 1: ${this.att1} | Attr 2: ${this.att2} | Attr 3: ${this.att3} -`;
    }
}

let instancia = new NombreClase('Valor 1', 'Valor 2', 'Valor 3');

console.log(instancia.toString());