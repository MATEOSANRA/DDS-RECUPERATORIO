const getFiltro = async () => {
    const filtro = document.getElementById('ddlCiudad');

    if (filtro) {
        const res = await fetch(`http://localhost:3000/api/hoteles/${filtro.value}`);
        console.log(filtro.value)
        const resJSON = await res.json();

        if (resJSON.ok) {
            mostrarDatos(resJSON.datos);
        }
        else {
            console.log(`${res.status}: ${resJSON.mensaje}.`);
        }
    }
}


const mostrarDatos = (datos) => {
    const divTabla = document.getElementById('divHoteles');

    if (divTabla) {
        let contenido = `
            <table class="table">
                <thead>
                    <tr>
                        <td>ID</td>
                        <td>Nombre</td>
                        <td>Ciudad</td>
                        <td>Plazas</td>
                    </tr>
                </thead>
                <tbody>
        `;
        datos.forEach(hotel => {
            contenido += `
                    <tr>
                        <td>${hotel.id}</td>
                        <td>${hotel.nombre}</td>
                        <td>${hotel.ciudad}</td>
                        <td>${hotel.plazas}</td>
                    </tr>
            `;
        });
        contenido += `
                </tbody>
            <table>
        `;

        divTabla.innerHTML = contenido;
    }
}

const btnBuscar = document.getElementById('btnCargarHoteles');

if (btnBuscar) {
    btnBuscar.addEventListener('click', getFiltro);
}