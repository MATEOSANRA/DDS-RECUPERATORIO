// Express es una libreria que permite facilitar el trabajo con peticiones http
import express from 'express';

const main = () => {
    // primero creamos una app express
    const app = express();

    let contador = 0;
    let numeros = new Array(10).fill(0).map(_ => { return  Math.floor(Math.random() * 100) });

    // la app tiene un metodo por cada uno de los posibles metodos de http que nos permite asignar a un par metodo | direccion
    // un comportamiento

    /*
        Aca programamos los endpoints de la app
    */
   
    // GET "/"
    app.get('/', (request, response) => {
        response.send(`Hola people: ${contador++}`);
        response.end();
    })

    // GET /numeros
    app.get('/numero', (request, response) =>{
        response.send(numeros);
        response.end();
    })

    // GET /numero:numero | consulta si existe el numero en el arreglo
    app.get('/numero/:buscado', (request, response) => {
        const buscado = parseInt(request.params.buscado);
        response.write(`Se busca el numero ${buscado}\n`)
        response.write(numeros.find(x => x === buscado) ? 'Se existe el numero.' : 'No existe el numero.');
        response.send();
        response.end();
    })

    // POST /numeros:nuevo | agregar un numero al arreglo
    app.post('/numeros/:nuevo', (request, response) => {
        const n = parseInt(request.params.nuevo);
        numeros.push(n);
        response.send(numeros);
        response.end();
    })

    app.listen(8081);
}

main();