// importamos el modulo http, similar a 
import http from 'http'

// Creamos un server http que es capaz de escuchar y responder peticiones http response es lo que envia el server

/*
    Lo ideal seria decir, dada una request especifica (petición especifica) se responda con una response especifica
    Aqui podriamos usar condicionales
*/
let i = 0;
const server = http.createServer((request, response) => {
    // response.end() envia una response
    response.end('Hola mundo', i++);
});

const main = function() {
    // listen hace que el servidor http creado escuche peticiones en un puerto e ip definido, en este caso 8080 
    // y localhost respectivamente
    server.listen(8080, 'localhost');
};

main();