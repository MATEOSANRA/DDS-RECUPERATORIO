let arreglo = [];
let suma = 0;
let mayor, menor;
let cantidadMayoresCeroConCinco = 0;

for (let i = 0; i < 100; i++) {
    arreglo.push(Math.random());
}

for (let i = 0; i < arreglo.length; i++) {
    suma += arreglo[i];

    if (mayor === undefined || arreglo[i] > mayor) {
        mayor = arreglo[i];
    }
    if (menor === undefined || arreglo[i] < menor) {
        menor = arreglo[i];
    }
    if (arreglo[i] > 0.5) {
        cantidadMayoresCeroConCinco++;
    }
}

console.log('Promedio de valores: ', suma > 0 ? suma / 100 : 0);
console.log('Mayor valor del arreglo: ', typeof(mayor) !== undefined ? mayor : 0);
console.log('Menor valor del arreglo: ', typeof(menor) !== undefined ? menor : 0);
console.log('Cantidad de elementos mayores a 0,5 en el arreglo: ', cantidadMayoresCeroConCinco)