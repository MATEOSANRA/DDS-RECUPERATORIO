/*
    Variables y estructuras secuenciales
*/

// Inicializo ina variable
let a;
console.log(typeof(a));  // como la variable no está asignada, el tipo es undefined

a = 3.56;
console.log(typeof(a));  // number: tipo de dato que representa un numero de coma flotante de hasta 8 bytes

let s = 'Franco';
console.log(typeof(s));  // string: cadena de caracteres

const PI = 3.14159;
console.log('Pi:', PI);  // valor constante, no puede variar a lo largo de la ejecución del programa (inmutable)

/*
    Comentario en bloque
    Los comentarios en JavaScript funcionan igualque en C#
*/

console.log(s[0]);  // Para acceder a un elemento de un tipo de dato compuesto utilizamos indices

// Podemos conocer la longitud de una variable de un tipo de dato compuesto a travez de la PROPIEDAD lenght
console.log(s.length);

let plantilla = `Hola ${s}. ¿Como estas?`;  // Similar a los format strings o fstrings de python
console.log(plantilla);
