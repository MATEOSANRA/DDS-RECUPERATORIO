/*
    Tipos de datos compuestos [Arreglos]
*/

let v = [];
v.push(1, 2, 3);  // push es similar a append de python. en este caso me permite agregar de a varios elementos
console.log(v);

console.log('El segundo elemento del arreglo es: ', v[1]);

console.log('El ultimo elemento del arreglo era: ', v.pop());  // pop retorna el ultimo elmento del arreglo y lo elimina del mismo
console.log(v);

v.unshift(-1, 0);  // unshift agrega un elemento (o conjunto de elementos) al principio del arreglo
console.log(v);

console.log('EL primer elemento del arreglo era: ', v.shift()); // shift retorna el primer elemento del arreglo y lo elimina del mismo
console.log(v);