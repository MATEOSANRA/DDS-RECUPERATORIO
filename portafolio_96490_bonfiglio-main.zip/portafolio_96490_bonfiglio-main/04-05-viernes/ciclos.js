/*
    Estructuras itereativas
*/

let i = 5
while (i > 0) {
    console.log('While: ', i);
    i--;
}

for (let j = 0; j < 5; j++)
{
    if (j === 2) {
        continue;
    } else if (j === 4) {
        console.log('For: iteracion final.')
        break;
    }
    console.log('For: ', j);
}

let k = 0
do {
    console.log('Do while: ', k)
} while (k !== 0)