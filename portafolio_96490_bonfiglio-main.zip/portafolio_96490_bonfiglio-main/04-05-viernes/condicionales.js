/*
    Estructuras condicionales
*/

// if else

let deuda = 6_000;
if (deuda > 5_000) {
    console.log('Su deuda es de mayor a $5000, si no regulariza se tomaran medidas judiciales.')
}
else {
    console.log('Felicitaciones, su deuda es menor a $5000, puede seguir utilizando el servicio sin problemas')
}

if (deuda === 5_000) {   // el operador === es la igualdad estricta de valor y tipo de dato, == solo compara el valor 10 == '10' => true
    console.log('Deuda igual a $5000')
}

// switch

let tipo = 3;
switch (tipo) {
    case 1: 
        console.log('Tipo Maestro');
        break;
    case 2: 
        console.log('Tipo Campeon');
        break;
    case 3: 
        console.log('Tipo Novato');
        break;
    default: 
        console.log('Tipo desconocido.');
        break;
}

// Operador ternario
console.log(tipo <= 2 ? 'Tipo alto' : 'Tipo bajo');