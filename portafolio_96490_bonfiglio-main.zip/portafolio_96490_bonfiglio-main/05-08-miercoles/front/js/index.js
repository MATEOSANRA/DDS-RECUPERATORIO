const cargarDatos = async () => {
    const divCursos = document.getElementById('divCursos');
    if (divCursos) {
        let nivel = 0;
        const ddlNivel = document.getElementById('ddlNivel');
        if (ddlNivel) {
            nivel = ddlNivel.value;
        }


        const res = await fetch(nivel != '0' ? `http://localhost:3000/niveles/${nivel}` : 'http://localhost:3000/cursos');
        const datos = await res.json();
        if (datos) {
        
            let contenido = '<table class="table">';
            contenido += `
            <tr>
                <td>ID</td>
                <td>Nombre</td>
                <td>Duracion</td>
                <td>Cupo</td>
                <td>Nivel</td>
            </tr>
            `;
            datos.forEach(curso => {
                contenido += `
                <tr>
                    <td>${curso.id}</td>
                    <td>${curso.nombre}</td>
                    <td>${curso.duracion}</td>
                    <td>${curso.cupo}</td>
                    <td>${curso.nivel}</td>
                </tr>
                `            
            });
            contenido += '</talbe>'
            divCursos.innerHTML = contenido;
        }
        
    }
}

const btnCargarCursos = document.getElementById('btnCargarCursos');

if (btnCargarCursos) {
    btnCargarCursos.addEventListener('click', cargarDatos);
}