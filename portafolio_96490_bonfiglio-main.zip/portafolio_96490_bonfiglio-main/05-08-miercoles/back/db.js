import { Sequelize } from "sequelize";

export const seq = new Sequelize({
    dialect: 'sqlite',
    storage: './data/data.sqlite'
});