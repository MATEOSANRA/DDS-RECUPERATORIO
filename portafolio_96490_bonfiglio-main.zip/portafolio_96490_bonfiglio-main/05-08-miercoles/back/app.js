import express from 'express';
import cors from 'cors';
import { ServicioCurso } from './servicioCursos.js';
import { seq } from './db.js';

const main = async () => {
	const app = express();
	const PORT = 3000;
	app.use(cors());

	const servicio = new ServicioCurso();

	try {
		seq.sync().then(() => console.log('Sincronización correcta!'));
	} catch (error) {
		console.log(`ERROR: no se pudo sincronizar. \n ${error}`);
	}

	servicio.inicializarDesdeCero();

	// GET '/'
	app.get('/', (req, res) => {
		res.end('<h1>Home</h1>');
	})

	// GET  'cursos/'
	app.get('/cursos/', async (req, res) => {
		const cursos = await servicio.consultarCursos();
		if (cursos.length != 0) {
			res.json(cursos);
		} 
		else {
			res.send('<h1>No se encontraron cursos.</h1>');
		}
		res.end();
	});

	// GET '/cursos/:id'
	app.get('/cursos/:id', async (req, res) => {
		const id = parseInt(req.params.id);
		if (id) {
			const curso = await servicio.consultarCurso(id);
			if (curso) {
				res.json(curso);
			}
			else {
				res.send(`No se encontró ningun curso de ID: ${id}`);
			}
		}
		else {
			res.send('Error en el id ingresado.');
		}
		res.end();
	});

	app.get('/niveles/:nivel', async (req, res) => {
        const nivel = parseInt(req.params.nivel);
		if (nivel) {
			const cursos = await servicio.consultarCursoNivel(nivel);
			if (cursos) {
				res.json(cursos);
			}
			else {
				res.send(`No se encontraron cursos de nivel ${nivel}`);
			}
		}
		else {
			res.send('Error en parametro nivel');
		}
		res.end();
    })

	app.listen(PORT, () => {console.log(`Sevidor en: https://localhost:${PORT}`)});
}

main();