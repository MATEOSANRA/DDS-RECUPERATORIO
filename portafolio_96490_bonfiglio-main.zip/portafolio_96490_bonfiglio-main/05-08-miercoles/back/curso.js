import { seq } from './db.js';
import { DataTypes } from 'sequelize';

export const Curso = seq.define('Curso',
    {
        id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
        nombre: { type: DataTypes.TEXT },
        duracion: { type: DataTypes.STRING },
        cupo: { type: DataTypes.INTEGER },
        nivel: { type: DataTypes.INTEGER }
    },
    {
        timestamps: false,
        modelName: 'curso',
        seq
    }
)