import { seq } from './db.js';
import { Curso } from './curso.js';

export class ServicioCurso {
    async consultarCursos() {
        return await Curso.findAll();
    }

    async consultarCurso(id) {
        return await Curso.findOne({ where: { id: id } });
    }

    async consultarCursoNivel(nivel) {
        return await Curso.findAll({ where: { nivel: nivel } });
    }

    async crearCursosIniciales() {
        await Curso.bulkCreate([
            {nombre: 'Curso1', duracion: '12 meses', cupo: 15, nivel: 1},
            {nombre: 'Curso2', duracion: '6 meses', cupo: 20, nivel: 2},
            {nombre: 'Curso3', duracion: '8 meses', cupo: 10, nivel: 3},
            {nombre: 'Curso4', duracion: '5 meses', cupo: 23, nivel: 2},
            {nombre: 'Curso5', duracion: '3 meses', cupo: 20, nivel: 2},
            {nombre: 'Curso6', duracion: '18 meses', cupo: 10, nivel: 1}
        ])
    }

    async inicializarDesdeCero() {
        await Curso.truncate();
        await this.crearCursosIniciales();
    }
}