// setTimeout(callback, tiempo) ejecuta la función callback() una vez haya transcurrido el tiempo indicado (en ms)
// las funciones asincronas se ejecutan solo cuando la pila de funciones sincronas esta vacia, el tiempo indicado en 
// setTimeout representa el tiempo minimo, tendiendo que esperar luego que se vacie la pila de funciones sincronas.
setTimeout(() => { console.log('Pasó el tiempo.'); }, 2000);

// setInterval(callback, tiempo) ejecuta la función callback() cada sierto tiempo (en ms)
setInterval(() => { console.log('Paso el tiempo una o mas veces.'); }, 2000);

// Para cortar la ejecución de un setInterval usamos clearInterval():
const intervalo = setInterval(() => console.log('Mostrando en intervalo'), 2000);
clearInterval(intervalo);
