// Una promesa que pasados 3 segundos se resuelve correctamente y devuelve el valor 999
const promesa = new Promise((resolve, reject) => {
    setTimeout(() => resolve('Correcto! Se resolvio correctamente'), 3000);
});

// Como se resuelve correctamente se ejecuta el then
promesa.then((dato) => console.log(dato));

// Una promesa que pasados 3 segundos se resuelve correctamente y devuelve el valor 999
const promesa_reject = new Promise((resolve, reject) => {
    setTimeout(() => reject('Error! la promesa no se resolvió correctamente'), 3000);
});

// Como se resuelve correctamente se ejecuta el then
promesa_reject
.then((_) => console.log('Correcto!', ))
.catch((dato) => console.log(dato));
