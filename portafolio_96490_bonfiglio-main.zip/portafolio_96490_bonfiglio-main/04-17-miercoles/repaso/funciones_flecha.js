const saludar = () => console.log('Hola');
const saludarConNombre = nombre => console.log(`Hola ${nombre}!`);

const sumar = (a, b) => {
    let resultado = a+b;
    return resultado;
}

const main = () => {
    saludar();
    saludarConNombre('Franco');
    console.log(sumar(10, 2));
}

main();