const calcular = (a, b, operacion) => {
    return operacion(a, b);
}

const main = () => {
    console.log(calcular(3, 2, (a, b) => a * b ));
    console.log(calcular(3, 2, (a, b) => a / b));
    console.log(calcular(3, 2, (a, b) => a + b));
    console.log(calcular(3, 2, (a, b) => a - b));
}

main();