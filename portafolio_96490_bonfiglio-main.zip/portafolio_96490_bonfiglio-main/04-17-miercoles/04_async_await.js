// Con async y await podemos hacer lo mismo que con las promesas (03_fetcj.js) pero escribiendo el codigo como si fuera sincrono
// lo que resulta mas sencillo.
const obtenerDatos = async () => {
    const respuesta = await fetch('https://jsonplaceholder.typicode.com/todos');
    if (respuesta.ok) {
        const datos = await respuesta.json();
        datos.forEach(elemento => {
            console.log(elemento.title);
        });
    }
}

obtenerDatos();