const response = fetch('https://jsonplaceholder.typicode.com/todos')
    .then(respuesta => console.log(respuesta.ok))
    .catch(respuesta => console.log(respuesta.ok));

fetch('https://jsonplaceholder.typicode.com/todos')
    .then(respuesta => respuesta.json())
    .then(datos => {
        datos.forEach(elemento => {
            console.log(elemento.title);
        })
    })
    .catch(respuesta => console.log('Error!', respuesta.ok));