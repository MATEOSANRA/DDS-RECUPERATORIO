// Importar la librería seedrandom
const seedrandom = require('seedrandom');

// Función para generar números aleatorios enteros utilizando seedrandom
function generarNumerosAleatorios(seed, cantidad) {
    const rng = seedrandom(seed);
    const numeros = [];
    for (let i = 0; i < cantidad; i++) {
        numeros.push(rng.int32());
    }
    return numeros;
}

// Función para contar números positivos y negativos
function contarPositivosNegativos(numeros) {
    let positivos = 0;
    let negativos = 0;
    for (let numero of numeros) {
        if (numero > 0) {
            positivos++;
        } else if (numero < 0) {
            negativos++;
        }
    }
    return { positivos, negativos };
}

// Función para contar números cuyo resto al dividirlos en 7 sea 0, 3, 5 o 6
function contarRestos(numeros) {
    const restos = [0, 0, 0, 0]; // Índices 0, 1, 2, 3 corresponden a restos 0, 3, 5, 6
    for (let numero of numeros) {
        const resto = Math.abs(numero) % 7;
        if (resto === 0 || resto === 3 || resto === 5 || resto === 6) {
            restos[resto]++;
        }
    }
    return restos;
}

// Función para contar números según su anteúltimo dígito
function contarAnteultimosDigitos(numeros) {
    const contadores = {};
    for (let numero of numeros) {
        const anteultimoDigito = Math.floor(Math.abs(numero / 10) % 10);
        if (contadores[anteultimoDigito] === undefined) {
            contadores[anteultimoDigito] = 1;
        } else {
            contadores[anteultimoDigito]++;
        }
    }
    return contadores;
}

// Función para encontrar el menor valor y su posición
function encontrarMenor(numeros) {
    let menorValor = numeros[0];
    let posicionMenor = 1;
    for (let i = 1; i < numeros.length; i++) {
        if (numeros[i] < menorValor) {
            menorValor = numeros[i];
            posicionMenor = i + 1;
        }
    }
    return { valor: menorValor, posicion: posicionMenor };
}

// Función para contar números cuyo signo sea igual al del anterior
function contarSignoIgualAlAnterior(numeros) {
    let cantidad = 0;
    for (let i = 1; i < numeros.length; i++) {
        if (Math.sign(numeros[i]) === Math.sign(numeros[i - 1])) {
            cantidad++;
        }
    }
    return cantidad;
}

// Función para calcular el promedio entero de números con 6 dígitos
function promedioNumeros6Digitos(numeros) {
    let suma = 0;
    let cantidad = 0;
    for (let numero of numeros) {
        if (numero >= 100000 && numero <= 999999) {
            suma += numero;
            cantidad++;
        }
    }
    if (cantidad === 0) return 0;
    return Math.round(suma / cantidad);
}

// Generar 1,000,000 de números aleatorios enteros con semilla 1763519
const semilla = 1763519;
const cantidadNumeros = 1000000;
const numerosAleatorios = generarNumerosAleatorios(semilla, cantidadNumeros);

// Resultados
const positivosNegativos = contarPositivosNegativos(numerosAleatorios);
const restos = contarRestos(numerosAleatorios);
const anteultimosDigitos = contarAnteultimosDigitos(numerosAleatorios);
const menor = encontrarMenor(numerosAleatorios);
const signoIgualAnterior = contarSignoIgualAlAnterior(numerosAleatorios);
const promedio6Digitos = promedioNumeros6Digitos(numerosAleatorios);

console.log("Cantidad de números positivos:", positivosNegativos.positivos);
console.log("Cantidad de números negativos:", positivosNegativos.negativos);
console.log("Cantidad de números cuyo resto al dividirlos en 7 sea 0:", restos[0]);
console.log("Cantidad de números cuyo resto al dividirlos en 7 sea 3:", restos[1]);
console.log("Cantidad de números cuyo resto al dividirlos en 7 sea 5:", restos[2]);
console.log("Cantidad de números cuyo resto al dividirlos en 7 sea 6:", restos[3]);
console.log("Arreglo de contadores según el anteúltimo dígito:", anteultimosDigitos);
console.log("Menor valor:", menor.valor, "en la posición:", menor.posicion);
console.log("Cantidad de números cuyo signo sea igual al del anterior:", signoIgualAnterior);
console.log("Promedio entero de números con 6 dígitos:", promedio6Digitos);
