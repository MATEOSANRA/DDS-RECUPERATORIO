var seedrandom = require('seedrandom');
var rng = seedrandom(1763519);

const promedio = function (total, cantidad) {
    if (cantidad != 0){
        return Math.round(total / cantidad);
    }
    return 0;
}

const main = function () {
    let numeros = [];
    let cantPositivos = 0, cantNegativos = 0, cantItem2 = 0, pos = 0, cantMismoSignoAnterior = 0, qNumerosPtoSeis = 0, sumaPtoSeis = 0;
    let contIndiceSegundoDigito = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
    let menor, posMenor, anterior;
    for (let i = 0; i < 1_000_000; i++){
        numeros.push(rng.int32());
    }

    numeros.forEach(num => {
        pos++

        if (num > 0) { cantPositivos++; }
        else if (num < 0) { cantNegativos++; }

        let mod = num % 7;

        if (mod === 0 || mod === 3 || mod === 5 || mod === 6) { cantItem2++; }

        contIndiceSegundoDigito[Number(num.toString()[num.toString().length - 2])]++;

        if ((anterior >= 0 && num >= 0) || (anterior < 0 && num < 0)) { cantMismoSignoAnterior++; }

        if (!menor || num < menor) {
            menor = num;
            posMenor = pos
        }

        if (100_000 <= Math.abs(num) && Math.abs(num) <= 999_999) {
            qNumerosPtoSeis++;
            sumaPtoSeis += num;
        }

        anterior = num
    });

    console.log('Cantidad positivos: ', cantPositivos);
    console.log('Cantidad negativos: ', cantNegativos);
    console.log('Cantidad resto 7: ', cantItem2);
    console.log('Elementos segun segundo digito: ', contIndiceSegundoDigito)
    console.log('Menor del conjunto: ', menor, ' - Posicion menor: ', posMenor);
    console.log('Cantidad numeros signo igual al anterior: ', cantMismoSignoAnterior);
    console.log('Promedio entero seis digitos: ', promedio(sumaPtoSeis, qNumerosPtoSeis));
}

main();