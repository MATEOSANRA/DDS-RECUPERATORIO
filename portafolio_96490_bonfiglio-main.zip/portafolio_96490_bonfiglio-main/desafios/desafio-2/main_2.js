const main = function() {
    let dataJSON = require('./data/personas.json');
    let sumaEdades = dataJSON.map(x => x.edad).reduce((x, y) => x + y);
    let sumaEdadesNomParApImpar = dataJSON.filter(x => x.nombre.length % 2 === 0 && x.apellido.length % 2 !== 0)
                                          .map(x => x.edad)
                                          .reduce((x, y) => x + y);
    let menor = dataJSON.reduce((x, y) => x.edad <= y.edad ? x : y);
    let nombresGomez = dataJSON.filter(x => x.apellido === 'GOMEZ').map(x => x.nombre).sort();
    let cantidades = { 
        menores: dataJSON.filter(x => x.edad <= 18).length,
        mayores: dataJSON.filter(x => x.edad > 18).length,
        primerMitad: dataJSON.filter(x => x.apellido[0] <= 'L').length,
        segundaMitad: dataJSON.filter(x => x.apellido[0] > 'L').length
    };
    let acumuladorPorApellido = {
        'CASTILLO': dataJSON.filter(x => x.apellido === 'CASTILLO').length,
        'DIAZ': dataJSON.filter(x => x.apellido === 'DIAZ').length,
        'FERRER': dataJSON.filter(x => x.apellido === 'FERRER').length,
        'PINO': dataJSON.filter(x => x.apellido === 'PINO').length,
        'ROMERO': dataJSON.filter(x => x.apellido === 'ROMERO').length
    };

    console.log('Promedio edades: ', dataJSON.length !== 0 ? Math.round(sumaEdades / dataJSON.length) : 0);
    console.log(`Nombre menor: ${menor.nombre} | apellido menor: ${menor.apellido} - Edad: ${menor.edad}`);
    console.log('Nombres de personas de apellido GOMEX: ', nombresGomez);
    console.log('Suma de edades de personas con nombre de longitud par y apellido de longitud impar: ', sumaEdadesNomParApImpar);
    console.log('Resultado funcion obtenerCantidades: ', cantidades);
    console.log('Resultado funcion acumularPorApellido: ', acumuladorPorApellido);
}

main();