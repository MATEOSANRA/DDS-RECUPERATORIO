const main = function() {
    const dataJSON = require('./data/personas.json')

    let sumaEdades = 0, sumaEdadesNomParApImpar = 0;
    let menorEdad, nombreMenor, apellidoMenor, 
    nombresGomez = [];

    dataJSON.forEach(persona => {
        sumaEdades += persona.edad;

        if (!menorEdad || persona.edad < menorEdad ) {
            menorEdad = persona.edad;
            nombreMenor = persona.nombre;
            apellidoMenor = persona.apellido;
        };

        if (persona.apellido === 'GOMEZ') { nombresGomez.push(persona.nombre); };

        if (persona.nombre.length % 2 === 0 && persona.apellido.length % 2 !== 0) { sumaEdadesNomParApImpar += persona.edad; };
    })

    console.log('Promedio edades: ', dataJSON.length !== 0 ? Math.round(sumaEdades / dataJSON.length) : 0);
    console.log(`Nombre menor: ${nombreMenor} | apellido menor: ${apellidoMenor} - Edad: ${menorEdad}`);
    console.log('Nombres de personas de apellido GOMEX: ', nombresGomez.sort());
    console.log('Suma de edades de personas con nombre de longitud par y apellido de longitud impar: ', sumaEdadesNomParApImpar);
    console.log('Resultado funcion obtenerCantidades: ', obtenerCantidades('./data/personas.json'))
    console.log('Resultado funcion acumularPorApellido: ', acumularPorApellido('./data/personas.json'))
}

const obtenerCantidades = function(file) {
    const dataJSON = require(file);

    let obj = { menores: 0, mayores: 0, primerMitad: 0, seguindaMitad: 0 };

    dataJSON.forEach(persona => {
        if (persona.edad > 18) { obj.mayores++; }
        else { obj.menores++; };

        if (persona.apellido[0] <= 'L') { obj.primerMitad++; }
        else { obj.seguindaMitad++; };
    })
    return obj;
}

const acumularPorApellido = function(file) {
    const dataJSON = require(file);

    let map = new Map();

    dataJSON.forEach(persona => {
        if (map.has(persona.apellido)) { map.set(persona.apellido, map.get(persona.apellido) + 1) }
        else if (persona.apellido === 'CASTILLO' || persona.apellido === 'DIAZ' || 
                persona.apellido === 'FERRER' || persona.apellido === 'PINO' || persona.apellido === 'ROMERO'){ map.set(persona.apellido, 1); };
    })
    return map;
}

main();
