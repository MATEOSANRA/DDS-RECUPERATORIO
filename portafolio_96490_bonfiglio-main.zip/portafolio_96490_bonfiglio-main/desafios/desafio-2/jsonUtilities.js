import * as fs from 'fs';

class Reader {
    constructor(){}

    readJSON(file) {
        return fs.promises.readFile(file, 'utf8')
            .then(data => JSON.parse(data));
    }
}


export default Reader;