import { sequelize } from "./db.js";
import { ServicioPersonas } from "./servicio.js";
import express from 'express';
import cors from 'cors';

const main = async () => {
    const app = express();
    await sequelize.sync();

    // Define que sitios pueden acceder al contenido (CORS)
    app.use(cors());

    const servicio = new ServicioPersonas();

    app.get('/personas', async (req, res) => {
        const personas = await servicio.obtenerPersonas();
        if (personas) {
            res.json(personas);
        }
        else {
            res.statusCode(404);
            res.send();
        }
        res.end();
    });

    // app.get('/personas/:documento', async (req, res) => {
    //     const documento = parseInt(req.params.documento);
    //     const persona = await servicio.obtenerPersona(documento);
    //     res.send(persona);
    //     res.end();
    // });

    app.get('/personas/:apellido', async (req, res) => {
        const apellido = req.params.apellido;
        const personas = await servicio.obtenerPersonasApellido(apellido);
        if (personas) {
            res.json(personas);
        }
        else {
            res.json({ ok: false, mensaje: 'No se encontró la persona.', datos: []});
        }
        res.end();
    });

    app.listen(8081);
}

main();