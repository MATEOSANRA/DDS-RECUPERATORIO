import { sequelize } from "./db.js";
import { Persona } from "./persona.js";

export class ServicioPersonas {
    async crearPersoa (personaData) {
        if (personaData.documento) {
            const persona = await Persona.create(personaData);
            console.log('Persona creada correctamente.')
            return persona;
        }
        else {
            console.log('[ERROR - crearPersona] El DNI es obligatorio.');
        }
    }
    
    async obtenerPersonas() {
        return await Persona.findAll();
    }
    
    async obtenerPersonasApellido(apellido) {
        return await Persona.findAll({ where: { apellido: apellido } });
    }
    
    async modificarPersona(documento, nuevaData) {
        const persona = await Persona.findOne({ where: { documento: documento } });
        if (persona) {
            persona.nombre = nuevaData.nombre ? nuevaData.nombre : persona.nombre,
            persona.apellido = nuevaData.apellido ? nuevaData.apellido : persona.apellido,
            persona.edad = nuevaData.edad ? nuevaData.edad : persona.edad
    
            persona.save();
            console.log('Persona actualizada correctamente.')
        }
        else {
            console.log(`No existe persona con documento: ${documento}`);
        }
    }
}
