const btnBuscarPersona = document.getElementById('btnBuscarPersona');


const buscarPersona = async () => {
    const divPersonas = document.getElementById('mostrarPersonas');
    if (divPersonas) {
        const textoBuscarPersona = document.getElementById('textoBuscarPersona');
        let apellido = '';
        if (textoBuscarPersona) {
            apellido = textoBuscarPersona.value;
        }
        const res = await fetch(apellido !== '' ? `http://localhost:8081/personas/${apellido}` : 'http://localhost:8081/personas/');
        const datos = await res.json();

        if (datos) {
            contenido = '<table class="table">';
            contenido += `
            <thead>
            <tr>
                <td>Documento</td>
                <td>Nombre</td>
                <td>Apellido</td>
                <td>Edad</td>
            </tr>
            </thead>
            <tbody>
            `;
            datos.forEach(persona => {
                contenido += `
                <tr>
                <td>${persona.documento}</td>
                <td>${persona.nombre}</td>
                <td>${persona.apellido}</td>
                <td>${persona.edad}</td>
                </tr>
                `;
            });
            contenido += `
            </tbody>
            </table>
            `;
            divPersonas.innerHTML = contenido;
        }
    }
}


if (btnBuscarPersona) {
    btnBuscarPersona.addEventListener('click', buscarPersona)
}