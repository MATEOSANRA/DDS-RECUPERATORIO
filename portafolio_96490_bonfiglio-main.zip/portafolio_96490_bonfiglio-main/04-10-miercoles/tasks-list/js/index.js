let tareas = [];
let contador = 0;

// Referenciamos al boton por id
// const btnAgregarTarea = document.getElementById('btnAgregarTarea');
const btnAgregarTarea = document.querySelector('#btnAgregarTarea'); // Esto me permite buscar por selector, no solo por id

const txtNombreTarea = document.querySelector('#txtNombreTarea');

// Definimos el constructor para la tercer forma de crear un objeto
function Tarea (nombreTarea) {
    this.id = ++contador;
    this.nombre = nombreTarea;
    this.realizada = false;
}

const agregarTarea = function(nombreTarea) {
    // Creamos un nuevo objeto [JavaScript utiliza el modelo de Objetos Prototipo, no de herencia. Es decir son dinamicos
    // y no son instancias de una clase]

    // Primer forma de crear un objeto
    // const nuevaTarea = {
    //     id: ++contador,
    //     nombre: nombreTarea,
    //     realziada: false
    // };

    // Segunda froma de crear un objeto [Crearlo vacio y agregarle atributos de forma directa]
    const nuevaTarea = new Object();
    nuevaTarea.id = ++contador;
    nuevaTarea.nombre = nombreTarea;
    nuevaTarea.realizada = false;

    // Tercera forma
    // nuevaTarea = Tarea(nombreTarea)

    tareas.push(nuevaTarea);
    
    renderListaTarea();

    // console.table(tareas);
}

const renderListaTarea = function() {
    const listaTareas = document.querySelector('#listaTareas');
    if (listaTareas) {
        let contenido = '';

        tareas.forEach(t => {
            contenido += `
            <li class="list-group-item">
                <input class="form-check-input me-1" type="checkbox" value="" id="checkbox">
                <label class="form-check-label" for="firstCheckbox">${t.nombre}</label>
                <div class="btn-group float-end" role="group" aria-label="Basic mixed styles example">
                    <button type="button" class="btn btn-outline-success"><i class="bi bi-pencil-fill"></i></button>
                    <button type="button" class="btn btn-outline-danger"><i class="bi bi-trash-fill"></i></button>
                </div>
            </li>
            `
        })

        // El innerHTML referencia la estructura html dentro del elemento
        listaTareas.innerHTML = contenido;
    }
}

// Por convención de programacion orientada a eventos las funciones que se disparan al producirse un evento se nombran iniciando en on
// function onAgregarTarea() {
//     console.log('Presionó el botón')
// }

// Otra forma de definir una función
// let onAgregarTarea = function() {
    //     console.log('Presionó el botón')
    // }

// Otra forma [función flecha]
// const onAgregarTarea = () => {console.log('Presionó el botón')}

if (btnAgregarTarea && txtNombreTarea) {
    // Agrega un listener al objeto que al recibir el evento indicado en el primer paramero, ejecuta una 
    // función indicada en el segundo parametro
    btnAgregarTarea.addEventListener('click', () => {   // funcion lambda o flecha
        if (txtNombreTarea.value){
            agregarTarea(txtNombreTarea.value);
            txtNombreTarea.value = '';
        }
    });
}