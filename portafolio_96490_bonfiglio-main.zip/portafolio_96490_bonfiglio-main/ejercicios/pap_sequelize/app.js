import { sequelize } from './db.js';
import { Tarea } from './tarea.js';
import { Usuario } from './usuario.js';

const main = async () => {
    try {
        await sequelize.sync();
        console.log('Sincronizacion correcta!')
    } catch (error) {
        console.log('[ERROR] Sincronizacion incorrecta: ', error);
    }

    Usuario.hasMany(Tarea);
    Tarea.belongsTo(Usuario);

    crearUsuarios();

    const usuarios = await recuperarUsuarios();
    usuarios.forEach(usuario => {
        console.log(`|${usuario.nombre}|${usuario.apellido}|${usuario.usuario}|${usuario.email}|`)
    });



    usuarios.forEach(async usuario => {
        await usuario.destroy();
    });
}

const crearUsuarios = async () => {
    const datosJuanPerez = {
        nombre: 'Juan',
        apellido: 'Perez',
        usuario: 'juanperez',
        password: 'UnaContraseña',
        email: 'jperez@gmail.com'
    };

    try {
        if (! await Usuario.findOne({ where: { usuario: datosJuanPerez.usuario } })) {
            const juanPerez = await Usuario.create(datosJuanPerez);
            console.log('Usuario creado correctamente.');
        }
        else { console.log('Ya existe el usuario') }
    } catch (error) {
        console.log('[ERROR] Usuario no creado: ', error);
    }

    const datosMariaGonzales = {
        nombre: 'Maria',
        apellido: 'Gonzales',
        usuario: 'marigonzales',
        password: 'OtraContraseña',
        email: 'mgonzales@gmail.com'
    };

    try {
        if (! await Usuario.findOne({ where: { usuario: datosMariaGonzales.usuario } })) {
            const mariaGonzales = await Usuario.create(datosMariaGonzales);
            console.log('Usuario creado correctamente.');
        }
        else { console.log('Ya existe el usuario') }
    } catch (error) {
        console.log('[ERROR] Usuario no creado: ', error);
    }
}

const recuperarUsuarios = async () => {
    return await Usuario.findAll();
}

const recuperarUsuario = async (id) => {
    const usuario = await Usuario.findOne({ where: { id: id } });

    if (usuario) { return usuario }
    else {
        console.log('Usuario no encontrado.');
        return null;
    }
}

const modificarUsuario = async (id, nombre) => {
    const usuario = await Usuario.findOne({ where: { id: id } });
    if (usuario) {
        usuario.nombre = nombre;
        await usuario.save();
        console.log('Usuario modificado');
    }
    else {
        console.log('Usuario no encontrado');
    }
}

const eliminarUsuario = async (id) => {
    const usuario = await Usuario.findOne({ where: { id: id } });

    if (usuario) {
        await usuario.destroy();
        console.log('Usuario eliminado');
    }
    else {
        console.log('Usuario no encontrado.')
    }
}

const agregarTarea = async (usuarioId, descripcionTarea) => {
    const usuario = await Usuario.findOne({ where: { id: usuarioId } });
    if (usuario) {
        usuario.createTarea({
            descripcion: descripcionTarea
        });
    }
    else {
        console.log('Usuario no encontrado.');
    }
}

const listarTareasUsuario = async (usuarioId) => {
    const usuario = await Usuario.findOne({ where: { id: usuarioId } });
    if (usuario) {
        const tareas = await usuario.getTareas();
        if (tareas) {
            tareas.forEach(tarea => {
                console.log(`|${t.descripcion}|`);
            });
        }
        else {
            console.log('El usuario no tiene tareas.')
        }
    }
    else {
        console.log('Usuario no encontrado.');
    }
}

const listarTareasUsuarioPrecarga = async (usuarioId) => {
    const usuario = await Usuario.findOne({ 
        where: { id: usuarioId },
        include: Tarea 
    });

    if (usuario && usuario.Tareas) {
        usuario.Tareas.forEach(tarea => {
            console.log(`|${t.descripcion}|`);
        })
    }
    else {
        console.log('No existe el usuario o el usuario no posee tareas asociadas.')
    }
}

const eliminarTareaUsuario = async (usuarioId, descripcionTarea) => {
    const usuario = await Usuario.findOne({ where: { id: usuarioId } });
    if (usuario){
        const tarea = await usuario.getTareas({
            where: { descripcion: descripcionTarea },
        });
    
        if (tarea) {
            await usuario.removeTarea(t);
        }
    }
}  

main();