import { Model, DataTypes } from 'sequelize';
import { sequelize } from './db.js';

export const Tarea = sequelize.define('Tarea', 
    {
        descripcion: { type: DataTypes.TEXT }
    },
    {
        sequelize,
        modelName: 'tarea',
        timestamps: false
    }
);