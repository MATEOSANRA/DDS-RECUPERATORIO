import { useState, useEffect } from "react";
import axios from 'axios';
import { useNavigate } from "react-router-dom";
import Obra from "./Obra";

const Lista = () => {
    const [obras, setLista] = useState([]);

    useEffect(() => {getObras()}, []);

    const navigate = useNavigate();

    const getObras = async () => {
        const obrasDatos = await axios.get('http://localhost:3001/api/obras-teatrales/');
        setLista(obrasDatos.data);
    }

    const eliminarObra = async (id) => {
        await axios.delete(`http://localhost:3001/api/obras-teatrales/${id}`);
        await getObras();
    }

    const updateObra = (id) => {
        navigate(`/obras/registrar/${id}`);
    }

    return (
    <table className="table table-warning table-bordered text-center mt-5">
        <thead>
            <tr><th colSpan="7" className="text-center">Obras teatrales</th></tr>
            <tr>
                <th>#</th>
                <th>Titulo</th>
                <th>Director</th>
                <th>Precio Entrada</th>
                <th>Fecha Desde</th>
                <th>Fecha Hasta</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            {
                obras && obras.map(obra => {return (<Obra key={obra.Id} onDelete={eliminarObra} onUpdate={updateObra} obra={obra} />)})
            }
        </tbody>
    </table>
    )
}

export default Lista;