const Inicio = () => {
    return( 
    <div className="row text-center">
        <h1 className="title">Bienvenido al compendio de obras teatrales</h1>    
        <h2 className="subtitle">El mas grande del mundo!</h2>
    </div>
    )
}

export default Inicio