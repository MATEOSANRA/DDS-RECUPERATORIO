const Obra = ({onDelete, onUpdate, obra}) => {
    return (
        <tr>
            <td>{obra.Id}</td>
            <td>{obra.Titulo}</td>
            <td>{obra.Director}</td>
            <td>{obra.PrecioEntrada}</td>
            <td>{obra.FechaDesde}</td>
            <td>{obra.FechaHasta}</td>
            <td>
                <button className="btn btn-outline-secondary me-2" onClick={() => {onUpdate(obra.Id)}}><i className="bi bi-pencil" /></button>
                <button className="btn btn-outline-danger" onClick={() => {onDelete(obra.Id)}}><i className="bi bi-trash" /></button>
            </td>
        </tr>
    )
}

export default Obra;