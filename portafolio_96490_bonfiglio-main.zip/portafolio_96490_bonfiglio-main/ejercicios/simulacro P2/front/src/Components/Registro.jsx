import { useParams } from "react-router-dom";
import Formulario from "./Formulario";
import Lista from "./Lista";

const Registro = () => {
    const {id} = useParams();
    return (
        <>
            <Formulario id={id} />
            <Lista />
        </>
    )
}

export default Registro;