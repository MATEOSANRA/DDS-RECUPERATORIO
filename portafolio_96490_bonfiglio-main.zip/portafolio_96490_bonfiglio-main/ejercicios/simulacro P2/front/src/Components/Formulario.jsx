import axios from 'axios';
import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { useNavigate, useParams } from 'react-router-dom';

const Formulario = ({id}) => {

    const navigate = useNavigate();

    const {register, handleSubmit} = useForm();

    const [obra, setObra] = useState({});

    useEffect(() => {
        if (id > 0) {
            getObra(id);
        }
        else {
            setObra({Id: '', Titulo: '', Director: '', PrecioEntrada: '', FechaDesde: '', FechaHasta: ''});
        }
    }, [])

    const getObra = async (id) => {
        const obraData = await axios.get(`http://localhost:3001/api/obras-teatrales/${id}`);
        setObra(obraData.data);
    }

    const onSubmit = async (data) => {
        console.log('Valores del form: ', data);
        if (id > 0) {
            // Actualizacion
            await axios.put(`http://localhost:3001/api/obras-teatrales/${id}`, data)
        }
        else {
            await axios.post('http://localhost:3001/api/obras-teatrales', data);
        }
        volver();
    }

    const volver = () => {
        navigate('/obras');
    }

    const cancelar = () => {
        volver();
    }

    return (
        <form onSubmit={handleSubmit(onSubmit)} className="row text-center">
            <div className='card'>
                <div>
                    <div className='row mt-2'>
                        <div className='col-4'>
                            <label htmlFor='Titulo'>Titulo:</label>
                        </div>
                        <div className='col-8'>
                            <input type="text" className='form-control' defaultValue={obra.Titulo} {...register('Titulo', {required: 'El titulo es obligatorio.'})} />
                        </div>
                    </div>

                    <div className='row mt-2'>
                        <div className='col-4'>
                            <label htmlFor='Director'>Director:</label>
                        </div>
                        <div className='col-8'>
                            <input type="text" className='form-control' defaultValue={obra.Director} {...register('Director', {required: 'El director es obligatorio.'})} />
                        </div>
                    </div>

                    <div className='row mt-2'>
                        <div className='col-4'>
                            <label htmlFor='PrecioEntrada'>Precio Entrada:</label>
                        </div>
                        <div className='col-8'>
                            <input type="text" className='form-control' defaultValue={obra.PrecioEntrada} {...register('PrecioEntrada', {required: 'El precio de la entrada es obligatorio.'})} />
                        </div>
                    </div>

                    <div className='row mt-2'>
                        <div className='col-2'>
                            <label htmlFor='FechaDesde'>Fecha Desde:</label>
                        </div>
                        <div className='col-4'>
                            <input type="text" className='form-control' defaultValue={obra.FechaDesde} {...register('FechaDesde', {required: 'La fecha desde es obligatorio.'})} />
                        </div>

                        <div className='col-2'>
                            <label htmlFor='FechaHasta'>Fecha Hasta:</label>
                        </div>
                        <div className='col-4'>
                            <input type="text" className='form-control' defaultValue={obra.FechaHasta} {...register('FechaHasta', {required: 'La fecha hasta es obligatorio.'})} />
                        </div>
                    </div>

                    <div className='row mt-2 mb-2'>
                        <div className='col-3'></div>
                        <button className='btn btn-outline-danger mr-3 col-2' onClick={cancelar}>Cancelar</button>
                        <div className='col-2'></div>
                        <input type="submit" value={id > 0 ? 'Guardar': 'Crear'} className='btn btn-outline-success col-2' />
                    </div>
                </div>
            </div>
        </form>
    )
}

export default Formulario;