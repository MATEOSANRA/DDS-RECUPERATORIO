import { Link } from "react-router-dom";
const Menu = () => {
    return (
    <>
        <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
            <div className="container-fluid">
                <Link className="navbar-brand" to="/">Obras teatrales</Link>
                <div className="collapse navbar-collapse" id="navbarNav">
                    <ul className="navbar-nav me-auto">
                        <li className="nav-item">
                        <Link className="nav-link active" to="/">Inicio</Link>
                        </li>
                        <li className="nav-item">
                        <Link className="nav-link active" to="/obras">Consultar</Link>
                        </li>
                    </ul>
                    <Link className="d-flex" to='/obras/registrar/0'>
                        <button className='btn btn-primary'>Registrar obra</button>
                    </Link>
                </div>
            </div>
        </nav>
    </>
    )
}

export default Menu;