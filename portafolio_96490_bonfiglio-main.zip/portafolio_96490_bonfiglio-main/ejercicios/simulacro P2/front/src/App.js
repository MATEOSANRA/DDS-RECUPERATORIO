import {Routes, Route}  from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap-icons/font/bootstrap-icons.css'
import Menu from './Components/Menu';
import Inicio from './Components/Inicio';
import Lista from './Components/Lista';
import Registro from './Components/Registro';

function App() {
  return (
    <>
      <Menu />
      <div className='container bg-light'>
        <Routes>
          <Route path='/' element={<Inicio />}/>
          <Route path='/obras' element={<Lista />}/>
          <Route path='/obras/registrar/:id' element={<Registro />}/>
        </Routes>
      </div>
    </>
  );
}

export default App;
