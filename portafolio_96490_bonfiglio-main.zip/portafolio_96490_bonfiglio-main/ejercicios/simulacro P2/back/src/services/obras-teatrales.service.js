import sequelize from "../models/database.js"
import { Op } from "sequelize";


const getObrasTeatrales = async (filtros) => {
    const where = {};
    if (filtros.titulo)
        where.Titulo =  { [Op.like]: `%${filtros.titulo}%` }
    if (filtros.director)
        where.Director =  { [Op.like]: `%${filtros.director}%` }
    const resultado = await sequelize.models.ObrasTeatrales.findAll({
        attributes: [
            'Id',
            'Titulo',
            'Director',
            'Eliminado',
            'FechaDesde',
            'FechaHasta',
            'PrecioEntrada'
        ],
        where,
        order: [['Titulo', 'ASC']]
    })
    // console.log(resultado) // console para ver que deevuelve 
    return resultado.map(p => { //para cada objeto para devolver objetos con con propiedades que empiezen con minuscula
        return {
            Id: p.dataValues.Id,
            Titulo: p.dataValues.Titulo,
            Director: p.dataValues.Director,
            PrecioEntrada: p.dataValues.PrecioEntrada,
            FechaDesde: p.dataValues.FechaDesde,
            FechaHasta: p.dataValues.FechaHasta,
        }
    })
}

const getObraTeatral = async (id) => {
    const obra = sequelize.models.ObrasTeatrales.findOne({ where: { Id: id } });
    if (!obra) {
        throw new Error(`No se encontró obra para el id ${id}.`)
    }
    return obra;
}

const insertarObraTeatral = async (obraTeatralCmd) => {
    const resultado = await sequelize.models
    .ObrasTeatrales.create({
        Titulo: obraTeatralCmd.Titulo,
        Director: obraTeatralCmd.Director,
        Eliminado: false,
        PrecioEntrada: obraTeatralCmd.PrecioEntrada,
        FechaDesde: obraTeatralCmd.FechaDesde,
        FechaHasta: obraTeatralCmd.FechaHasta,
    })
    console.log('insertar Obra Teatral', resultado)
    return {
        Id: resultado.dataValues.Id,
        Titulo: resultado.dataValues.Titulo,
    };
}

// ====================PUT====================
const editarObraTeatral = async (obraTeatralCmd) => {
    const obra = await sequelize.models.ObrasTeatrales.findOne({
        where: { Id: obraTeatralCmd.id, Eliminado: false },
    });
    if (!obra) {
        throw new Error("obra teatral no encontrada");
    }

    const updatedobra = await sequelize.models.ObrasTeatrales.update(
        {
            Titulo: obraTeatralCmd.Titulo,
            Director: obraTeatralCmd.Director,
            IdClasificacion: obraTeatralCmd.idClasificacion,
            PrecioEntrada: obraTeatralCmd.PrecioEntrada
        },
        {
            where: { Id: obraTeatralCmd.id }
        });
    console.log(obra)
    return { id: obraTeatralCmd.id };

}

const deleteObraTeatral = async (obraTeatralCmd) => {
    const obra = await sequelize.models.ObrasTeatrales.findOne({
        where: { Id: obraTeatralCmd.id }
    })
    if (!obra) {
        throw new Error(`Obra teatral no encontrada para el id: ${obraTeatralCmd.id}.`)
    }

    obra.delete

    await sequelize.models.ObrasTeatrales.destroy({
        where: { Id: obraTeatralCmd.id }
    })
    return { message: 'Obra teatral eliminada.' }
}

const obrasTeatralesService = {
    getObrasTeatrales,
    insertarObraTeatral,
    editarObraTeatral,
    deleteObraTeatral,
    getObraTeatral
}

export default obrasTeatralesService;
