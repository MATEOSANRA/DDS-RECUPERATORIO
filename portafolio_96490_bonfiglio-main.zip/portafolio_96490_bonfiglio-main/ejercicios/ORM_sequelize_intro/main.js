import { Sequelize, DataTypes, Op, QueryTypes } from "sequelize";

const main = async function () {
    // Utiliza una base de datos en memoria (sin persistencia, para testing)
    // const seq = Sequelize("sqlite::memory");
    const seq = new Sequelize({
        dialect: "sqlite",
        storage: "./data/database.db"
    });

    // Para comprobar la conección:
    try {
        await seq.authenticate();
        console.log('Autenticación correcta!');
    } catch (error) {
        console.log('[ERROR] Autenticación incorrecta: ', error);
    }

    // Para sincronizar la base de datos
    try {
        await seq.sync();
        console.log('Sincronización correcta!');
    } catch (error) {
        console.log('[ERROR] Sincronización incorrecta: ', error);
    }

    /* 
        Definimos un modelo (abstracción que representa una relación)

        En este caso se define el modelo usuario con los atributos (columnas):
            * id [PK][Autoincrement]
            * nombre
            * apellido
            * usuario
            * genero: un valor igual a F o M
            * fecha_alta [default: now]

    */
    const Usuario = seq.define("usuario", {
        id: {
            type: DataTypes.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
        nombre: { type: DataTypes.STRING, allowNull: flase },
        apellido: { type: DataTypes.STRING, allowNull: true },
        usuario: { type: DataTypes.STRING, unique: true },
        edad: { type: DataTypes.INTEGER },
        genero: { 
            type: DataTypes.STRING, 
            allowNull: true, 
            isIn: {
                args: [['F', 'M']],
                msg: 'Debe ser Masculino (M) o Femenino (F)'
            } 
        },
        fecha_alta: { type: DataTypes.DATE, defaultvalue: DataTypes.NOW }
    })

    const Perfil = seq.define("Perfil", {
        id: {
            type: DataTypes.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
        descripcion: { type: DataTypes.TEXT }
    });

    Perfil.hasOne(Usuario, { foreignKey: 'usuario' });
    Usuario.belongsTo(Perfil);

    /* 
        Operaciones con modelos:
    */

    // Devuelve todos los registros de Usuario en la base dedatos
    const usuarios = await Usuario.findAll();

    // Devuelve un solo registro que coincida con lo indicado en where: 
    const usuarioParticular = await Usuario.findOne({ where: { id: 5 } });

    // Devuelve todos los usuarios cuyo apellido cntengoa "cia"
    const usuariosFiltro = await Usuario.findAll({
        where: {
            apellido: { [Op.like]: '%cia' }
        }
    })

    // devuelve todos los usuarios cuyo apellido contenga "cia" y cuyo ip no sea 1, 2 o 3
    const usuariosFiltro2 = await Usuario.findAll({
        where: {
            [Op.and]: [
                { apellido: { [Op.like]: '%cia' } },
                { [Op.not]: { id: [1, 2, 3] } }
            ]
        }
    });

    // Se pueden paginar los resultados para manejar grandes volumenes de datos.
    // Aqui se obtiene la pagina 2 con un tamañp de pagina de 10 elementos
    const pagina = 2;
    const tamPagina = 10;
    const usuariosPaginados = await Usuario.findAll({
        offset: (pagina - 1) * tamPagina,
        limit: tamPagina
    });

    // Devuelve todos los registros de usuario ordenados de forma ascendente por usuario
    const usuariosOrdenados = await Usuario.findAll({
        order: [['apellido', 'ASC']]
    });

    // Devuelve los datos de ambos modelos si estos estan relacionados
    const usuariosConDetalle = await Usuario.findAll({
        include: [{
            model: Perfil,
            as: 'perfil'
        }]
    });

    // funciones de agregacion:
    const totalUsuarios = await Usuario.count();
    const maxEdad = await Usuario.max('edad');
    const sumaEdades = await Usuario.sum('edad');

    // INNER JOIN
    const usuariosConPerfiRequerido = await Usuario.findAll({
        include: [{
            model: Perfil,
            as: 'perfil',
            required: true // Solo retorna en los que no sea null
        }]
    });

    /*
        Consultas SQL directas para situaciones especificas
    */
    const resultado = seq.query("SELECT * FROM usuarios WHERE edad > 30", { TYPE: QueryTypes.SELECT })

    // Manejo de transacciones
    await seq.transaction(async (t) => {
        const usuario = await Usuario.create({ nombre: 'Juan', apellido: 'Perez' }, { transaction: t });
        const perfil = await Perfil.create({ usuario: usuario, descripcion: 'Un usuario' }, { transaction: t });
    });

    /*
        Persistencia de datos
    */

    // Creacion o inserción
    const juan_perez = await Usuario.create({
        nombre: 'Juan',
        apellido: 'Perez',
        usuario: 'juanperez123',
    });

    // Actualizacion (modificacion)
    await Usuario.update({ apellido: 'Perez Garcia' }, { where: { usuario: 'juanperez123' } });

    // Eliminación
    const usuarioAEliminar = await Usuario.findOne({ where: { id: 1 } });
    await usuarioAEliminar.destroy();

    // Eliminación 2 (todos los registros que cumplan)
    Usuario.destroy({
        where: { id: 2 }
    });
}

main();