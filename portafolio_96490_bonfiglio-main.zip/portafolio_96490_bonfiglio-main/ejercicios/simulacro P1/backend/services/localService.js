import { Op } from "sequelize";
import { Local } from "../models/local.js";

export class ServicioLocal {
    async getLocalesArgentina() {
        return await Local.findAll({ where: { country: 'AR' } });
    }

    async getLocalesInterior() {
        return (await this.getLocalesArgentina()).filter(local => local.province != 'C' && local.province != 'B');
    }    

    async getLocalesInteriorQueryOp() {
        return await Local.findAll({
            where: {
                country: 'AR',
                province: {
                    [Op.notIn]: ['C', 'B']
                }
            }
        });
    }    
}