import express from "express";
import dotenv from "dotenv";
import cors from "cors";

import dbInit from "./data/db-init.js";

import { ServicioLocal } from "./services/localService.js";

dotenv.config();

const app = express();

app.use(cors());

app.get("/status", (req, res) => {
    res.json({ respuesta: "API iniciada y escuchando..." });
});

const servicio = new ServicioLocal();

(async function start() {
    const PORT = process.env.PORT || 3000;

    // Inicializar la conexión a la base de datos
    await dbInit();

    app.get('/locales', async (_, res) => {
        const locales = await servicio.getLocalesArgentina();
        if (locales) {
            res.json(locales);
        }
        res.end();
    })
    
    app.get('/locales/interior', async (_, res) => {
        const locales = await servicio.getLocalesInteriorQueryOp();
        if (locales) {
            res.json(locales);
        }
        res.end();
    })

    // Iniciar el servidor
    app.listen(PORT, () => {
        console.log(`Servidor iniciado y escuchando en el puerto ${PORT}`);
    });
}());
