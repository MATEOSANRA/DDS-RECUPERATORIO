const mostrarDatos = async (res) => {
    const datos = await res.json();
    const datosTabla = document.getElementById('datos');
    if (datosTabla) {
        let contenido = '';
        datos.forEach(local => {
            contenido += `
                <tr>
                    <th scope="row">${local.number}</th>
                    <td>${local.name}</td>
                    <td>${local.address}</td>
                    <td>${local.city}</td>
                    <td>${local.latitude}</td>
                    <td>${local.longitude}</td>
                </tr>
            `
        });

        datosTabla.innerHTML = contenido;
    }
}

const consultaLocales = async () => {
    const res = await fetch('http://localhost:3001/locales/');
    if (res) {
        mostrarDatos(res);
    }
}

const consultaSoloInterior = async () => {
    const res = await fetch('http://localhost:3001/locales/interior/');
    console.log('Hola');
    if (res) {
        mostrarDatos(res);
    }
}

const btnSoloInterior = document.getElementById('btn_solo_interior');

if (btnSoloInterior) {
    btnSoloInterior.addEventListener('click', consultaSoloInterior);
    console.log('Hola');
}

consultaLocales();