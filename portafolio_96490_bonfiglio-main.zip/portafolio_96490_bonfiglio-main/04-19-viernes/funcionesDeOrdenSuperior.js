// Podemos almacenar funciones en variables y constantes a modo de "renombrar" funciones
let imprimir = console.log;
let aleatorio = Math.random;
imprimir(aleatorio());

/*
    Definiendo funciones de esta forma podemos actualizar el proceso de la función y siempre que devuelva los mismos tipos de parámetros
    va a funcionar, esto es: escribir funciones da modularidad.
*/

// Funciones flecha, anonimas o lambda

/* 
    Las funciones flacha tienen una diferencia con respecto a las definidas con function: si forman parte de una clase,
    this en las funciones definidas con function se refieren a la clase, mientras que en las funciones flecha se refiere
    al bloque de codigo al que pertenece.
*/

/*
    Si una funcion se pasa como parametro o se retorna como resultado de otra función, esta constituye una función de orden superior
*/

let funcionFlecha = (parametro) => { console.log(parametro); };

// Ejemplo util

const cronometer = (f) => {
    const start = new Date();
    f();
    return new Date() - start;
}

// Funciones de orden superior en arreglos:

const v = [1, 2, 3, 4, 5, 6, 7, 8, 9];

// forEach
const recorrerVector = (v, f) => {
    v.forEach(element => {
        f(element);
    });
}

const pruebaForEachConMasParametros = () => {
    const v2 = [[1, 2], [3, 4], [5, 6]];
    // Esto guarda en a cada sublista y en b los indices
    v2.forEach((a, b) => {
        console.log('A: ', a, 'B: ', b);
    });
}

pruebaForEachConMasParametros();

// map [v.map(f: function)]
// Retorna un nuevo vector que es el resultado de aplicarle a cada elemento del vector v la funcion f
console.log('====================== MAP ======================')
console.log('Vector original:', v);
console.log('Vector mapeado: x => x * 2', v.map(x => x * 2));

// filter [v.filter(f: function))]
// Retorna un nuevo vector que contiene solo los elementos de v para los cuales f retornó true (f debe retornar un bool)
console.log('====================== FILTER ======================')
console.log('Vector original:', v);
console.log('Vector mapeado: x => x >= 5', v.filter(x => x >= 5));

// llamadas encadenadas
// Como ambas funciones devuelven otros vectores, se puede llamar a una de las funciones sobre el return de la otra
console.log('====================== MAP - FILTER ======================')
console.log('Vector original:', v);
console.log('Nuevo vector: filter [x => x > 5] | map [x => x / 2]', v.filter(x => x >= 5).map(x => x / 2));

// reduce [v.reduce(f: function)]
// f debe ser una función de dos parametros. Lo que va a devolver es un solo valor resultado de aplicar sobre los dos primeros
// elementos del vector la funcion f y reemplazarlos por el resultado de ejecutar f(a, b) donde a es el primer valor y b el segundo
// luego repite hasta que solo quede un valor.
console.log('====================== REDUCE ======================')
console.log('Vector original:', v);
console.log('reduce para suma:', v.reduce((x, y) => x + y));
console.log('reduce para mayor: ', v.reduce((x, y) => x > y ? x : y));

console.log('====================== REDUCE - FILTER ======================')
const v3 = [-1, -2, -3, -4, -5, 1, 2, 3, 4, 5];
console.log('Vector original:', v3);
console.log('Menor de los positivos:', v3.filter(x => x > 0).reduce((x, y) => x < y ? x : y));

// Otros metodos de orden superior son:
/*
    find: Devuelve el primer elemento del vector que cumpla una condición
    findIndex: Devuelve el indice del primer elemento del vector que cumpla una condición
    some: Devuelve true si al menos un elemento del vector satisface una condición
    every: DEvuelve true si todos los elementos del vector satisfacen una condición
*/
console.log('vector: ', v);
console.log('find: x % 2 == 0', v.find(x => x % 2 == 0));
console.log('findIndex: x % 2 == 0', v.findIndex(x => x % 2 == 0));
console.log('some: x % 2 == 0', v.some(x => x % 2 == 0));
console.log('every: x % 2 == 0', v.every(x => x % 2 == 0));