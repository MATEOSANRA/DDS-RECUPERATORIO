## Status code
Los codigos de estado se devuelven como información complementaria al response de una petición a modo que cada codigo representa si la peticion fue exitosa o no y por que lo fué

Status code 100: informativo
Status code 2**: Exito
* 200: Ok
* 201: Created
Status code 3**: Redirect
Status code 4**: Error del cliente
* 400: Bad request
* 401: Forbiden (no se puede leer un dato por alguna condicion)
* 403: Unauthorized (Sin permiso)
* 404: Not foud
Status cpde 5**: Error del servidor

## ORM: Object relation mapping
Nos permiten mapear una base de datos relacional a objetos definidos dentro de nuestro codigo. A su vez permite volcar objetos en relaciones que permanezcan en la base de datos. Esto nos permite poder seguir programando en objetos mientras que utilizamos una base de datos relacional.

El ORM que utilizaremos en JavaScript se llama **Sequelize**
