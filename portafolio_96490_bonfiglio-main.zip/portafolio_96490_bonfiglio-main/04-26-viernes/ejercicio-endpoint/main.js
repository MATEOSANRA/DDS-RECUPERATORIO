import express from 'express';
import data from './data/cp.json' with { type: 'json' };

const filtrarPorCodigo = (arreglo, codigo) => {
    return arreglo.filter(elemento => elemento.codigo_postal === codigo);
}

const verificarNuevoCodigo = (codigo) => {
    return codigo.codigo_postal && codigo.nombre_localidad && codigo.codigo_provincia;
}

const main = () => {
    const app = express();

    app.get('/cp', (request, response) => {
        response.status(200);
        response.send(data);
        response.end();
    });

    app.get('/cp/:codigo', (request, response) => {
        const codigo = parseInt(request.params.codigo);
        const res = filtrarPorCodigo(data, codigo);
        response.status(res.length === 0 ? 404 : 200)
        response.send(res.length === 0 ? 'ERROR 404: NOT FOUND.' : res);
        response.end();
    });

    app.post('/cp', (req, res) => {
        console.log(req.params);
        res.send('Hola');
        res.end();
    });
    
    app.listen(8081);
}

main();