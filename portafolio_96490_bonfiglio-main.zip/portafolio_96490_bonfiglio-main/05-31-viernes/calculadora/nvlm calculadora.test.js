const sumar = require('./calculadora.js');

test('Sumar 6 y 9: ', () => {
    const resultado = sumar(6, 9);
    expect(resultado).toBe(15);
})

test('Sumar -9 y 9: ', () => {
    const resultado = sumar(-9, 9);
    expect(resultado).toBe(0);
})