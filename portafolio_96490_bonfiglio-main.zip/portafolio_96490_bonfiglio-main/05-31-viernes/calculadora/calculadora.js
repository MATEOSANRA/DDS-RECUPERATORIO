const sumar = (s1, s2) => {
    return s1 + s2;
}

module.exports = sumar;