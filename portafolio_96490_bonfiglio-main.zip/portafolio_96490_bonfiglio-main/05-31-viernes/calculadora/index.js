const suma = require('./calculadora.js');

const s1 = suma(6, 9);
console.log(`La suma es: ${s1}`);