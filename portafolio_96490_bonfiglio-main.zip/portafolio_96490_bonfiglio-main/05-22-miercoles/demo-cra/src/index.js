import React from 'react';
// import ReactDOM from 'react-dom/client';
import { createRoot } from 'react-dom/client';
import App from './components/App';

const nombre = 'Franco';

createRoot(document.getElementById('root')).render(
    <App></App>
    // <>
    //     <h1>Titulo del sitio</h1>
    //     <h2>Bienvenido {nombre}</h2>
    //     <p>3 + 5 = {3+5}</p>
    // </>
);