import '../css/site.css'
/* 
    Esta funcion representa el elemento de react, el return es lo que se va a aplicar en el DOM cuando se llama desde otro componente
    raiz. Toma como parametro un objeto que contiene los argumentos que se pasaron (por medio de atributos en la etiqueta). Se puede
    asignar a una variable y luego acceder a los elementos, o "desempaquetarlo" como se hace a continuacion (Es muy importante 
    respetar los nombres)

    children: children es un parametro que recibe lo que se pasa como contenido dentro de la etiqueta, para este caso: 
    <Titulo>contenido</Titulo> "contenido" seria el valor de children, pudiendo contener html, texto, etc.
*/
export default function Titulo({color = 'rojo', children = 'N/D'}) {
    return (
        <h1 className={color}>{children}</h1>
    );
}