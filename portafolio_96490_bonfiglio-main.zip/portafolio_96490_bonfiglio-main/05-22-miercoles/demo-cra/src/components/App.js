import Titulo from "./Titulo"
export default function App() {
    return (
    <>
        <Titulo color='rojo'>React desde cero</Titulo>
        <Titulo color='azul'>Mi primer app con react</Titulo>
        <Titulo color='azul' />
    </>
    )
}