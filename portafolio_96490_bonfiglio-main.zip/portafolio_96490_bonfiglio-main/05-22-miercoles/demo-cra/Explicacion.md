## npx create-react-app "nombreCarpeta"
Este comando crea un proyecto base en react con todas las dependencias necesarias y scripts por defecto para ejecutar y trabajar con una aplicacion react.
