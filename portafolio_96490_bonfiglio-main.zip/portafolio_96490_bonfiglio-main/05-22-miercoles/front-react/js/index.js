const root = document.getElementById('root');

/* 
    React trabaja con un VirtualDOM dado que el DOM real es demasiado lento.
    Lo que hace es modificar un objeto de JS que es una copia del DOM en memoria
    y cuando se llama la función .render() envia solo las diferencias entre el DOM y
    el VDOM
*/

// Creamos un elemento de etiqueta <h1>, que tiene como contenido (childrens) el texto 'Primer Elemento'
// El objeto pasado como segundo parametro son las opciones, es decir los atributos html (por ej para utilizar bootstrap)
const elemento = React.createElement('h1', { style: { color: 'red' } }, 'Primer elemento');

// Creamos un boton con el texto Aceptar como contenido
const boton = React.createElement('button', { className: 'btn btn-outline-success' }, 'Aceptar');

// Creamos un div que servira como root para el documento, esto nos permite enviar ambos elementos al dom
const div = React.createElement('div', {}, [elemento, boton]);

// En lugar de crear un div, modemos utilizar un elemento propio de react que permite agrupar elementos bajo un mismo padre
// sin crear un elemento HTML adicional, lo cual puede no ser deseable.
const fragment = React.createElement(React.Fragment, {}, [elemento, boton]);

ReactDOM.createRoot(root).render(fragment);