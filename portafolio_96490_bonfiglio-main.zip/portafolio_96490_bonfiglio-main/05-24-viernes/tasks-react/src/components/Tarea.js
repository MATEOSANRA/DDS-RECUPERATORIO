import { useState } from 'react';

const Tarea = ({tarea, eliminarTarea}) => {
    const [realizada, setRealizada] = useState(tarea.realizada)
    let estilo = {
        textDecoration: realizada && 'line-through',
        color: realizada && 'red'
    }

    const handleEliminarTarea = (_) => {
        eliminarTarea(tarea.id);
    }

    return (
        <li>
            <div className='form-check'>
                <input className='form-check-input' type='checkbox' onChange={(e) => setRealizada(e.target.checked)} checked={ realizada ? 'checked' : '' } />
                <label className='form-check-label' style={estilo}>ID: {tarea.id} | Nombre: {tarea.nombre} | Realizada: { realizada ? 'Si': 'No' } </label>
                <button className="btn btn-outline-secondary" onClick={handleEliminarTarea}><i className='bi bi-trash3'></i></button>
            </div>
        </li>
    );
}

export default Tarea;