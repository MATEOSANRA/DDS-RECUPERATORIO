import { useState } from 'react';
import Agregar from './Agregar';
import Lista from './Lista';
import Titulo from './Titulo';

const Contenedor = () => {
    const [lista, setLista] = useState([]);

    const agregarTarea = (tarea) => {
        // lista.push(tarea);

        /* 
            El operador spread funciona desempaquetando un array en cada uno de sus elementos de forma separada
            de este modo, si:
                let a = [1, 2, 3]
                let b = [...a, 99]
                ** b = [1, 2, 3, 99] ** 
        */
        setLista([...lista, tarea]); // El operador ... descompone una lista en todos sus elementos (es como desempaquetar)
        
    }
    
    const eliminarTarea = (id) => {
        setLista(lista.filter(t => t.id !== id));
    }

    return (
        <div className='container col-md-8 text-center'>
            <Titulo>Lista de tareas</Titulo>
            <Agregar agregarTarea={agregarTarea} />
            <Lista lista={lista} eliminarTarea={eliminarTarea} />
        </div>
    );
}

export default Contenedor;