import { useState } from 'react';
import Tarea from './Tarea';

const Lista = ({lista, eliminarTarea}) => {
    // Todo elemento hijo de una lista necesita tener un atributo key con valor unico, por ello en el map
    // podemos utilizar un indice (index) y se lo asignamos a cada elemento que se vaya a crear de tipo tarea
    // en este caso asignamos como key el id de la tarea para evitar problemas al eliminar las tareas
    return (
        <ul className='row list-unstyled text-start'>
            {lista.map(t =>  <Tarea key={t.id} tarea={t} eliminarTarea={eliminarTarea} /> )}
        </ul>
    );
}

export default Lista;