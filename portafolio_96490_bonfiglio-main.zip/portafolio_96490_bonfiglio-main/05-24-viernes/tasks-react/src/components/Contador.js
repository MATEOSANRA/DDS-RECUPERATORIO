// Para que se actualice el dom con cada click
import { useState } from "react";

const Contador = () => {
    // retorna un array con dos elementos la variable que queremos tomar como parametro y una funcion que utilizaremos para
    // actualizarla.
    const [contador, setContador] = useState(0);
    const incrementar = () => {
        // Ejecutamos la funcion y le pasamos como parametro el nuevo valor para la variable.
        setContador(contador + 1);
    }

    return (
        <>
            <button className="btn btn-outline-success" onClick={incrementar}>Presionado {contador} veces</button>
        </>
    );
}

export default Contador;