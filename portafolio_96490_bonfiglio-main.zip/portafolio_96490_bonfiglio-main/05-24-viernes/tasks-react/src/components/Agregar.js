import { useState } from 'react';

const Agregar = ({agregarTarea}) => {
    const [nombre, setNombre] = useState('');

    // el parametro event trae toda la información del evento, en este caso es el onChange del input
    const actualizarNombre = (event) => {
        setNombre(event.target.value);
    }

    const handleSubmit = (e) => {
        e.preventDefault();
        agregarTarea({ id: window.crypto.randomUUID(), nombre: nombre, realizada: false });
        setNombre('');
    } 

    return (
        <form onSubmit={handleSubmit}>
            <div className='input-group mt-5 mb-5'>
                <input type='text' placeholder='Nueva tarea...' onChange={actualizarNombre} value={nombre} className='form-control'></input>
                <button className='btn btn-outline-success' disabled={!nombre}>Agregar Tarea</button>
            </div>
        </form>
        
    );
}

export default Agregar;