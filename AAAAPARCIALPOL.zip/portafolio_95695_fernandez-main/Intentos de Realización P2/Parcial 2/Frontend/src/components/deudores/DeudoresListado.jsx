import React from "react";
import moment from "moment";

export default function DeudoresListado({
  Items,
  Consultar,
  Modificar,
  ActivarDesactivar
}) {
  return (
    <div className="table-responsive">
      <table className="table table-hover table-sm table-bordered table-striped">
        <thead>
          <tr>
            <th className="text-center">Apellido y Nombre</th>
            <th className="text-center">Fecha deuda</th>
            <th className="text-center">Importe</th>
          </tr>
        </thead>
        <tbody>
          {Items &&
            Items.map((Item) => (
              <tr key={Item.IdDeudor}>
                <td>{Item.ApellidoYNombre}</td>
                <td className="text-end">
                  {moment(Item.FechaDeuda).format("DD/MM/YYYY")}
                </td>
                <td className="text-end">{Item.ImporteAdeudado}</td>
              </tr>
            ))}
        </tbody>
      </table>
    </div>
  );
}
