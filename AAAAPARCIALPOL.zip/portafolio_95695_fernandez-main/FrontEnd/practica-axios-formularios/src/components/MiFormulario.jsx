// import { useForm } from 'react-hook-form';
// import '../estilos/Formularios.css'

// function MiFormulario() {
//   const { register, handleSubmit, formState: { errors } } = useForm()

//   const onSubmit = (data) => {
//     console.log('Datos del formulario:', data);
//   }

//   return (
//     <form onSubmit={handleSubmit(onSubmit)}>
//       <label htmlFor="name">Nombre:</label>
//       <input
//         id="name"
//         type="text"
//         {...register('name', { required: 'El campo nombre es requerido' })}
//       />
//       {errors.name && <p>{errors.name.message}</p>}
//       <br />
//       <label htmlFor="email">Correo electrónico:</label>
//       <input
//         id="email"
//         type="email"
//         {...register('email', { required: 'El campo correo electrónico es requerido' })}
//       />
//       {errors.email && <p>{errors.email.message}</p>}
//       < br />
//       <button type="submit">Enviar</button>
//     </form>
//   );
// }

// export default MiFormulario;


import { useForm } from 'react-hook-form';

function MiFormulario() {
  const { register, handleSubmit, formState } = useForm();
  const { isDirty, isValid, isSubmitting, isSubmitted, errors, touchedFields } = formState;

  // Función que devuelve una promesa que se resuelve después de una demora específica
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const onSubmit = async (data) => {
    console.log('Datos del formulario:', data);
    // Simular una demora de 3 segundos usando await y sleep
    await sleep(3000);
    console.log('Formulario enviado después de 3 segundos');
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <label htmlFor="name">Nombre:</label>
      <input
        id="name"
        type="text"
        {...register('name', { required: 'El campo nombre es requerido' })}
      />
      {errors.name && touchedFields.name && <p>{errors.name.message}</p>}
      <br />
      <label htmlFor="email">Correo electrónico:</label>
      <input
        id="email"
        type="email"
        {...register('email', {
          required: 'El campo correo electrónico es requerido'
        })}
      />
      {errors.email && touchedFields.email && <p>{errors.email.message}</p>}
      < br />
      <button type="submit" disabled={!isValid || isSubmitting}>
        {isSubmitting ? 'Enviando...' : 'Enviar'}
      </button>
      {isDirty && isSubmitted && !isValid && <p>Por favor, completa correctamente
        todos los campos.</p>}
      {isValid && isSubmitted && < p > Felicidades!!!</p>}
    </form >
  );
}
export default MiFormulario;