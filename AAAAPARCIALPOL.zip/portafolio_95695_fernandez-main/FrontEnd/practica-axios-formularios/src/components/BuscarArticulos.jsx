import { useState, useEffect } from 'react';
import { articulosService } from '../services/articulos.service';

const BuscarArticulos = () => {
  const [data, setArticulos] = useState(null);

  useEffect(() => {
    async function BuscarArticulos() {
      let data = await articulosService.BuscarTodos();
      setArticulos(data);
    }
    BuscarArticulos();
  }, []);

  return (
    <div>
      {data ? (
        <table>
          <thead>
            <tr>
              <th>Articulo</th>
              <th>Precio</th>
            </tr>
          </thead>
          <tbody>
            {data.map((element) => (
              <tr key={element.IdArticulo}>
                <td>{element.Nombre}</td>
                <td>${element.Precio}.00</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p>Cargando datos...</p>
      )}
    </div>
  );
};

export default BuscarArticulos;