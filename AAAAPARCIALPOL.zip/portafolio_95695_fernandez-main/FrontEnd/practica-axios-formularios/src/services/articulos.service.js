import axios from 'axios';
const API_BASE_URL = 'https://labsys.frc.utn.edu.ar/dds-express/api'; //URL de ejemplo

async function BuscarTodos() {
  try {
    const response = await axios.get(`${API_BASE_URL}/articulos`);
    return response.data;

  } catch (error) {
    console.error('Error al obtener los datos:', error);
    throw error;
  }
}

async function Grabar(item) {
  if (item.IdArticulo === 0) {
    await axios.post(`${API_BASE_URL}/articulos`, item);
  } else {
    await axios.put(`${API_BASE_URL}/articulos/${item.IdArticulo}`, item);
  }
}

async function Baja(item) {
  await axios.delete(`${API_BASE_URL}/articulos/${item.IdArticulo}`);
}

export const articulosService = {
  BuscarTodos, Grabar, Baja
}