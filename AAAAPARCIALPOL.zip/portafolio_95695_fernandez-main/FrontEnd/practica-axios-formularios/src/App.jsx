import { useState } from 'react'
import BuscarArticulos from './components/BuscarArticulos'
import MiFormulario from './components/MiFormulario'
import './App.css'

function App() {
  const [mountedArticles, setMountedArticles] = useState(false)

  return (
    <>
      <h1>Prueba Axios y Formularios</h1>
      <section>
        <button onClick={() => { setMountedArticles(!mountedArticles) }}>Presiona para {mountedArticles ? 'ocultar' : 'mostrar'} los articulos</button>
        {mountedArticles && <BuscarArticulos />}
      </section>
      <section>
        <MiFormulario />
      </section>
    </>
  )
}

export default App
