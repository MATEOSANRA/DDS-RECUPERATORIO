let miArray = [3, 5, 7];
console.log(miArray);
miArray.push(33);
miArray.forEach((valor) => console.log("elemento: " + valor));