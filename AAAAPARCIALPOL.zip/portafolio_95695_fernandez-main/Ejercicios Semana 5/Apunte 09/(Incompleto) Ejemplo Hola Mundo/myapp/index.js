const express = require("express"); //Importamos módulo Express
const app = express();
const port = 3000;

app.get("/", (req, res) => { //Solo responde a las solicitudes HTTP GET con la URL especificada
  res.send("Hello World!");
});
/*Se crea servidor app que escucha las peticiones HTTP del puerto 3000
e imprime un mensaje en la consola que indica que URL del navegador
se puede usar para testear el servidor*/
app.listen(port, () => { 
  console.log(`Example app listening on port ${port}!`);
});
