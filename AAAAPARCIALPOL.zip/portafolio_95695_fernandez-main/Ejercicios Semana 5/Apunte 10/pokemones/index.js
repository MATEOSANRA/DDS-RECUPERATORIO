const pokemones = fetch("https://pokeapi.co/api/v2/pokemon/1");

/* 
pokemones.then(res => res.json())
    .then(data => {
        console.log(data.name);
    }).catch(error => console.log(error))
*/

pokemones
    .then(poke => {
        return poke.json()
    })
    .then(data => {
        console.log(data.name);
    })
    .catch(error => {
        return console.log(error)
    });
  
//Obtenemos 5 pokemones ordenados y síncronos
function obtener_pokemon(id){
    let url = "https://pokeapi.co/api/v2/pokemon/" + id;
    return fetch(url).then(res => {return res.json()});
}

obtener_pokemon(1).then(data => {
    console.log(data.name);
    return obtener_pokemon(2);
}).then(data =>{
    console.log(data.name);
    return obtener_pokemon(3);
}).then(data =>{
    console.log(data.name);
    return obtener_pokemon(4);
}).then(data =>{
    console.log(data.name);
    return obtener_pokemon(5);
}).then(data =>{
    console.log(data.name);
})

