/*
Desarrollar un programa Javascript que genere 1000000 de números aleatorios enteros. Para 
ello debe utilizarse la librería seedrandom y al hacerlo debe utilizar como semilla el 
número: 1763519 y obtener cada siguiente número aleatorio con llamadas al método int32.
*/
const seedrandom = require('seedrandom');
//const seed = 1763519;
const rng = seedrandom(1763519);

let cantNumRandom = 1000000;
const numAleatorios = [];

for (let i=0; i < cantNumRandom; i++){
    num = rng.int32();
    numAleatorios.push(num);
};
//const numAleatorios = Array.from({ length: 1000000 }, () => rng.int32());

// Consigna N°1
/*Cantidad de números positivos y cantidad de números negativos.*/
let positivos = 0
let negativos = 0

numAleatorios.forEach(num => {
    if (num > 0){
        positivos += 1;
    }
    else if (num < 0){
        negativos += 1;
    }
});

console.log("Consigna N°1:")
console.log(`Positivos: ${positivos}`);
console.log("Negativos: " + negativos);

// Consigna N°2
/*Cantidad de números cuyo resto al dividirlos en 7 sea exactamente 0, 3, 5 o 6.*/
/*
const numRestoCero = numAleatorios.filter(num => (num % 7) === 0);
console.log(numRestoCero.length);
const numRestoTres = numAleatorios.filter(num => (num % 7) === 3);
console.log(numRestoTres.length);
const numRestoCinco = numAleatorios.filter(num => (num % 7) === 5);
console.log(numRestoCinco.length);
const numRestoSeis = numAleatorios.filter(num => (num % 7) === 6);
console.log(numRestoSeis.length);
let numDivSiete = numRestoCero.length + numRestoCinco.length + numRestoTres.length + numRestoSeis.length;
console.log(numDivSiete);
*/
const numDivSieteA = numAleatorios.filter(num => (num % 7) === 0 || (num % 7) === 3 || (num % 7) === 5 || (num % 7) === 6).length;
console.log("\nConsigna N°2:")
console.log("Cantidad de números cuyo resto al dividirlos por 7 sea 0, 3, 5, 6: " + numDivSieteA);

// Consigna N°3
/*Un arreglo de contadores que indique la cantidad de números según su anteúltimo dígito 
(el de las decenas) coincida con el índice. De esta manera el número 2134 debe contarse en la 
posición 3 del arreglo, el número 32405 en la posición 0 del arreglo y así sucesivamente. 
Evidentemente el arreglo va a ser de 10 contadores con índices del 0 al 9 y deberá ser cargado 
usando llaves y valores separados por comas.*/

const contadorIndice = new Array(10).fill(0);

/*
contadorIndice.forEach((cont, i) => {
    console.log(cont)
    for (let numero in numAleatorios){
        let anteUltimo = parseInt(numero.toString().charAt(numero.toString().length - 2));
        if (anteUltimo === i){
            cont++;
        }
    }
    console.log(cont)
    console.log(`Cantidad de números cuyo ante utlimo número es igual a ${i}: ${cont}`);
});
*/

numAleatorios.forEach(numero =>{
    let anteUltimo = parseInt(numero.toString().charAt(numero.toString().length - 2));
    contadorIndice[anteUltimo]++;
})

console.log("\nConsigna N°3:")
contadorIndice.forEach((cont,i) => {
    console.log(`Cantidad de números cuyo ante utlimo número es igual a ${i}: ${cont}`);
})
console.log(contadorIndice);

// Consigna N°4
/*Valor y posición del menor de todos. La posición del primer número generado debe considerarse 
como 1, es decir no se pide el índice del valor en el arreglo sino el número de orden del mismo.*/

let menor = {num: null, orden: null};
numAleatorios.forEach((numero,i) => {
    /*let menor = new Object();
        menor.num = null;
        menor.orden = null;*/

    if (i === 0){
        menor.num = numero;
        menor.orden = i + 1;
    }

    else if (menor.num > numero){
        menor.num = numero;
        menor.orden = i + 1;
    }

});

console.log("\nConsigna N°4:");
console.log(`Menor número: ${menor.num}; Número de Orden: ${menor.orden}`);

// Consigna N°5
/*Cantidad de números cuyo signo sea igual al del anterior, evidentemente el primer elemento del 
conjunto no puede ser contabilizado porque no tiene anterior, es decir el máximo posible es la 
cantidad de elementos generados menos 1.*/

function positivosYNegativos(anterior){
    let positivos = 0;
    let negativos = 0;
    numAleatorios.forEach(numero => {
        if (numero > 0 && anterior > 0){
            positivos++;
        }
        else if (numero < 0 && anterior < 0){
            negativos++;
        }
        anterior = numero;
    });
    return {positivos, negativos}
}

let negativo = positivosYNegativos(0).negativos;
let positivo = positivosYNegativos(0).positivos;

console.log("\nConsigna N°5:");
console.log("Cantidad de números positivos cuyo numero anterior también fue positivo: " + positivo);
console.log("Cantidad de números negativos cuyo numero anterior también fue negativo: " + negativo);
console.log("Cantidad total: " + (positivo + negativo));

// Consigna N°6
/*Promedio entero (redondeado con Math.round) de todos los números que contengan exactamente 6 dígitos.*/

let sumatoria = 0;
let contador = 0;
numAleatorios.forEach(numero => {
    if (100000 <= numero && numero < 1000000){
        sumatoria = sumatoria + numero;
        contador += 1;
    }
    else if (-1000000 < numero && numero <= -100000){
        sumatoria = sumatoria + numero;
        contador += 1;
    }
})

let promedio = Math.round(sumatoria / contador);
console.log("\nConsigna N°6:");
console.log("Promedio: " + promedio);