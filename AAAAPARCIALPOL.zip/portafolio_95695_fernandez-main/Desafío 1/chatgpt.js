// Importar la librería seedrandom
const seedrandom = require('seedrandom');

// Semilla para generar números aleatorios
const seed = '1763519';
const rng = seedrandom(seed);

// Generar 1,000,000 de números aleatorios enteros
const cantidadNumerosAleatorios = 1000000;
const numerosAleatorios = [];
for (let i = 0; i < cantidadNumerosAleatorios; i++) {
    numerosAleatorios.push(rng.int32());
}

// Inicializar contadores y variables
let cantidadPositivos = 0;
let cantidadNegativos = 0;
let contadoresResto = [0, 0, 0, 0]; // Para resto 0, 3, 5, 6
let contadoresAnteultimoDigito = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; // Para los dígitos del 0 al 9
let menorNumero = numerosAleatorios[0];
let posicionMenorNumero = 1;
let cantidadMismoSignoAnterior = 0;
let sumaNumerosCon6Digitos = 0;
let cantidadNumerosCon6Digitos = 0;

// Iterar sobre los números generados
numerosAleatorios.forEach((numero, index) => {
    // Actualizar cantidad de positivos y negativos
    if (numero > 0) {
        cantidadPositivos++;
    } else if (numero < 0) {
        cantidadNegativos++;
    }

    // Actualizar contadores según el resto de la división por 7
    const resto = Math.abs(numero) % 7;
    if (resto === 0 || resto === 3 || resto === 5 || resto === 6) {
        contadoresResto[resto]++;
    }

    // Actualizar contadores según el anteúltimo dígito
    let anteultimoDigito = obtenerAnteultimoDigito(numero);
    if (anteultimoDigito >= 0 && anteultimoDigito <= 9) {
        contadoresAnteultimoDigito[anteultimoDigito]++;
    }

    // Actualizar menor número y su posición
    if (numero < menorNumero) {
        menorNumero = numero;
        posicionMenorNumero = index + 1;
    }

    // Contar cantidad de números con el mismo signo que el anterior
    if (index > 0 && Math.sign(numero) === Math.sign(numerosAleatorios[index - 1])) {
        cantidadMismoSignoAnterior++;
    }

    // Actualizar suma de números con 6 dígitos
    if (numero >= 100000 && numero <= 999999) {
        sumaNumerosCon6Digitos += numero;
        cantidadNumerosCon6Digitos++;
    }
});

// Calcular promedio entero de números con 6 dígitos
let promedioNumerosCon6Digitos = Math.round(sumaNumerosCon6Digitos / cantidadNumerosCon6Digitos);

// Función para obtener el anteúltimo dígito de un número
function obtenerAnteultimoDigito(numero) {
    let cadenaNumero = Math.abs(numero).toString();
    if (cadenaNumero.length >= 2) {
        return parseInt(cadenaNumero.charAt(cadenaNumero.length - 2));
    }
    return -1; // Si el número no tiene al menos dos dígitos, retorna -1
}

// Mostrar resultados
console.log("Cantidad de números positivos:", cantidadPositivos);
console.log("Cantidad de números negativos:", cantidadNegativos);
console.log("Contadores de números según resto de la división por 7:", contadoresResto);
console.log("Contadores de números según su anteúltimo dígito:", contadoresAnteultimoDigito);
console.log("Menor número:", menorNumero, "en la posición:", posicionMenorNumero);
console.log("Cantidad de números cuyo signo es igual al del anterior:", cantidadMismoSignoAnterior);
console.log("Promedio entero de números con exactamente 6 dígitos:", promedioNumerosCon6Digitos);
