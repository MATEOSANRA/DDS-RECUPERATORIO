const cargarMuseos = () => {
   fetch('http://localhost:3000/museos')
      .then(res => res.json())
      .then(museos => {
         let contenidoT = '';
         for (let museo in museos) { //let museo of museos para muestra mejor
            contenidoT += 
            `<tr>
               <td>${museos[museo].nombre}</td>
               <td>${museos[museo].ubicacion}</td>
               <td>${museos[museo].exposiciones}</td>
               <td>${museos[museo].horarios}</td>
               <td>${museos[museo].precioEntrada}</td>
            </tr>`
            //Utilizamos DOM
            document.getElementById('lista-museos'). //Referenciamos tabla
            innerHTML = contenidoT; //Añadimos a la tabla el contenidoT
         }
      })
      .catch(error => {
         console.log("ERROR: ", error)
      })
};