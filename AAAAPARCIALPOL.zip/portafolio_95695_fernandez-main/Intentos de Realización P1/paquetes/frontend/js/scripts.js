const apiUrl = 'http://localhost:3000/paquetes'; // Reemplaza con la URL de tu API

// Función para cargar la grilla de paquetes
function cargarPaquetes() {
    fetch(apiUrl)
        .then(res => res.json()) //Parseamos
        .then(paquetes => {
            let filas = ''
            paquetes.forEach(paquete => {
                filas += 
                    `<tr>
                        <td>${paquete.destino}</td>
                        <td>${paquete.duracion}</td>
                        <td>${paquete.precio}</td>
                        <td>${paquete.descripcion}</td>
                        <td><button onclick="eliminarPaquete(${paquete.id})">X</button></td>
                    </tr>`;
            });
            document.getElementById('lista-paquetes').innerHTML = filas;
        })
}

// Función para buscar paquetes por descripción
function buscarPaquetes() {
    let destino = document.getElementById('buscar-input').value;
    //console.log(apiUrl + '/' + destino); Gracia mi a mo
    fetch(apiUrl + '/' + destino)
        .then(res => res.json())
        .then(paquetes=> {
            let filas = ''
            paquetes.forEach(paquete => {
                filas += 
                    `<tr>
                        <td>${paquete.destino}</td>
                        <td>${paquete.duracion}</td>
                        <td>${paquete.precio}</td>
                        <td>${paquete.descripcion}</td>
                        <td><button onclick="eliminarPaquete(${paquete.id})">X</button></td>
                    </tr>`;
            });
            document.getElementById('lista-paquetes').innerHTML = filas;
        })
}

// Función para agregar un nuevo paquete
function agregarPaquete() {
    const destino = document.getElementById('in-destino').value;
    const duracion = document.getElementById('in-duracion').value;
    const precio = document.getElementById('in-precio').value;
    const descripcion = document.getElementById('in-desc').value;

    const paquete = {
        destino: destino,
        duracion: duracion,
        precio: precio,
        descripcion: descripcion
    }

    fetch(apiUrl, {
        method: 'POST',
        headers: {
            //Parte de la petición HTTP. Le informa al servidor el tipo de dato que le estamos enviando
            //en este caso, información de tipo JSON
            'Content-Type': 'application/json' 
        },
        body: JSON.stringify(paquete),
         })
        .then(res => {
            if (res.ok){
                document.getElementById('in-destino').value = '';
                document.getElementById('in-duracion').value = '';
                document.getElementById('in-precio').value = '';
                document.getElementById('in-desc').value = '';
                cargarPaquetes()
            }
            else{
                alert("Error al cargar paquete")
            }
        });
}

// Función para eliminar un paquete
function eliminarPaquete(id) {
    fetch(apiUrl + '/' + id, {
            method: 'DELETE'
        })
        .then(res => {
            if (res.ok){
                console.log(res)
                alert("Se ha eliminado exitosamente")
                cargarPaquetes()
            } else {
                alert("No se ha podido eliminar el paquete");
            }
        })
}

// Cargar la lista de paquetes al cargar la página
cargarPaquetes();