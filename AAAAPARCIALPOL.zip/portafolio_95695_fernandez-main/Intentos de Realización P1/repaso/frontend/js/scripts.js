const apiUrl = 'http://localhost:3000/museos'

const cargarLibros = () => {
    let filas = '';
    fetch(apiUrl)
        .then(res => res.json())
        .then(museos => {
            museos.forEach(museo => {
                filas +=
                `<tr>
                    <td>${museo.titulo}</td>
                    <td>${museo.autor}</td>
                    <td>${museo.genero}</td>
                    <td>${museo.editorial}</td>
                    <td>${museo.año_publicacion}</td>
                </tr>`
            });
            document.getElementById("lista-museos").innerHTML = filas
        })
}

const buscarMuseos = () => {
    let filas = '';
    const url = apiUrl + "/" + document.getElementById('buscar-input').value;
    fetch(url)
        .then(res => res.json())
        .then(museos => {
            museos.forEach(museo => {
                filas +=
                `<tr>
                    <td>${museo.titulo}</td>
                    <td>${museo.autor}</td>
                    <td>${museo.genero}</td>
                    <td>${museo.editorial}</td>
                    <td>${museo.año_publicacion}</td>
                </tr>`
            });
            document.getElementById("lista-museos").innerHTML = filas
        })
}

cargarLibros()