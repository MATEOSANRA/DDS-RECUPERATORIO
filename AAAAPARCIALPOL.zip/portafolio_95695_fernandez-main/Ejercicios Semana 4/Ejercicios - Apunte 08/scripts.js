/* 
Se pide crear una página HTML para administrar una lista de tareas pendientes. 
Debe haber un formulario con un campo de entrada de texto para agregar 
nuevas tareas y un botón para añadirlas a la lista. Además, cada tarea en
la lista debe tener un botón para eliminarla. La página debe mostrar 
inicialmente una lista vacía y permitir al usuario agregar y eliminar 
tareas según sea necesario.
*/

//Array que contendrá cada nota
let notas = [
    {numero: '-', nota: '-', eliminar: '-'}
];

function ocultar(){
    document.getElementById("alerta").style.display = "none";
};

function nuevo(){
    document.getElementById("nuevaNota").value = ''
};

function eliminarNota(boton){
    //nota es igual al padre del padre del boton
    let nota = boton.parentNode.parentNode;
    //con querySelector('td').textContent accedo al contenido de la primer columna
    let numero = nota.querySelector('td').textContent;
    notas.splice(numero-1, 1);
    if (notas.length === 0){
        mostrar();
        return
    };
    notas.forEach((nota,i) => {
        nota.numero = ++i;
    })
    console.log(numero);
    mostrar();
};

function mostrar(){
    let fila = '';
    //Buscamos cada elemento del array para concatenarlo con fila
    notas.forEach(n => {
       fila += `<tr>
                    <td class="num" colspan="1">${n.numero}</td>
                    <td colspan="10">${n.nota}</td>
                    <td colspan="1">${n.eliminar}</td>
                </tr>`;
    });

    document.getElementById("tablita").innerHTML = fila;
    nuevo();
}

function agregarNota(){
    let numero = notas.length + 1;
    let nota = document.getElementById("nuevaNota").value;
    let eliminar = `<button type="button" class="btn-close" onclick="eliminarNota(this)"></button>`;
    //Pequeña validación para que se muestre una advertencia si no se rellena caja al agregar
    let estado = document.getElementById("alerta");
    if (nota === ''){
        if (estado.style.display === "none"){
            estado.style.display = "block";
            return
        };
        estado.setAttribute("style", "display: block");
        return
    };

    if(estado.style.display === "block"){
        ocultar();
    };

    if (notas.length === 1 && notas[0].numero === '-'){
        notas.pop();
        numero--;
    };

    notas.push({
        numero: numero,
        nota: nota,
        eliminar: eliminar,
    });
    mostrar();
}


