
// se necesita inicializarce primero
const readlineSync = require("readline-sync");
anio = Number(readlineSync.question("Ingrese un anio: "));

if (anio % 4 === 0){
    if (anio % 100 === 0){
        if (anio % 400 === 0){
            console.log(`${anio} es anio bisiesto :-)`);
        }
    }
}
else{
    console.log(`${anio} NO es bisiesto :-(`);
}


