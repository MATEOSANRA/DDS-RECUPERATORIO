const readlineSync = require("readline-sync");
frase = readlineSync.question("Ingrese una frase (termine con un punto): ");
let caja = '';
let pal = 0;
let mayor = 0;
let resta = 0;
let palabra = '* ';
let tapa = '';
let bandera = true;

for (let i=0; i <frase.length; i++){
    if (frase[i] === ' ' || frase[i] === '.'){
        if (mayor === 0) {
            mayor = pal;
        }
        else {
            if (mayor < pal) {
                mayor = pal;
            }
        }
        pal = 0;
    }
    else {
        pal = pal + 1;
    }
}

//Tapa superior
for (let i=0; i < mayor; i++){
    tapa = tapa + '*'
}
tapa = tapa + '****'
caja = tapa + '\n'

//Contenido de la caja
for (let i=0; i < frase.length; i++){
    if (frase[i] === ' ' || frase[i] === '.'){
        //Utilizo mas 2 porque también se incluye en palabra.length el blanco que se añade al terminar de ejecutar este if
        resta = (mayor + 3) - palabra.length;
        caja = caja + palabra;
        for (let i=0; i < resta; i++){
            caja = caja + ' ';
        }
        caja = caja + "*\n"
        palabra = '* '
    }
    else{
        palabra = palabra + frase[i]
    }
}
//Tapa inferior
caja = caja + tapa

console.log(caja)

