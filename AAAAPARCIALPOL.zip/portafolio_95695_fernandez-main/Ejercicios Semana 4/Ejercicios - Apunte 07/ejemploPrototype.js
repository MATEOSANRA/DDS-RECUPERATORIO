const persona = new Object (value, {
    nombre: 'Sergio',
    edad: 25,
    salido: function (){
        console.log("Hola!")
    }
})