/*
Crear un array con al menos 8 personas. Usar la clase persona previamente definida.
Definir funciones que reciban como argumento el array vuelvan:
1- Personas mayores de edad: mayoresDeEdad(personas)
2- Persona cuya profesión sea una pasada por argumento, ej: personasXProfesion(personas, 'superheroe')
3- obtenerPersonaMasGrande(personas), tener en cuenta que ahora recibe como argumento un array con n personas.
4- obtenerProfesiones(personas). // sin duplicados
*/ 
class Persona {

    constructor(nombre, correo, profesion, fechaNacimiento) {
        this.nombre = nombre;
        this.correo = correo;
        this.profesion = profesion;
        this.fechaNacimiento = fechaNacimiento;
    }

    saludar() {
        console.log('Hola soy ' + this.nombre);
    }

    edad() {
        const hoy = new Date();
        return hoy.getFullYear() - this.fechaNacimiento.getFullYear();
    }
}

const persona1 = new Persona('Juan', 'juan@gmail.com', 'Arquitecto', new Date(1985, 5, 15));
const persona2 = new Persona('María', 'maria@gmail.com', 'Abogada', new Date(1988, 3, 20));
const persona3 = new Persona('Carlos', 'carlos@gmail.com', 'Médico', new Date(1979, 10, 10));
const persona4 = new Persona('Ana', 'ana@gmail.com', 'Ingeniera de software', new Date(1995, 7, 25));
const persona5 = new Persona('Luis', 'luis@gmail.com', 'Diseñador gráfico', new Date(1983, 11, 5));
const persona6 = new Persona('Laura', 'laura@gmail.com', 'Profesora', new Date(1976, 1, 30));
const persona7 = new Persona('Mario', 'mario@gmail', 'Ingeniero químico', new Date(1990,9,1));
const persona8 = new Persona('Carla', 'carla@gmail.com', 'Ingeniero en Sistemas de Información', new Date(2012, 9, 1));

let personas = [
    {persona1},
    {persona2},
    {persona3},
    {persona4},
    {persona5},
    {persona6},
    {persona7},
    {persona8}
]
console.log(personas.persona1.edad())
personas.forEach(persona => {
    if (persona.edad() >= 18){
        console.log(persona.nombre, persona.edad())
    }
});