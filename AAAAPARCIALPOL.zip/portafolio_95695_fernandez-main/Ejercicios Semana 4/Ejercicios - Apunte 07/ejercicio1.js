/*Práctica 3.1: Se ha solicitado un script que permita cargar las precipitaciones 
promedio en cada mes del país (en nuestro caso serán generadas de manea aleatorias 
con valores comprendidos entre [15;35]º), en base a esos datos determinar:

el promedio anual de lluvias
el promedio de lluvias para el segundo semestre del año
el mes más seco del año
Práctica 3.1.js */

let min = 15;
let max = 35;
let lluviaAnual = 0;
let lluviaSegSem = 0;
let menor = {numero: 0, indice: null};
const promLluvia = new Array(12);

function mesMasSeco(lluviaMes, menor, iactual, imenor){
    if (menor === 0){
        // Cuando se retorna, hay que tener concordancia con los nombres de las propiedades
        return {numero: lluviaMes, indice: iactual}
    }
    else if (menor < lluviaMes){
        return {numero: menor, indice: imenor}
    }
    else{
        return {numero: lluviaMes, indice: iactual}
    };
};

//Se podría haber añadido en vez de un forEach unos acumuladores en este ciclo for
for (let i=0; i < 12; i++){
    let  lluvia = (Math.random() * (max - min) + min).toFixed(2);
    promLluvia[i] = lluvia;
};

console.log("(-) Lista de promedio mensual de lluvias en Argentina:");
promLluvia.forEach((lluvia,i) => {
    console.log(`Mes ${i+1}: ${lluvia}`);
    lluviaAnual += Number(lluvia);
    menor = mesMasSeco(Number(lluvia),menor.numero, i, menor.indice);
    if (i > 5){
        lluviaSegSem += Number(lluvia);
    };
});

let promAnual = (lluviaAnual / 12).toFixed(2);
console.log(`\n(-) Promedio anual de lluvias: ${promAnual}`);

let promSegSem = (lluviaSegSem / 6).toFixed(2);
console.log(`(-) Promedio del segundo semestre de lluvias: ${promSegSem}`);

console.log(`(-) Mes mas seco: ${menor.indice+1}`);

