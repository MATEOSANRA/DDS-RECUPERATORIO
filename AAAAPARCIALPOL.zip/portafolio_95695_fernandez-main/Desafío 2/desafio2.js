 //Importamos readFile para leer el archivo JSON como un vector de objetos
import { readFile } from 'fs/promises';

function leerJSON(personasJS){
    return readFile(personasJS, 'utf-8')
        //Vamos a convertir a personasJS de formato JSON a un vector de objetos (personas)
        .then(personas => JSON.parse(personas))
};


// #1
function promedioEdades(personas){
    let edadSum = 0;
    personas.forEach(persona => {
        edadSum += persona.edad;
    })

    return "Promedio Entero de Edades: " + Math.round(edadSum / personas.length, 0)
};


// #2
function primerPersonaMasJoven(personas){
    let personaMenor = {nombre: null, apellido: null, edad: null}

    personas.forEach(persona => {
        if (personaMenor.edad === null){
            personaMenor = persona;
        }
        else if (personaMenor.edad > persona.edad){
            personaMenor = persona;
        }
        else{
            personaMenor = personaMenor
        }
    })

    return `Nombre: ${personaMenor.nombre}; Apellido: ${personaMenor.apellido}; Edad: ${personaMenor.edad}`
};


// #3 
function gomezOrdenados(personas){
    let gomezConcatenados = '';
    let gomezes = personas.filter(persona => persona.apellido === 'GOMEZ');
    let gomezesOrdenados = gomezes.sort((gomezA, gomezB) => gomezA.nombre.localeCompare(gomezB.nombre));
    
    for (let i=0; i < gomezesOrdenados.length; i++){
        if (i < gomezesOrdenados.length - 1){
            gomezConcatenados = gomezConcatenados + gomezesOrdenados[i].nombre + ', '
        }
        else {
            gomezConcatenados = gomezConcatenados + gomezesOrdenados[i].nombre
        }
    }
    return gomezConcatenados
}


// #4
function sumaEdadesNPyAI(personas){
    let edadSum = 0;

    personas.forEach(persona => {
        if ((persona.nombre.length % 2) === 0 && (persona.apellido.length % 2) === 1){
            edadSum = edadSum + persona.edad;
        }
    })

    return "Edad Total de personas con Nombre Par y Apellido Impar: " + edadSum
}


// #5
function jsonCantidades(personas){
    let mayores = 0;
    let menores = 0;
    let primeraMitad = 0;
    let segundaMitad = 0;

    mayores = personas.filter(persona => persona.edad > 18).length;
    menores = personas.length - mayores;

    primeraMitad = personas.filter(persona => persona.apellido.charAt(0) >= 'A' && persona.apellido.charAt(0) <= 'L').length;
    segundaMitad = personas.length - primeraMitad;

    const objetoNoJSON = {
        mayores: mayores, 
        menores: menores,
        primeraMitad: primeraMitad,
        segundaMitad: segundaMitad
    };

    const objetoJSON = JSON.stringify(objetoNoJSON);
    return objetoJSON
}


// #6
function jsonCantidadesApellidos(personas){
    let cast = personas.filter(persona => persona.apellido === 'CASTILLO').length;
    let diaz = personas.filter(persona => persona.apellido === 'DIAZ').length;
    let ferr = personas.filter(persona => persona.apellido === 'FERRER').length;
    let pino = personas.filter(persona => persona.apellido === 'PINO').length;
    let rome = personas.filter(persona => persona.apellido === 'ROMERO').length;
    
    const objetoNoJSON = {
        CASTILLO: cast,
        DIAZ: diaz,
        FERRER: ferr,
        PINO: pino,
        ROMERO: rome
    }

    const objetoJSON = JSON.stringify(objetoNoJSON);
    return objetoJSON
}


(function main(){
    leerJSON('./datos/personas.json')
        .then(personas => {
            // #1
            console.log("(+) Consigna N°1\n" + promedioEdades(personas));

            // #2
            console.log("(+) Consigna N°2\n" + primerPersonaMasJoven(personas));

            // #3
            console.log("(+) Consigna n°3\n" + gomezOrdenados(personas));

            // #4
            console.log("(+) Consigna n°4\n" + sumaEdadesNPyAI(personas));

            // #5
            console.log("(+) Consigna n°5\n" + jsonCantidades(personas));

            // #6
            console.log("(+) Consigna n°6\n" + jsonCantidadesApellidos(personas));
        })
        .catch(error => console.log('error'))
})()
