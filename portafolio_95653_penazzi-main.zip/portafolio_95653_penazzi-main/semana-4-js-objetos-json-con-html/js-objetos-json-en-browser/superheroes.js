const poderes = [
    {
        id: 1,
        nombre: 'Volar' 
    },
    {
        id: 2,
        nombre: 'Superfuerza'
    },
];

const superheroes = [
    {
        id: 1,
        nombre: 'Superman',
        activo: true,
        poder: poderes[0]
    },
    {
        id:2,
        nombre: 'Flash',
        activo: false,
        poder: poderes[1]
    },
];

function cargarSuper() {
    const tabla=document.getElementById('datos');
    for (let superheroe of superheroes) {
        const row = `
        <td scope="row">${superheroe.id}</td>
        <td>${superheroe.nombre}</td>
        <td>${superheroe.poder.nombre}</td>
        <td>${superheroe.activo}</td>
        `;

        const nuevaFila = tabla.insertRow(tabla.rows.lenght);
        nuevaFila.innerHTML= row
    }
};

const filtrarSuper = (nombreSuper) => {
    const superFiltrados = superheroes.filter((s) => {
        return s.nombre === nombreSuper
    });
    
    const tabla=document.getElementById('datos');
    for (let superheroe of superFiltrados) {
        const row = `
        <td scope="row">${superheroe.id}</td>
        <td>${superheroe.nombre}</td>
        <td>${superheroe.poder.nombre}</td>
        <td>${superheroe.activo}</td>
        `;
        const nuevaFila = tabla.insertRow(tabla.rows.lenght);
        nuevaFila.innerHTML= row
    }
} 


document.addEventListener('DOMContentLoaded', function(e)
{
    cargarSuper();
    const btnFiltrar =document.getElementById('btnFiltrar');    
    btnFiltrar.addEventListener('click', function(event){
        //console.log('click event', event)
        const textoIngresado = document.getElementById('textoafiltrar').value.trim();
        filtrarSuper(textoIngresado);
    })
});

