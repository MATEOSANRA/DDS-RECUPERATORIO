# Clase 3 - Javascript - objetos - JSON
Presentación [aquí](https://docs.google.com/presentation/d/1mmXo4_0uNU63o4dL53DWOMCqf6GoTjFUOONtJsbaGv4/edit?usp=sharing)

- Clases y Objetos JSON.
- Integración de HTML y JS (Agregar validación a un formulario bien completo de forma que no sea necesario backend)
- DOM: manejo de documento con JavaScript. Interfaces y objetos. 
- Estructuración y Desestructuración de Objetos.


## Link útiles
- Material de cátedra: https://labsys.frc.utn.edu.ar/gitlab/desarrollo-de-software1/materiales/semana-04/-/tree/main/apunte-07?ref_type=heads
- 