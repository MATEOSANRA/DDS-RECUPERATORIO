# Consideraciones sobre el simulacro:

# Link:  
https://docs.google.com/document/d/1oKlFAC5gYUPMwjfdMx9t-RuQTDdFb3HR/edit#heading=h.gjdgxs

# simulacro
1. En la propuesta inicial el parcial tiene:
- un componente Menú con una sola ruta que redirige al componente Registro (padre)
- un componente padre (Registro) con estado que contiene un formulario HTML para carga de datos de una entidad
- un componente hijo (Consulta) que no tiene estado y que muestra los registros de la tabla a medida que se van cargando.
- un botón Volver que desde la consulta te permite volver al registro

2. Sobre esta base se puede cambiar:
- Navegación (routers) directamente en App.js, eliminar el componente Menu o bien darlo resuelto
- El componente padre puede ser la tabla con la consulta, y el hijo modelar el formulario de carga (invertir el componente)
- Respetando la propuesta original, se puede pedir solo el formulario y dar la consulta ya resuelta
- En el Menú se podría abrir 2 rutas: 1 para la consulta y 1 para la Carga (Componente Padre sería el menu y los hijos: registro y consulta)
- Cambiar el botón Volver por Nuevo y que quede más tipo ABMC (desde la consulta, mediante la opción Nuevo -> registro)




