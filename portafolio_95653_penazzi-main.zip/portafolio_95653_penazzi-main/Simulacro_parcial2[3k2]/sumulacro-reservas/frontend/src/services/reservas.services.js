import axios from 'axios'
const URL = 'http://localhost:3001/reservas'

async function getReservas(){
    const response = await axios.get(URL)
    return response.data
}

async function saveReserva(obra){
    const response = await axios.post(URL, obra)
}

export default {getReservas, saveReserva}
