import React, { useState, useEffect } from 'react'
import './styles.css'
import TablaReservas from './TablaReservas'
import service from '../services/reservas.services.js'
import { useNavigate } from "react-router-dom"

export const Consulta = () => {
    const [rows, setRows] = useState([])
    const navigate = useNavigate();

    useEffect(() => {
        const loadData = async () => {
            const data = await service.getReservas()
            setRows(data)
        }
        loadData()
    }, [])

    const onVolver = () => {
        navigate("/");
    }

    return (
        <div className='container_app'>
            <h5>Consulta de Reserva de estadía</h5>
            <TablaReservas rows={rows} onVolver={onVolver}></TablaReservas>
        </div >
    )
}
