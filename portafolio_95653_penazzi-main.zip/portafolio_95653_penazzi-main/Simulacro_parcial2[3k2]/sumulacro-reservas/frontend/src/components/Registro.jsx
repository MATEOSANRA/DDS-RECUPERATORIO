import React, { useState } from 'react'

import TablaReservas from './TablaReservas' // lo importo asi porque el componente esta `export default `
import service from '../services/reservas.services.js'
import { useForm } from 'react-hook-form'
import { useNavigate } from "react-router-dom"

export default function Registro() {
    const [rows, setRows] = useState([])
    const { register, handleSubmit, formState: { errors } } = useForm()
    const navigate = useNavigate();

    const onSubmit = async (data) => {
        await service.saveReserva(data)
        await loadData()
    }

    const loadData = async () => {
        const data = await service.getReservas()
        setRows(data)
    }

    const onVolver = () => {
        navigate("/");
    }

    return (
        <div className='container_app'>
            <form onSubmit={handleSubmit(onSubmit)}>
                <h5>Registro de Reserva de estadía</h5>
                <div className="form-group">
                    <label htmlFor="Dni">DNI reserva:</label>
                    <input type="text" className="form-control" id="Dni"  {...register("Dni", { required: 'Este campo es requerido' })} />
                    {errors.dni && <span className='error'>{errors.dni.message}</span>}
                </div>
                <div className="form-group">
                    <label htmlFor="FechaIngreso">Fecha ingreso:</label>
                    <input type="date" className="form-control" id="FechaIngreso" {...register("FechaIngreso", { required: 'Este campo es requerido' })} />
                    {errors.fechaIngreso && <span className='error'>{errors.fechaIngreso.message}</span>}
                </div>
                <div className="form-group">
                    <label htmlFor="FechaSalida">Fecha salida:</label>
                    <input type="date" className="form-control" id="FechaSalida"  {...register("FechaSalida")} />
                </div>
                <div className="form-group">
                    <label htmlFor="Huespedes">Cantidad de huéspedes:</label>
                    <input type="number" className="form-control" id="Huespedes" {...register("Huespedes", { required: 'Este campo es requerido' })} />
                    {errors.huespedes && <span className='error'>{errors.huespedes.message}</span>}
                </div>
                <div className="form-group" >
                    <label htmlFor="stay">Tipo de estadía:</label>
                    <select className="form-control" id="TipoEstadia" {...register("TipoEstadia", { required: 'Este campo es requerido' })}>
                        <option value="Pension completa">Pensión completa</option>
                        <option value="Media pensión">Media Pensión</option>
                        <option value="Solo estadía">Solo estadía</option>
                    </select>
                    {errors.tipoEstadia && <span className='error'>{errors.tipoEstadia.message}</span>}
                </div>
                <div className="form-group text-center mt-3">
                    <button type="submit" className="btn btn-primary mx-1">Registrar</button>
                    <button type="reset" className="btn btn-secondary mx-1">Limpiar</button>
                </div>
            </form>
            <TablaReservas rows={rows} onVolver={onVolver}></TablaReservas>
        </div >
    )
}
