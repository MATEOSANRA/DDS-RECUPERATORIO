import {
  BrowserRouter as Router,
  Routes,
  Route
} from 'react-router-dom'
import { Menu } from './components/Menu'; // lo importo asi porque el componente Consulta esta declarado `export const `
import Registro from './components/Registro'; // lo importo asi porque el componente Registro esta declara con `export default `
import './App.css';
import { Consulta } from './components/Consulta'; // lo importo asi porque el componente Consulta esta declarado `export const `

function App() {
  return (
    <div>
      <Router>
        <div>
          <Routes>
            <Route path='/' element={<Menu />} />
            <Route path='/reservas' element={<Consulta />} />
            <Route path='/reservas/registrar' element={<Registro />} />
          </Routes>
        </div>
      </Router>
    </div>
  );
}

export default App;

