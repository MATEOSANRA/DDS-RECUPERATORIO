import axios from "axios"

const getObras = async () => {
    const response = await axios.get('http://localhost:3001/api/obras-teatrales')
    return response.data
}

const postObra = async (obraTeatral) =>{
    const response = await axios.post('http://localhost:3001/api/obras-teatrales',
        obraTeatral,
        {
            headers: {"Content-Type": 'application/json'}
        }
    )
    return response.data
}

export {getObras, postObra}