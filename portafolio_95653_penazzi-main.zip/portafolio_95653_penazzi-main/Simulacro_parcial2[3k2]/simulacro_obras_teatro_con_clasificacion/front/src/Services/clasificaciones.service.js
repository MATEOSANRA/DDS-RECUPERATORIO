import axios from "axios";

export default async function getClasificaciones() {
    const response = await axios.get('http://localhost:3001/api/clasificaciones')
    return response.data
}