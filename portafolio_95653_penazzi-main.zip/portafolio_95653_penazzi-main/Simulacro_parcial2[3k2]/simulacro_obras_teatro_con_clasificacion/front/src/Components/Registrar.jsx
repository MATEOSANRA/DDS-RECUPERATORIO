import { useForm } from "react-hook-form"
import { useEffect,useState } from "react"
import { postObra } from "../Services/Obras.service"
import { getObras } from "../Services/Obras.service"
import getClasificaciones from "../Services/clasificaciones.service"


export default function Registrar() {
    const [obras, setObras] = useState([])
    const [clasificaciones, setClasificaciones] = useState([])
    const {register, handleSubmit, formState: {errors} } = useForm()

    useEffect(()=> {
        const getData = async() => {
            const data = await getObras()
            setObras(data)
        
            const clasificaciones = await getClasificaciones()
            setClasificaciones(clasificaciones)
        }
        getData()
    }, [])

    const onSubmit = async(data) => {
        const nuevo ={
            director: data.director,
            idClasificacion: parseInt(data.idClasificacion),
            titulo: data.titulo
        }
        await postObra(nuevo)
        const obrasNuevas = await getObras()
        setObras(obrasNuevas)
    }

    return(
        <div className="row">
            <br />
            <div className="col-4">
                <form onSubmit={handleSubmit(onSubmit)}>
                    <div className="form-group">
                        <label htmlFor="titulo">Titulo:</label>
                        <input className="form-control" type="text" id="titulo" {...register("titulo", { required: 'Este campo es requerido' }) } />
                        {errors.titulo && <span className='error'>{errors.titulo.message}</span>}
                    </div>
                    <div className="form-group">
                        <label htmlFor="director">Director:</label>
                        <input className="form-control" type="text" id="director" {...register("director", {requiered: 'Este campo es requerido'}) } />
                        {errors.director && <span className='error'>{errors.titulo.message}</span>}
                    </div>
                    <div className="form-group">
                        <label htmlFor="stay">Clasificacion:</label>
                        <select className="form-control" id="idClasificacion" {...register("idClasificacion", { required: 'Este campo es requerido' } )}>
                            {clasificaciones.map((e)=> (
                                <option key={e.id} value={e.id}>{e.titulo}</option>
                            ))}
                        </select>
                        {errors.idClasificacion && <span className='error'>{errors.idClasificacion.message}</span>}
                    </div>
                    <div className="form-group text-center mt-3">
                        <button type="submit" className="btn btn-primary mx-1">
                            Registrar
                        </button>
                    </div>
                </form>
            </div>
        </div>
    )
}