import React, { useState, useEffect } from "react"
import { getObras } from "../Services/Obras.service"

const Consultar = () => {
    
    const [obras, setObras] = useState([])

    useEffect(() => {
        const getData = async () => {
            const data = await getObras()
            setObras(data);
        }
        getData();
    }, [])

    const onConsultar = async () => {
        const data = await getObras()
        setObras(data)
    }
    
    return (
        <div>
            <div>
                <button type="button" className="btn btn-primary mb-3" onClick={onConsultar}>Consultar</button>
            </div>
            <br />
            <h2>Tabla de obras</h2>
            <br />
            <div className="col-12">
                <table className="table table-responsive">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Titulo</th>
                            <th scope="col">Director</th>
                            <th scope="col">Clasificacion</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            obras && obras.map((obra, index) => {
                                return (
                                    
                                        <tr key={obra.id}>
                                            <th scope="row">{obra.id}</th>
                                            <td>{obra.titulo}</td>
                                            <td>{obra.director}</td>
                                            <td>{obra.clasificacion.titulo}</td>
                                        </tr>
                                )})
                        }
                    </tbody>
                </table>
            </div>
        </div>
    )
}

export default Consultar