import React from "react"
import { Routes, BrowserRouter, Route} from "react-router-dom"
import { Navbar } from "./Components/Navbar/navbar"
import Consultar from "./Components/Consultar"
import Registrar from "./Components/Registrar"

function App() {
  return (
    <BrowserRouter>
      <Navbar></Navbar>
      <Routes>
        <Route path='/obras-teatrales' element={<Consultar/>}></Route>
        <Route path='/obras-teatrales/crear' element={<Registrar/>}></Route>

      </Routes>

    </BrowserRouter> 
    
  )
}

export default App
