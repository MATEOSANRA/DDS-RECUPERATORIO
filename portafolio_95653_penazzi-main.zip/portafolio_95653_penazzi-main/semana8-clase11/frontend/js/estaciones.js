
function limpiarOpciones(select) {
    console.log(select.options);
    while(select.options.length > 0) {
        select.options.remove(0);
    }
}

async function getBarrios() {
    const resp = await fetch("http://localhost:3001/barrios");
    const data = await resp.json();

    return data;

}

async function cargarBarrios() {
    const select = document.getElementById("barrio");

    limpiarOpciones(select);
    try {
        const barrios = await getBarrios();
        // barrios.sort((a, b) => a.nombre.localeCompare(b.nombre));
        const opcionBase = new Option("", 0);
        select.options.add(opcionBase);
        barrios.forEach(elemento => {
            const opcion = new Option(elemento.nombre, elemento.idBarrio);
            select.options.add(opcion);
        });        

    }
    catch (error) {
        console.log(error);
        const opcionError = new Option("Sin barrios", -1);
        select.options.add(opcionError);
    }

}

function limpiarFilas(tBody) {

    while (tBody.rows.length > 0) {
        tBody.deleteRow(0);
    }

}

async function getEstaciones() {
    const resp = await fetch("http://localhost:3001/estaciones");
    const data = await resp.json();

    return data;

}

async function cargarEstaciones() {
    const tableBody = document.getElementById("datos");

    limpiarFilas(tableBody);
    try {
        const estaciones = await getEstaciones();

        estaciones.forEach((elemento => {
            const textoFila = `<th scope="row">${elemento.idEstacion}</th>
                               <td>${elemento.nombre}</td>
                               <td>${elemento.direccion}</td>
                               <td>${elemento.nombreBarrio}</td>
                               <td>${(elemento.activa === 1 ? "Si" : "No")}</td>
                              `;
            const fila = tableBody.insertRow(tableBody.rows.length);
            fila.innerHTML = textoFila;
        }));

        const titulo = document.getElementById("titulo_listado");
        titulo.textContent = `Lista de Estaciones (${estaciones.length})`;

    }
    catch (error) {
        console.log(error);
        const titulo = document.getElementById("titulo_listado");
        titulo.textContent = `Lista de Estaciones (Sin estaciones)`;

    }

}

async function getEstacionesByFilter(textoNombre, textoDireccion, idBarrio, activoChecked) {
    let url = "http://localhost:3001/estaciones";

    if (textoNombre || textoDireccion || Number(idBarrio) !== 0 || activoChecked)
        url += "?";

    if (textoNombre) {
        url += `nom=${textoNombre}`;
    }

    if (textoDireccion) {
        url += ((url[url.length - 1] !== "?")? "&" : "") + `dir=${textoDireccion}`;
    }

    if (Number(idBarrio) !== 0) {
        url += ((url[url.length - 1] !== "?")? "&" : "") + `barrio=${Number(idBarrio)}`;
    }

    if (activoChecked) {
        url += ((url[url.length - 1] !== "?")? "&" : "") + `inactivos=${activoChecked}`;
    }

    // console.log(url);

    const resp = await fetch(url);
    const data = await resp.json();

    return data;

}

async function buscarEstaciones(textoNombre, textoDireccion, idBarrio, activoChecked) {
    const tableBody = document.getElementById("datos");

    limpiarFilas(tableBody);
    try {
        const estaciones = await getEstacionesByFilter(textoNombre, textoDireccion, idBarrio, activoChecked);

        estaciones.forEach((elemento => {
            const textoFila = `<th scope="row">${elemento.idEstacion}</th>
                               <td>${elemento.nombre}</td>
                               <td>${elemento.direccion}</td>
                               <td>${elemento.barrio.nombre}</td>
                               <td>${(elemento.activa === 1 ? "Si" : "No")}</td>
                              `;
            const fila = tableBody.insertRow(tableBody.rows.length);
            fila.innerHTML = textoFila;
        }));

        const titulo = document.getElementById("titulo_listado");
        titulo.textContent = `Lista de Estaciones (${estaciones.length})`;

    }
    catch (error) {
        console.log(error);
        const titulo = document.getElementById("titulo_listado");
        titulo.textContent = `Lista de Estaciones (Sin estaciones)`;

    }

}

document.addEventListener('DOMContentLoaded', async function (e) {
    
    await cargarBarrios();

    await cargarEstaciones();

    const btnBuscar = document.getElementById('btnBuscar');
    btnBuscar.addEventListener('click', async function (event) {
        event.preventDefault();
        // console.log('click event', event)
        const textoNombre = document.getElementById('nombre').value;
        const textoDireccion = document.getElementById('direccion').value;
        const idBarrio = document.getElementById('barrio').value;
        const activoChecked = document.getElementById('activo').checked;

        console.log(`Nombre: ${textoNombre}`);
        console.log(`Direccion: ${textoDireccion}`);
        console.log(`Selected Barrio: ${idBarrio}`);
        console.log(`Activo: ${activoChecked}`);
        

        await buscarEstaciones(textoNombre, textoDireccion, idBarrio, activoChecked);
    });

});