import express from "express";
import dotenv from "dotenv";
import cors from "cors";

import dbInit from "./data/db-init.js";

import { obtenerBarrios } from "./services/barrios.service.js";
import {
    obtenerEstaciones,
    obtenerEstacionesActivas,
    obtenerEstacionesPorFiltro,
} from "./services/estaciones.service.js";

// import logger from "./middlewares/requestLogger.js";
// import errorHandler from "./middlewares/errorHandler.js";
// import notFound from "./middlewares/notFound.js";

// import serverStatusRouter from "./routes/serverStatus.router.js";
// import estacionesRouter from "./routes/estaciones.router.js";
// import barriosRouter from "./routes/barios.router.js";
// import usuariosRouter from "./routes/usuarios.router.js";

dotenv.config();

const app = express();

app.use(cors());

// // Logs
// if (process.env.LOG === "true") {
//     app.use(logger);
// }

app.get("/status", (req, res) => {
    res.json({ respuesta: "API iniciada y escuchando..." });
});
// app.use("/status", serverStatusRouter);

app
    .get("/estaciones", (req, res) => {
        console.log(JSON.stringify(req.query));
        return ((JSON.stringify(req.query) !== "{}")
            ? obtenerEstacionesPorFiltro(req, res)
            : obtenerEstacionesActivas(req, res));
    })
    .get("/estaciones/completo", obtenerEstaciones);

// app.use("/estaciones", estacionesRouter);

app.get("/barrios", obtenerBarrios);
// app.use("/barrios", barriosRouter);

// app.use("/usuarios", usuariosRouter);

// app
//     .use(errorHandler)
//     .use(notFound);

(async function start() {
    const PORT = process.env.PORT || 3000;

    // Inicializar la conexión a la base de datos
    await dbInit();

    // Iniciar el servidor
    app.listen(PORT, () => {
        console.log(`Servidor iniciado y escuchando en el puerto ${PORT}`);
    });
}());
