import appExpress from "express";
import {
    obtenerUsuariosPorFiltro
} from "../services/usuarios.service.js";

const usuariosRouter = appExpress.Router();

usuariosRouter.get("/", async (req, res, next) => {
    const { texto } = req.query;

    try {
        const usuarios = await obtenerUsuariosPorFiltro(texto);
        if (usuarios) {
            res.json(usuarios);
        }
        else {
            res.status(404).json({ error: "Usuarios no encontrados" });
        }
    }
    catch (error) {
        console.log(error);
        next(error);
    }
});

export default usuariosRouter;
