import appExpress from "express";
import { obtenerBarrios } from "../services/barrios.service.js";

const barriosRouter = appExpress.Router();

barriosRouter.get("/", obtenerBarrios);

export default barriosRouter;
