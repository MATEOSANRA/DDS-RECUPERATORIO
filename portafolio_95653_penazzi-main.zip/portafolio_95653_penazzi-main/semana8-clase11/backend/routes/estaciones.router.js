import appExpress from "express";
import {
    obtenerEstaciones,
    obtenerEstacionesActivas,
    obtenerEstacionesPorFiltro,
} from "../services/estaciones.service.js";

const estacionesRouter = appExpress.Router();

estacionesRouter.get("/", (req, res, next) => {
    console.log(JSON.stringify(req.query));
    return ((JSON.stringify(req.query) !== "{}")
        ? obtenerEstacionesPorFiltro(req, res, next)
        : obtenerEstacionesActivas(req, res));
});

estacionesRouter.get("/completo", obtenerEstaciones);

export default estacionesRouter;
