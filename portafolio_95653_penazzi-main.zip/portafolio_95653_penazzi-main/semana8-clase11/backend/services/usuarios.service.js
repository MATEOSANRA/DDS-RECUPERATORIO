import { Op } from "sequelize";
import Usuarios from "../models/usuarios.js";

export async function crearUsuario(nombre, apellido, mail, password) {
    const usuario = await Usuarios.create({
        nombre,
        apellido,
        mail,
        password
    });
    return usuario;
}

export async function obtenerUsuarioPorMail(mail) {
    const usuario = await Usuarios.findOne({
        where: { mail }
    });
    return usuario;
}

export async function actualizarUsuario(idUsuario, nombre, apellido, mail, password) {
    const usuario = await Usuarios.findByPk(idUsuario);
    if (!usuario) {
        throw new Error("Usuario no encontrado");
    }
    usuario.nombre = nombre;
    usuario.apellido = apellido;
    usuario.mail = mail;
    usuario.password = password;
    await usuario.save();
    return usuario;
}

export async function eliminarUsuario(idUsuario) {
    const usuario = await Usuarios.findByPk(idUsuario);
    if (!usuario) {
        throw new Error("Usuario no encontrado");
    }
    await usuario.destroy();
}

export async function obtenerUsuarioPorId(id) {
    return Usuarios.findByPk(id);
}

export async function obtenerUsuariosPorFiltro(texto) {
    let where = null;
    if (texto) {
        where = { [Op.or]:
            [{ nombre: { [Op.like]: `${texto}%` } },
                { apellido: { [Op.like]: `${texto}%` } }] };
    }

    const filter = {
        attributes: ["idUsuario", "nombre", "apellido", "mail", "fechaHoraCreacion"],
        order: ["NOMBRE", "APELLIDO"]
    };
    if (where !== null) filter.where = where;
    return Usuarios.findAll(filter);
}
