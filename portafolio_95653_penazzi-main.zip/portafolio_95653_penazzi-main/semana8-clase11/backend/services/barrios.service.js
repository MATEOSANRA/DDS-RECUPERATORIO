import Barrios from "../models/barrios.js";

export async function obtenerBarrios(req, res) {
    // Consulta a la base de datos para traer las filas de la tabla barrios
    //  como objetos y retornar ese conjunto como un vector json.
    try {
        // realizo la consulta a la base de datos.
        const barrios = await Barrios.findAll({
            order: ["NOMBRE"]
        });

        // envío la respuesta con el resultado de la consulta.
        res.json(barrios);
    }
    catch (error) {
        console.log(error);
        res
            .status(500)
            .json({ error: "Database error obteniendo barrios." });
    }
}

export async function obtenerBarrioPorId(id) {
    const barrio = await Barrios.findByPk(id);
    return barrio;
}
