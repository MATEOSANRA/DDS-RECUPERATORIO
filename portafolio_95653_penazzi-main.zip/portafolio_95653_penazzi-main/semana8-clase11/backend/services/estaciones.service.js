import { Op } from "sequelize";
import sequelize from "../data/db.js";
import Estaciones from "../models/estaciones.js";
import Barrios from "../models/barrios.js";

async function completarNombresBarrios(estaciones) {
    const result = await Promise.all(estaciones.map(async (estacion) => {
        const barrio = await Barrios.findByPk(estacion.idBarrio);
        // estacion.nombreBarrio = barrio.nombre;
        return { ...estacion.dataValues, nombreBarrio: barrio.nombre };
    }));
    return result;
}

export async function obtenerEstacionesActivas(req, res) {
    // Consulta a la base de datos para traer las filas de la tabla barrios
    //  como objetos y retornar ese conjunto como un vector json.
    try {
        // realizo la consulta a la base de datos.
        let estaciones = await Estaciones.findAll({
            // include: [
            //     {
            //         model: Barrio,
            //         as: "barrio",
            //         required: true
            //     }
            // ],
            where: { activa: 1 },
            order: ["NOMBRE"],
        });

        // completar nombres de barrios buscando 1 por 1
        estaciones = await completarNombresBarrios(estaciones);

        // envío la respuesta con el resultado de la consulta.
        res.json(estaciones);
    }
    catch (error) {
        console.log(error);
        res.status(500).json({ error: "Database error obteniendo barrios." });
    }
}

export async function obtenerEstaciones(req, res) {
    // Consulta a la base de datos para traer las filas de la tabla barrios
    //  como objetos y retornar ese conjunto como un vector json.
    try {
        // realizo la consulta a la base de datos.
        const estaciones = await Estaciones.findAll({
            // include: [
            //     {
            //         model: Barrio,
            //         as: "barrio",
            //         required: true
            //     }
            // ],
            order: ["NOMBRE"],
        });

        // envío la respuesta con el resultado de la consulta.
        res.json(estaciones);
    }
    catch (error) {
        console.log(error);
        res.status(500).json({ error: "Database error obteniendo barrios." });
    }
}

export async function obtenerEstacionPorId(req, res) {
    const { id } = req.params;

    try {
        const estacion = await Estaciones.findByPk(id);
        if (estacion) {
            res.json(estacion);
        }
        else {
            res.status(404).json({ error: "Estación no encontrada" });
        }
    }
    catch (error) {
        res.status(500).json({ error: "Error al obtener la estación" });
    }
}

export async function obtenerEstacionesPorFiltro(req, res, next) {
    const { nom, dir, barrio, inactivos } = req.query;
    const where = {};
    if (nom) {
        where.nombre = { [Op.like]: `${nom}%` };
    }

    if (dir) {
        where.direccion = { [Op.like]: `${dir}%` };
    }

    if (barrio) {
        where.idBarrio = Number(barrio);
    }

    if (!inactivos) {
        where.activa = 1;
    }

    // console.log(where);

    try {
        const estacion = await Estaciones.findAll(
            {
            // include: [
            //     {
            //         model: Barrio,
            //         as: "barrio",
            //         required: true
            //     }
            // ],
                where,
                order: sequelize.col("nombre") }
        );
        if (estacion) {
            res.json(estacion);
        }
        else {
            res.status(404).json({ error: "Estación no encontrada" });
        }
    }
    catch (error) {
        // console.log(error);
        console.log("Llegó catch");
        next(error);
    }
}
