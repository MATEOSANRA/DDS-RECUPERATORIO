import Locales from "../models/locales.js";
import { Op } from "sequelize";

export async function obtenerLocales(req, res) {
    try{
        const locales = await Locales.findAll();
        res.json(locales);
    }
    catch (error) {
        console.log(error);
        res
            .status(500)
            .json({ error: "DATABASE ERROR obteniendo locales..." })

    }
}

export async function obtenerLocalesArg(req, res) {
    try {
        const locales = await Locales.findAll({
            where: { country: "AR"},
        });
        res.json(locales)
    }
    catch (error) {
        console.log(error);
        res.status(500).json({ error: "Database error obteniendo locales..." });
    }
} 

export async function obtenerLocalesInterior(req, res) {
    try {
        const locales = await Locales.findAll({
            where: { 
                country: "AR",
                province: {
                    [Op.notIn]: ["C", "B"],
                },
            }
        });
        res.json(locales)
    }
    catch (error) {
        console.log(error);
        res.status(500).json({ error: "Database error obteniendo locales..." });
    }
} 