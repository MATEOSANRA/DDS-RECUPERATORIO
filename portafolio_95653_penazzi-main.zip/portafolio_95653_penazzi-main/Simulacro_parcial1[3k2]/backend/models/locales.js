// Locales.js
import { DataTypes } from "sequelize";
import  sequelize  from "../data/db.js";

const Local = sequelize.define("Local", {
    storeNumber: {
        type: DataTypes.TEXT,
        primaryKey: true,
        field: "STORE_NUMBER"
    },
    storeName: {
        type: DataTypes.TEXT,
        allowNull: false,
        field: "STORE_NAME",
    },
    streetAddress: {
        type: DataTypes.TEXT,
        allowNull: false,
        field: "STREET_ADDRESS"
    },
    city: {
        type: DataTypes.TEXT,
        allowNull: false,
        field: "CITY"
    },
    province: {
        type: DataTypes.TEXT,
        allowNull: false,
        field: "PROVINCE"     
    },
    country: {
        type: DataTypes.TEXT,
        allowNull: false,
        field: "COUNTRY"
    },
    postCode: {
        type: DataTypes.TEXT,
        allowNull: false,
        field: "POSTCODE"
    },
    longitude: {
        type: DataTypes.REAL,
        field: "LONGITUDE"
    },
    latitude: {
        type: DataTypes.REAL,
        field: "LATITUDE"
    },
}, {
    timestamps: false,
    tableName: "STARBUCKS_DIRECTORY",
});

export default Local;