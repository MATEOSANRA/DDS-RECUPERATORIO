
async function getLocales() {
    const res = await fetch("http://localhost:3001/locales")
    const data = await res.json()
    return data
};


async function getLocalesInterior() {
    const res = await fetch("http://localhost:3001/locales/interior")
    const data = await res.json()
    return data
};


function limpiarTabla (tbody) {
    while (tbody.rows.length > 0) {
        tbody.deleteRow(0);
    };
};


async function cargarLocales() {
    const tbody = document.getElementById("datos");
    limpiarTabla(tbody);

    try {
        const locales = await getLocales()

        locales.forEach(element => {
            const textoFila = `
                <th scope="row">${element.storeNumber}</th>
                    <td>${element.storeName}</td>
                    <td>${element.streetAddress}</td>
                    <td>${element.city}</td>
                    <td>${element.latitude}</td>
                    <td>${element.longitude}</td>`;
            const fila = tbody.insertRow(tbody.rows.length);
            fila.innerHTML = textoFila;
        });
    }
    catch (error) {
        console.log(error);
    }
};


async function cargarLocalesInterior() {
    const tbody = document.getElementById('datos');
    limpiarTabla(tbody);

    try {
        const locales = await getLocalesInterior()

        locales.forEach(element => {
            const textoFila = `
                <th scope="row">${element.storeNumber}</th>
                    <td>${element.storeName}</td>
                    <td>${element.streetAddress}</td>
                    <td>${element.city}</td>
                    <td>${element.latitude}</td>
                    <td>${element.longitude}</td>`;
            const fila = tbody.insertRow(tbody.rows.length);
            fila.innerHTML = textoFila;
        });
    }
    catch (error) {
        console.log(error);
    }
};


async function verTodos() {
    const boton = document.getElementById('verTodos');
    boton.addEventListener("click", async function() {
        await cargarLocales()
    });
};


async function filtrarLocales() {
    const boton = document.getElementById("botonFiltrar");
    
    boton.addEventListener("click", async function() {
            await cargarLocalesInterior();
        });  
};


document.addEventListener("DOMContentLoaded", async function(e){

    await cargarLocales()
    await filtrarLocales()
    await verTodos()

});