
const getTracks = async () => {
        const response = await fetch("http://localhost:3001/tracks");
        const tracks = await response.json()
        return tracks
}


async function cargarTracks() {
    const tbody = document.getElementById('datos');
    tbody.innerHTML = ""
    try {
        const tracks = await getTracks()
        tracks.forEach(e => {
            const duracion = `${Math.floor(e.milliseconds / 60000)}:${Math.floor((e.milliseconds % 60000)/1000)}`
            const fila = `
                    <th scope="row">${e.trackId}</th>
                        <td>${e.name}</td>
                        <td>${e.album}</td>
                        <td>${e.artistName}</td>
                        <td>${e.genre}</td>
                        <td>${duracion}</td>
                        `
            tbody.innerHTML += fila
        })
    }
    catch (error) {
        console.log(error);
    };

}


document.addEventListener("DOMContentLoaded", function(e) {
    cargarTracks()
})