import { Op } from "sequelize";
import Tracks from "../models/canciones.js";

async function obtenerTracks(req, res) {
    try {
        const tracks = await Tracks.findAll({
            where: {
                name: { [ Op.like ]: "%love%" },
                genre: {
                    [Op.in]: ["Blues", "Jazz", "Latin"]
                },
            },
            order: [ [ "MILLISECONDS", "DESC" ] ]
        })
        res.json(tracks)
    }
    catch (error) {
        console.log(error)
        res.status(500).json( { error:"DATABASE EROOR" })
        
    }
}

export default obtenerTracks