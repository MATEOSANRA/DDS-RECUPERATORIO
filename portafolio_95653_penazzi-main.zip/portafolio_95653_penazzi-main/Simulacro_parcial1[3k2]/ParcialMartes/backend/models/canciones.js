import sequelize from "../data/db.js";
import { DataTypes } from "sequelize";

const Tracks = sequelize.define( "tracks", {
    trackId : {
        type: DataTypes.INTEGER,
        primaryKey: true,
        field: "TRACK_ID"
    },
    name: {
        type: DataTypes.TEXT,
        field: "NAME"
    },
    album: {
        type: DataTypes.TEXT,
        field: "ALBUM",
    },
    artistName: {
        type: DataTypes.TEXT,
        field: "ARTIST_NAME",
    },
    composer: {
        type: DataTypes.TEXT,
        allowNull: true,
        field: "COMPOSER",
    },
    milliseconds: {
        type: DataTypes.INTEGER,
        field: "MILLISECONDS",
    },
    genre: {
        type: DataTypes.TEXT,
        field: "GENRE",
    },
    mediaType: {
        type: DataTypes.TEXT,
        field: "MEDIA_TYPE"
    }
},   
    {
        timestamps: false,
        tableName: "Tracks_Data"
    }

)

export default Tracks
