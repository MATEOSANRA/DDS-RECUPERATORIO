# Enunciado Práctica HTTP - Postman

## Configuracion previa
URL-REPO:  https://labsys.frc.utn.edu.ar/gitlab/desarrollo-de-software1/materiales/ejercicios/practica-http-postman-curl
RAMA base: main
```
$ git clone <URL-REPO>
```
```
$ cd REPO
```
Copiar contenido en su repositorio portafolio


## Objetivo
Practicar HTTP con distintos clientes HTTP (potman y curl)
1. Todo esto debe quedar en su **portafolio** en la carpeta practica-http-postman-curl
2. Buscar una api pública.
3. Identificar al menos 3 GET, 1 POST,1 PUT, 1 DELETE.
4. Actualizar el README.md con sus respectivos CURL
5. Crear el link para compartir la colección y actualizarla en el README.md
6. Pushear rama al portafolio. 

## Presentación
[Aquí](https://docs.google.com/presentation/d/1Aldiucn5-pMCBJgmMYYkJUAGoPq04BZyFbMhY4xKVvA/edit?usp=sharing)
