import React from "react";
import { useForm } from "react-hook-form";
import estacionesService from "../../services/estacionesService";

const BARRIOS= [
    {"idBarrio": 7,"nombre": "CENTRO"},
    {"idBarrio": 1,"nombre": "CIUDAD UNIVERSITARIA"},
    {"idBarrio": 2,"nombre": "NUEVA CÓRDOBA"},
    {"idBarrio": 19,"nombre": "Nuevo Barrio"},
    {"idBarrio": 20,"nombre": "Nuevo Barrio"},
    {"idBarrio": 21,"nombre": "Nuevo Barrio"},
    {"idBarrio": 4,"nombre": "ZONA ESTE"},
    {"idBarrio": 5,"nombre": "ZONA NORTE"},
    {"idBarrio": 6,"nombre": "ZONA OESTE"},
    {"idBarrio": 3,"nombre": "ZONA SUR"}
]


export const CrearEstaciones = () => {
    
    const {register, handleSubmit}= useForm()
    const onSubmit = (data) => {
        console.log(data)
        estacionesService.postEstacion(data)
    }

    return (
        <div className="mb-3">
            <h2>Crear estacion</h2>
            <form onSubmit={handleSubmit(onSubmit)}>
                <div class="form-group">
                    <label htmlFor="Nombre" class="label label-primary"></label>
                    <input class="form-control" placeholder="Nombre" type="text" {... register('nombre')} />
                </div>
                <div class="form-group">
                    <label htmlFor="Direccion"></label>
                    <input class="form-control" type="text" {... register('direccion')} placeholder="Direccion" />
                </div>
                <div class="form-group">
                    <label htmlFor="barrio"></label>
                    <select id="barrio" {... register('idBarrio')} class="form-select">
                        {BARRIOS.map((barrio) => (
                            <option key={barrio.idBarrio} value={barrio.idBarrio}>{barrio.nombre}</option>
                        ))}
                    </select>
                </div>
                <hr />
                <button className="btn btn-primary" type="submit">Crear estacion</button>
            </form>
        </div>
    )
}