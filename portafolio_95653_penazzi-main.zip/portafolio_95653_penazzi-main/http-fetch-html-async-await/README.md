# HTTP - Fetch - async - await
Presentación [aquí](https://docs.google.com/presentation/d/1Aldiucn5-pMCBJgmMYYkJUAGoPq04BZyFbMhY4xKVvA/edit?usp=sharing)

- [JSON](https://www.json.org/json-es.html)
- [Fetch](https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API )
- [HTTP GET](https://docs.google.com/presentation/d/1Aldiucn5-pMCBJgmMYYkJUAGoPq04BZyFbMhY4xKVvA/edit?usp=sharing)
- Integramos lo hecho hasta ahora con una API externa [https://jsonplaceholder.typicode.com/](https://jsonplaceholder.typicode.com/guide/)


## Qué contiene este repositorio?
En la rama `main` contiene los archivo bases para poder iniciar la actividad.

En la rama `guía` se muestra una solucion propuesta.

## Actividad continuar con ejercitación
A partir de la rama `guía` realizar:

1. Dar funcionalidad en el menu a la pestaña comentarios con el endpoint `https://jsonplaceholder.typicode.com/comments`. Si prefieren pueden usar algún endpoint de la [API de Space X](https://github.com/r-spacex/SpaceX-API/blob/master/docs/README.md), recordar cambiar el nombre de la pestaña si se usa esta API.

> Todo tiene que quedar en su portafolio.

## Colección en postman:
- [Descargar Postman](https://www.postman.com/downloads/) o usar [Postman web](https://www.postman.com/)
- Colección a importar: [https://api.postman.com/collections/1880332-4b1fe78c-dfa8-4e73-948c-d2b3b591948d?access_key=PMAT-01HW7BQDPB1V4HQ93KNRBD0RJP](https://api.postman.com/collections/1880332-4b1fe78c-dfa8-4e73-948c-d2b3b591948d?access_key=PMAT-01HW7BQDPB1V4HQ93KNRBD0RJP)

- Para importar
    ![importar colección](./imgs/importar-postman-1.png)

- Pegar link
    ![importar colección](./imgs/importar-postman-2.png)


## Link útiles
- Material de cátedra: https://labsys.frc.utn.edu.ar/gitlab/desarrollo-de-software1/materiales/
- Fetch: https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API 
- Otras API:
    - https://mixedanalytics.com/blog/list-actually-free-open-no-auth-needed-apis/
    - https://dev.to/ruppysuppy/7-free-public-apis-you-will-love-as-a-developer-166p
- API Space X: https://github.com/r-spacex/SpaceX-API/blob/master/docs/README.md 


