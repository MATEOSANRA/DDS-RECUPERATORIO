import axios from "axios";
import { baseUrl, token } from "./baseService";

const getEstaciones = async () => {
  // return fetch("http://localhost:3001/api/estaciones", 
  //   {
  //     headers: {"content-type": 'application/json', "Authorization": `Bearer ${token}`}
  //   }
  // ).then((response) =>
  //   response.json()
  // );
  // const response = await axios.get(`${baseUrl}/estaciones`, {
  //   headers: {"Authorization" : `Bearer ${token}`}
  // })  
  const response = await axios.get(`${baseUrl}/estaciones`)
  return response.data
};

const getEstacionById = async (idEstacion) => {
  const response = await axios.get(`${baseUrl}/estaciones/${idEstacion}`)
  return response.data
};

const borrarEstacion = async (idEstacion) => {
  const response = await axios.delete(`${baseUrl}/estaciones/${idEstacion}`)
}

const getEstacionesFiltradas = async (filtro) => {
  const params = {}

  if (filtro.nombre !== "")
    params.nom = filtro.nombre;
  if (filtro.direccion !== "")
    params.dir = filtro.direccion;
  if (filtro.barrio !== '0')
    params.barrio = filtro.barrio
  if (filtro.activo)
    params.inactivos = true

  const response = await axios.get(`${baseUrl}/estaciones`, { params });
  return response.data;

};

const postEstacion = async (estacion) => {
  console.log(estacion);
  return fetch("http://localhost:3001/api/estaciones", {
    method: "POST",
    body: JSON.stringify(estacion),
    // headers: {"content-type": 'application/json'}
    headers: { "content-type": 'application/json', "Authorization": `Bearer ${token}` }
  }).then((response) => response.json());
};


const putEstacion = async (estacion) => {
  console.log(estacion);
  await axios.put(`http://localhost:3001/api/estaciones/${estacion.idEstacion}`, estacion, {
    headers:{ 
      "content-type": 'application/json', 
      "Authorization": `Bearer ${token}` 
    }
  })
  // return fetch("http://localhost:3001/api/estaciones", {
  //   method: "POST",
  //   body: JSON.stringify(estacion),
  //   // headers: {"content-type": 'application/json'}
  //   headers: {"content-type": 'application/json', "Authorization": `Bearer ${token}`}
  // }).then((response) => response.json());
};

export default { getEstaciones, getEstacionesFiltradas, postEstacion, borrarEstacion, getEstacionById, putEstacion };
