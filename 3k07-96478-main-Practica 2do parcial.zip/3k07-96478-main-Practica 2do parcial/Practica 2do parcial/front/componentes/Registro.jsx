import React from "react";
import { useState } from "react";
import { useForm } from "react-hook-form"
import ingreso_servicios from "../services/ingreso_servicios.js";
import Consulta from "./Consultar.jsx";

export default function Registro(){
    const [action, setAction] = useState("R")
    const [rows, setRows] = useState([])
    const {register, handleSubmit, formState: {errors}} = useForm()

    const onSubmit = async(dat)=>{
        const res = await ingreso_servicios.saveIngreso(dat)
        if(res){
            loadData()
            setAction("C")
        }
    }
    const loadData = async()=>{
        const res = await ingreso_servicios.getIngresos()
        if(res){
            setRows(res)
        }
    }
    const onVolver = ()=>{
        setAction("R")
    }


    return(
        <div className="container mt-3">
  {action === "R" && (
    <form onSubmit={handleSubmit(onSubmit)}>
      <div className="mb-3">
        <label htmlFor="Dni" className="form-label">Dni</label>
        <input type="number" className="form-control" id="Dni" {...register("Dni", {required:'campo requerido'})}/>
        {errors.Dni && <div className="alert alert-danger">{errors.Dni.message}</div>}
      </div>
      <div className="mb-3">
        <label htmlFor="HoraIngreso" className="form-label">Hora ingreso</label>
        <input type="time" className="form-control" id="HoraIngreso" {...register("HoraIngreso", {required:'campo requerido'})}/>
        {errors.HoraIngreso && <div className="alert alert-danger">{errors.HoraIngreso.message}</div>}
      </div>
      <div className="mb-3">
        <label htmlFor="Proveedor" className="form-label">Proveedor</label>
        <input type="text" className="form-control" id="Proveedor" {...register("Proveedor", {required:'campo requerido'})}/>
        {errors.Proveedor && <div className="alert alert-danger">{errors.Proveedor.message}</div>}
      </div>
      <div className="mb-3 form-check">
        <input type="checkbox" className="form-check-input" id="ConNotebook" {...register("ConNotebook")}/>
        <label className="form-check-label" htmlFor="ConNotebook">Ingresa con Notebook</label>
      </div>
      <button type="submit" className="btn btn-primary">Enviar</button>
    </form>
  )}
  {action !== "R" && (
    <Consulta rows={rows} onVolver={onVolver}></Consulta>
  )}
</div>

    )
}
