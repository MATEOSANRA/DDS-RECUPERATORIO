import React from "react";

export default function Consulta({ rows, onVolver }) {
    return (
        <div className="container mt-5">
            <h5 className="text-center mb-4">Consulta de Datos</h5>
            <div className="table-responsive">
                <table className="table table-striped table-hover">
                    <thead className="table-dark">
                        <tr>
                            <th scope="col">DNI</th>
                            <th scope="col">Hora Ingreso</th>
                            <th scope="col">Proveedor</th>
                            <th scope="col">Ingresa con Notebook</th>
                        </tr>
                    </thead>
                    <tbody>
                        {rows.map((item, index) => (
                            <tr key={index}>
                                <td>{item.Dni}</td>
                                <td>{item.HoraIngreso}</td>
                                <td>{item.Proveedor}</td>
                                <td>{item.ConNotebook ? "Sí" : "No"}</td> 
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            <div className="text-center mt-4">
                <button className="btn btn-primary" onClick={onVolver}>
                    Volver al Registro
                </button>
            </div>
        </div>
    );
}

//el ? si : no indica que va a mostrar si el checkbox esta marcado o no 