const url = 'http://localhost:3001/ingresos'

async function getIngresos(){
    const res = await fetch(url)
    const data = await res.json()
    return data
}

async function saveIngreso(proyecto){
    const requestOptions = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(proyecto)
    }

    const res = await fetch(url, requestOptions)
    const data = await res.json()
    return data
}

export default {getIngresos, saveIngreso}