import React from "react";
import {Link} from "react-router-dom"

export function Menu(){
    return(
        <div>
            <h4>Parcial DDS</h4>
            <Link className="btn btn-primary" to="lista-canciones"/>Consulta<Link/>
             <Link  className="btn btn-primary" to="nueva-cancion"/>Registrar<Link/>
        </div>
    )
}