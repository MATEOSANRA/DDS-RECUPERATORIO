import React from "react";

export function Tabla({ rows, onVolver }) {
    return (
        <div>
            <table className="table table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nombre</th>
                        <th>Álbum</th>
                        <th>Artista</th>
                        <th>Género</th>
                        <th>Duración (ms)</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        rows && rows.map((e, index) => (
                            <tr key={e.trackId || index + 1}>
                                <td>{e.trackId}</td>
                                <td>{e.name}</td>
                                <td>{e.album}</td>
                                <td>{e.artistName}</td>
                                <td>{e.genre}</td>
                                <td>{e.milliseconds}</td>
                            </tr>
                        ))
                    }
                </tbody>
            </table>
            <button style={{ textAlign: 'center' }} onClick={onVolver} className='btn btn-secondary'>Volver</button>
        </div>
    );
}
