import React, { useState, useEffect } from "react";
import { Tabla } from "./Tabla";
import service from "../services/tracks.service";
import getGenres from "../services/genre.service";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";

export default function Consulta() {
    const [rows, setRows] = useState([]);
    const [genres, setGenres] = useState([]);
    const { register, handleSubmit } = useForm();
    const navigate = useNavigate();

    useEffect(() => {
        const loadData = async () => {
            const data = await service.getTracks();
            setRows(data);
        };
        loadData();

        const loadGenres = async () => {
            const genresData = await getGenres();
            setGenres(genresData);
        };
        loadGenres();
    }, []);

    const onVolver = () => {
        navigate("/");
    };

    const filterSubmit = async (filterData) => {
        try {
            const filter = filterData.filter || ""; 
            const genre = filterData.genre || ""; 
            const reposFiltrados = await service.getTracksFiltrados(filter, genre);
            setRows(reposFiltrados);
        } catch (error) {
            console.error("Error fetching filtered repos:", error);
        }
    };

    return (
        <div>
            <div>
                <form onSubmit={handleSubmit(filterSubmit)}>
                    <div className="form-group mb-3">
                        <label htmlFor="filter" className="form-label">Nombre Cancion</label>
                        <input type="text" id="filter" className="form-control" {...register("filter")} />
                    </div>
                    <div className="form-group mb-3">
                        <label htmlFor="genre" className="form-label">Género</label>
                        <select id="genre" className="form-control" {...register("genre")}>
                            <option value="">Todos los géneros</option>
                            {genres.map((genre, index) => (
                                <option key={index + 1} value={genre}>
                                    {genre}
                                </option>
                            ))}
                        </select>
                    </div>
                    <button type="submit" className="btn btn-primary">
                        Filtrar
                    </button>
                </form>
            </div>
            <div className='container_app'>
                <h5>Lista de Proyectos</h5>
                <Tabla rows={rows} onVolver={onVolver}></Tabla>
            </div>
        </div>
    );
}
