import React, { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import service from "../services/tracks.service";
import getGenres from "../services/genre.service";

export default function RegistroCancion() {
    const [genres, setGenres] = useState([]);
    const { register, handleSubmit, setError, formState: { errors } } = useForm();
    const navigate = useNavigate();

    useEffect(() => {
        const loadGenres = async () => {
            try {
                const genresData = await getGenres();
                setGenres(genresData);
            } catch (error) {
                console.error("Error fetching genres:", error);
            }
        };
        loadGenres();
    }, []);

    const onSubmit = async (data) => {
        try {
            const newTrack = {
                name: data.name,
                album: data.album,
                artistName: data.artistName,
                composer: data.composer,
                milliseconds: data.milliseconds,
                genre: data.genre,
                mediaType: data.mediaType
            };

            await service.addTrack(newTrack);
            navigate("/lista-canciones");
        } catch (error) {
            console.error("Error adding track:", error);
        }
    };

    return (
        <div className='container_app'>
            <form onSubmit={handleSubmit(onSubmit)}>
                <h5>Agregar Canción</h5>
                <div className="form-group">
                    <label htmlFor="name">Nombre:</label>
                    <input type="text" className="form-control" id="name" {...register("name", { required: 'Este campo es requerido' })} />
                    {errors.name && <span className='error'>{errors.name.message}</span>}
                </div>
                <div className="form-group">
                    <label htmlFor="album">Álbum:</label>
                    <input type="text" className="form-control" id="album" {...register("album", { required: 'Este campo es requerido' })} />
                    {errors.album && <span className='error'>{errors.album.message}</span>}
                </div>
                <div className="form-group">
                    <label htmlFor="artistName">Nombre del Artista:</label>
                    <input type="text" className="form-control" id="artistName" {...register("artistName", { required: 'Este campo es requerido' })} />
                    {errors.artistName && <span className='error'>{errors.artistName.message}</span>}
                </div>
                <div className="form-group">
                    <label htmlFor="composer">Compositor/es:</label>
                    <input type="text" className="form-control" id="composer" {...register("composer", { required: 'Este campo es requerido' })} />
                    {errors.composer && <span className='error'>{errors.composer.message}</span>}
                </div>
                <div className="form-group">
                    <label htmlFor="milliseconds">Duración (ms):</label>
                    <input type="number" className="form-control" id="milliseconds" {...register("milliseconds", { required: 'Este campo es requerido', valueAsNumber: true })} />
                    {errors.milliseconds && <span className='error'>{errors.milliseconds.message}</span>}
                </div>
                <div className="form-group">
                    <label htmlFor="genre">Género:</label>
                    <select id="genre" className="form-control" {...register("genre", { required: 'Este campo es requerido' })}>
                        <option value="">Seleccione un género</option>
                        {genres.map((genre, index) => (
                            <option key={index + 1} value={genre}>
                                {genre}
                            </option>
                        ))}
                    </select>
                    {errors.genre && <span className='error'>{errors.genre.message}</span>}
                </div>
                <div className="form-group">
                    <label htmlFor="mediaType">Tipo de Codificación:</label>
                    <input type="text" className="form-control" id="mediaType" {...register("mediaType", { required: 'Este campo es requerido' })} />
                    {errors.mediaType && <span className='error'>{errors.mediaType.message}</span>}
                </div>
                <div className="form-group text-center mt-3">
                    <button type="submit" className="btn btn-primary mx-1">Registrar</button>
                    <button type="reset" className="btn btn-secondary mx-1">Limpiar</button>
                    <button type="button" className="btn btn-secondary mx-1" onClick={() => navigate("/")}>Volver</button>
                </div>
            </form>
        </div>
    );
}
