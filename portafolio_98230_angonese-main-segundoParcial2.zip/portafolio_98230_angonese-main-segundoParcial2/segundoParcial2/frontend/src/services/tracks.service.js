import axios from 'axios';

const URL = "http://localhost:3001/api/tracks";

async function getTracks() {
    const response = await axios.get(URL);
    return response.data;
}

async function getTracksFiltrados(name, genre) {
    const response = await axios.get(URL, {
        params: {
            filterText: name,
            genre: genre
        }
    });
    return response.data;
}

async function addTrack(track) {
    const response = await axios.post(URL, track);
    console.log(response.data)
    return response.data;
}

const service = { getTracks, getTracksFiltrados, addTrack };

export default service;
