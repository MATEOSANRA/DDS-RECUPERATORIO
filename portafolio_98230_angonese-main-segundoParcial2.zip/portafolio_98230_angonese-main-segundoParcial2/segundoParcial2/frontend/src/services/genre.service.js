import axios from "axios";

const URL = "http://localhost:3001/api/genres"
export default async function getGenres(){
    const data = await axios.get(URL)
    return data.data
}