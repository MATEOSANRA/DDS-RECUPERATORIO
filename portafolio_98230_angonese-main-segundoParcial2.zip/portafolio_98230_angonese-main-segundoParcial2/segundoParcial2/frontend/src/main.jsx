import React from 'react'
import ReactDOM from 'react-dom/client'
import { Menu } from './components/Menu.jsx'
import Consulta from './components/Consulta.jsx'
import {  BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import RegistroCanciones from './components/RegistroCanciones.jsx'

import 'bootstrap/dist/css/bootstrap.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <div>
    <Router>
        <div>
          <Routes>
            <Route path='/' element={<Menu/>} />
            <Route path='lista-canciones' element={<Consulta />}/>
            <Route path='nueva-cancion' element={<RegistroCanciones/>}/>
          </Routes>
        </div>
      </Router>

  </div>,
)
