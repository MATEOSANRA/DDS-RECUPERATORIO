import Contador from "./components/Contador";
import Contenedor from "./components/Contenedor";
import '../node_modules/bootstrap/dist/css/bootstrap.css';
import '../node_modules/bootstrap-icons/font/bootstrap-icons.css';

const App = ()=>{
    return(
        <>
            <Contenedor></Contenedor>
        </>
    );
}

export default App;