import {useState} from 'react';
import Tarea from './Tarea';

const Lista = ({lista, removerTarea})=>{
   return(
       <ul className='list-group'>
        {lista.map((t,i) => <Tarea 
            tarea={t} 
            key={t.id} 
            removerTarea={removerTarea}/>)
        }
       </ul>
   );
}

export default Lista;