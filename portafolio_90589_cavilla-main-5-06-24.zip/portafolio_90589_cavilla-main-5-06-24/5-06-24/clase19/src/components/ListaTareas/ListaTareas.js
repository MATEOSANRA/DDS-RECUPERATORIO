import {useState} from 'react';
import Titulo from './Titulo';
import Agregar from './Agregar';
import Lista from './Lista';

const Contenedor = ()=>{
    const [lista, setLista] = useState([]);

    const agregarTarea = (tarea) =>{
        setLista([...lista, tarea]);
    }

    const removerTarea = id => {
        let nuevaLista = lista.filter(t => t.id !== id);
        setLista(nuevaLista);
    }


   return(
        <div className="container col-md-8 text-center">
            <Titulo>Lista de Tareas</Titulo>
            <Agregar agregarTarea={agregarTarea}></Agregar>
            <Lista lista={lista} removerTarea={removerTarea}></Lista>
        </div>
   );
}

export default Contenedor;