import {useState} from 'react';

const Tarea = ({tarea, removerTarea})=>{
   const [realizada, setRealizada] = useState(tarea.realizada);
    let estilo = {
        textDecoration: realizada && 'line-through', 
        color: realizada && 'red'
    }
   return(
       <li className='list-group-item text-start'>
            <input type="checkbox" 
            className="form-check-input me-1"
            onChange={(e)=>{
                setRealizada(e.target.checked);
                console.log(e.target.checked)
            }}
            checked={realizada?'checked':''} />
            <label 
            className="form-check-label ms-2" 
            style={estilo}>
                {tarea.nombre}
            </label>
            <button 
                className='float-end btn btn-default' 
                onClick={(e) =>removerTarea(tarea.id)}>
                <i className='bi bi-trash'></i>
            </button>
             
       </li>
   );
}

export default Tarea;