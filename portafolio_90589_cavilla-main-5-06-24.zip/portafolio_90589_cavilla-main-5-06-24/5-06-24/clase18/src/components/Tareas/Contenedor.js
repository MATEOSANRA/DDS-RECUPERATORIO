import {useState} from 'react';
import Titulo from './Titulo';
import Agregar from './Agregar';
import Lista from './Lista';

const Contenedor = ()=>{
    const [lista, setLista] = useState([]);

    const agregarTarea = (tarea) =>{
        lista.push(tarea);
        setLista(lista);
        console.log('Agregando', tarea);
    }


   return(
       <>
        <Titulo>Lista de Tareas</Titulo>
        <Agregar agregarTarea={agregarTarea}></Agregar>
        <Lista></Lista>
       </>
   );
}

export default Contenedor;