import {useState} from 'react';

const Tarea = ()=>{
   return(
       <>
       <p>Tarea anda!</p>
       </>
   );
}

export default Tarea;