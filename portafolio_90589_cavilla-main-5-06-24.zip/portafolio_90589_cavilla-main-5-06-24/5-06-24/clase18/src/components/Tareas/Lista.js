import {useState} from 'react';

const Lista = ()=>{
   return(
       <>
       <p>Lista anda!</p>
       </>
   );
}

export default Lista;