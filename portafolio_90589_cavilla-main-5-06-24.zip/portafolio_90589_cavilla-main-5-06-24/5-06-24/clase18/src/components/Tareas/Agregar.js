import {useState} from 'react';

const Agregar = ({agregarTarea})=>{
   const [nombre, setNombre] = useState('');
   
   const changeNombre = (e) =>{
        setNombre(e.target.value);
   }

   const handleAgregarTarea = () => {

    }

    const handleSubmit = (e)=>{
        e.preventDefault();
        agregarTarea({
            id: window.crypto.randomUUID(),
            nombre: nombre,
            realizada: false
        });
        setNombre('');

    }

   return(
       <form onSubmit={handleSubmit}>
        <input type="text" onChange={changeNombre} value={nombre} />
        <button disabled={nombre===''} onClick={handleAgregarTarea}>Agregar Tarea</button>
       </form>
   );
}

export default Agregar;