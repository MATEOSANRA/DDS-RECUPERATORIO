import Contador from "./components/Contador";
import Contenedor from "./components/Contenedor";

const App = ()=>{
    return(
        <>
            <Contenedor></Contenedor>
        </>
    );
}

export default App;