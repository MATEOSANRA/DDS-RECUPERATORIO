// CLASE DEL VIERNES 05/04/24

console.log("Hello world");

let a = 45;
console.log("Número: ", a);

console.log(typeof a);

const aa = 45;
console.log(aa);

/*aa = 'hola';
console.log(aa);*/

m = "Micaela";
console.log(m[2]);

m[2] = "k";
console.log(m);

console.log(m.length);

let saludo = "Hola " + m;
console.log(saludo);

console.log("================================");
let plantilla = `${saludo}, 
            gracias por elegirnos`;
console.log(plantilla);

let deuda = 2000;

if (deuda > 500) {
  console.log("Te vas a quedar pobre :(");
} else {
  console.log("Gracias por debernos poca plata :)");
}

console.log("================================");

console.log("================================");

console.log(plantilla);

let deuda2 = 2000;

if (deuda2 === 2000) {
  console.log("Te vas a quedar pobre :(");
} else {
  console.log("Gracias por debernos poca plata :)");
}

console.log("================================");


let key = 8;
switch (key) {
  case 1:
    console.log("Opcion 1 elegida");
    break;

  case 2:
    console.log("Opcion 2 elegida");
    break;

  case 3:
    console.log("Opcion 3 elegida");
    break;

  default:
    console.log("No elegiste opc valida");
    break;
}

console.log(
    deuda > 500 ?
    `Te vas a quedar pobre de nuevo` :
    `Debes poquito`
);



let i = 5;
while (i>0) {
    console.log('ciclo while ', i);
    i = i - 1
}

for (let f = 0; f < 5; f++) {
    console.log('ciclo for ', f);
    
}

let j = 0;
do {
    console.log('ciclo dowhile ', j);
    j = j + 1
} while (j < 4);

let k = 0;
do {
    console.log(k);
    k++;
} while (k < 8);


let v = []
v.push(1)
v.push(2)

console.log(v);
console.log('elemento 2: ', v[1]);

v.push(3)
v.push(4)
console.log(v);
v.pop()
console.log(v);
v.shift()
console.log(v);
v.unshift(1)
console.log(v);
v.unshift(0)
console.log(v);