
/* Desarrollar un programa Javascript que genere 1000000 de números aleatorios enteros. Para ello debe utilizarse la librería seedrandom y al hacerlo debe utilizar como semilla el número: 1763519 y obtener cada siguiente número aleatorio con llamadas al método int32.

A partir del conjunto de números generados se solicita obtener los siguientes resultados:

Cantidad de números positivos y cantidad de números negativos.
Cantidad de números cuyo resto al dividirlos en 7 sea exactamente 0, 3, 5 o 6.
Un arreglo de contadores que indique la cantidad de números según su anteúltimo dígito (el de las decenas) coincida con el índice. De esta manera el número 2134 debe contarse en la posición 3 del arreglo, el número 32405 en la posición 0 del arreglo y así sucesivamente. Evidentemente el arreglo va a ser de 10 contadores con índices del 0 al 9 y deberá ser cargado usando llaves y valores separados por comas.
Valor y posición del menor de todos. La posición del primer número generado debe considerarse como 1, es decir no se pide el índice del valor en el arreglo sino el número de orden del mismo.
Cantidad de números cuyo signo sea igual al del anterior, evidentemente el primer elemento del conjunto no puede ser contabilizado porque no tiene anterior, es decir el máximo posible es la cantidad de elementos generados menos 1.
Promedio entero (redondeado con Math.round) de todos los números que contengan exactamente 6 dígitos. */

// Importo la librería seedrandom
const seedrandom = require('seedrandom');

const seed = 1763519;
const rng = seedrandom(seed);
let numerosAleatorios = [];

// Generación del array de números random
for (let i = 0; i < 1000000; i++) {
    const numeroAleatorio = rng.int32();
    numerosAleatorios.push(numeroAleatorio);
}


// Funciones
function calcModulo(numero, divisor) {
    return numero % divisor
}

function anteultimo(numero) {
    const numeroCadena = numero.toString();
    let anteultimo = numeroCadena[numeroCadena.length - 2]
    return parseInt(anteultimo)
}

function seisDigitos(numero) {
    const numeroCadena = numero.toString();
    let digitos = numeroCadena.length;

    // Para que no se cuente el signo - como un dígito
    if (numero < 0) {
        digitos = numeroCadena.length - 1;
    }

    if (digitos === 6) {
        return true
    } else {
        return false
    }
}

function promedio(suma, cantidad) {
    return Math.round(suma / cantidad)
}



// Inicialización de variables y contadores
let indice = 0;

let contPos = 0;
let contNeg = 0;

let contModulos = 0;

let contAnteultimos = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

let menor;
let posMenor;

let anterior;
let cantIgualSigno = 0;

let sumaSeisDigitos = 0;
let cantSeisDigitos = 0;

numerosAleatorios.forEach(numero => {

    // Consigna 1
    if (numero > 0) {
        contPos++
    } else {
        if (numero < 0) {
            contNeg++
        }
    };

    // Consigna 2
    let modulo = calcModulo(numero, 7);
    if (modulo === 0 ||
        modulo === 3 ||
        modulo === 5 ||
        modulo === 6) {
        contModulos++
    };

    // Consigna 3
    contAnteultimos[anteultimo(numero)]++;

    // Consigna 4
    if (indice === 0 || numero < menor) {
        menor = numero;
        posMenor = indice + 1;
    };

    // Consigna 5
    if (indice > 0 &&
        ((numero < 0 && anterior < 0) ||
            (numero > 0 && anterior > 0))) {
        cantIgualSigno++;
    };
    anterior = numero;

    // Consigna 6
    if (seisDigitos(numero)) {
        sumaSeisDigitos = sumaSeisDigitos + numero
        cantSeisDigitos++
    };

    // Contador del número de vueltas
    indice++;
});

// Cálculo del promedio de los números con 6 dígitos
let promedioSeisDigitos = promedio(sumaSeisDigitos, cantSeisDigitos)

console.log();
console.log('================================================================================================================');
console.log('CONSIGNA 1');
console.log("- Cantidad de números positivos: ", contPos);
console.log("- Cantidad de números negativos: ", contNeg);
console.log();
console.log('CONSIGNA 2');
console.log("- Cantidad de números cuyo módulo en 7 sea exactamente 0, 3, 5 o 6: ", contModulos);
console.log();
console.log('CONSIGNA 3');
console.log("- Arreglo de contadores que indica la cantidad de números según su anteúltimo dígito (coincide con el índice): ");
console.table(contAnteultimos);
console.log();
console.log('CONSIGNA 4');
console.log("- Valor del menor de todos: ", menor);
console.log("- Posición del menor de todos: ", posMenor);
console.log();
console.log('CONSIGNA 5');
console.log("- Cantidad de números cuyo signo es igual al del anterior: ", cantIgualSigno);
console.log();
console.log('CONSIGNA 6');
console.log("- Promedio entero los números de 6 dígitos: ", promedioSeisDigitos);
console.log('================================================================================================================');