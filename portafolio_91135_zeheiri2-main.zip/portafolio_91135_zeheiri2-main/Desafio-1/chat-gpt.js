// Importar la librería seedrandom
const seedrandom = require('seedrandom');

// Semilla para reproducibilidad
const seed = 1763519;

// Crear una función para generar números aleatorios enteros
function generarNumerosAleatorios(cantidad) {
    // Inicializar el generador de números aleatorios con la semilla
    const rng = seedrandom(seed);
    
    // Array para almacenar los números generados
    const numerosAleatorios = [];
    
    // Generar los números aleatorios enteros
    for (let i = 0; i < cantidad; i++) {
        // Generar el siguiente número aleatorio entero
        const numeroAleatorio = rng.int32();
        
        // Agregar el número aleatorio al array
        numerosAleatorios.push(numeroAleatorio);
    }
    
    return numerosAleatorios;
}

// Función para contar la cantidad de números positivos y negativos
function contarPositivosNegativos(numeros) {
    let positivos = 0;
    let negativos = 0;
    
    numeros.forEach(numero => {
        if (numero >= 0) {
            positivos++;
        } else {
            negativos++;
        }
    });
    
    return { positivos, negativos };
}

// Función para contar la cantidad de números con resto 0, 3, 5 o 6 al dividirlos por 7
function contarRestoMod7(numeros) {
    const restoMod7 = [0, 0, 0, 0];
    
    numeros.forEach(numero => {
        const resto = Math.abs(numero % 7);
        if (resto === 0 || resto === 3 || resto === 5 || resto === 6) {
            restoMod7[resto]++;
        }
    });
    
    return restoMod7;
}

// Función para contar la cantidad de números según su anteúltimo dígito
function contarAnteultimoDigito(numeros) {
    const contadores = Array.from({ length: 10 }, () => 0);
    
    numeros.forEach(numero => {
        const anteultimo = Math.floor(Math.abs(numero / 10) % 10);
        contadores[anteultimo]++;
    });
    
    return contadores;
}

// Función para encontrar el valor y la posición del menor número
function encontrarMenorNumero(numeros) {
    let menor = numeros[0];
    let posicion = 1;
    
    for (let i = 1; i < numeros.length; i++) {
        if (numeros[i] < menor) {
            menor = numeros[i];
            posicion = i + 1;
        }
    }
    
    return { valor: menor, posicion };
}

// Función para contar la cantidad de números cuyo signo sea igual al del anterior
function contarSignoIgualAnterior(numeros) {
    let cantidad = 0;
    
    for (let i = 1; i < numeros.length; i++) {
        if (Math.sign(numeros[i]) === Math.sign(numeros[i - 1])) {
            cantidad++;
        }
    }
    
    return cantidad;
}

// Función para calcular el promedio entero de los números con exactamente 6 dígitos
function promedio6Digitos(numeros) {
    let suma = 0;
    let cantidad = 0;
    
    numeros.forEach(numero => {
        if (Math.abs(numero) >= 100000 && Math.abs(numero) < 1000000) {
            suma += numero;
            cantidad++;
        }
    });
    
    return Math.round(suma / cantidad);
}

// Generar 1,000,000 de números aleatorios enteros
const numerosAleatorios = generarNumerosAleatorios(1000000);

// Obtener resultados
const resultados = {
    positivosNegativos: contarPositivosNegativos(numerosAleatorios),
    restoMod7: contarRestoMod7(numerosAleatorios),
    anteultimoDigito: contarAnteultimoDigito(numerosAleatorios),
    menorNumero: encontrarMenorNumero(numerosAleatorios),
    cantidadSignoIgualAnterior: contarSignoIgualAnterior(numerosAleatorios),
    promedio6Digitos: promedio6Digitos(numerosAleatorios)
};

// Imprimir resultados
console.log("Cantidad de números positivos:", resultados.positivosNegativos.positivos);
console.log("Cantidad de números negativos:", resultados.positivosNegativos.negativos);
console.log("Cantidad de números con resto 0, 3, 5 o 6 al dividirlos por 7:", resultados.restoMod7);
console.log("Contadores según el anteúltimo dígito:", resultados.anteultimoDigito);
console.log("Valor del menor número:", resultados.menorNumero.valor, "en la posición", resultados.menorNumero.posicion);
console.log("Cantidad de números cuyo signo sea igual al del anterior:", resultados.cantidadSignoIgualAnterior);
console.log("Promedio entero de los números con exactamente 6 dígitos:", resultados.promedio6Digitos);
