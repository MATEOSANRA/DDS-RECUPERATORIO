const express = require('express');
const app = express();

let numeros = new Array(10).fill(0).map(() => Math.floor(Math.random() * 100))
console.log(numeros);
app.get('/numeros', (req, res) => {
    res.send(numeros);
    res.end()
})

app.get('/numeros/:buscado', (req, res) => {
    const x = parseInt(req.params.buscado)
    res.write(`Existe el número ${x}?`)
    if (numeros.includes(x)) {
        res.write('Si')
    } else {
        res.write('No')
        res.end()
    }
})

app.post('/numeros/:nuevo', (req, res) => {
    const x = parseInt(req.params.nuevo)
    numeros.push(x)
    res.end()

})

app.listen(8080);