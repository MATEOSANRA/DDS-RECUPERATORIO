const http = require('http');
let cantidad = 0;

const server = http.createServer(
    (request, response) => {
        cantidad++
        response.end(`Hola mundo:  ${cantidad}`)
    }
);

server.listen(8080, 'localhost');


let contador = "*";
app.get('/', (req, res) => {
    contador += "*";
    res.end(contador)
})