import { Op } from 'sequelize';
import { Canciones } from '../models/canciones.js';

export class GestorCanciones {

    async cancionesDeAmor() {
        return await Canciones.findAll({
            where: {
                [Op.and]: [
                    { name: { [Op.like]: '%love%' } },
                    { genre: { [Op.or]: ['Blues', 'Jazz', 'Latin'] } }
                ]
            },
            order: [['milliseconds', 'DESC']]

        })
    }
}