import { Model, DataTypes } from "sequelize";
import sequelize from "../data/db.js";

export const Canciones = sequelize.define(
    "Tracks_Data", 
    {
        id: { 
            type: DataTypes.TEXT, 
            primaryKey: true,
            field: "TRACK_ID"
        },
        nombre: { 
            type: DataTypes.STRING,
            field: "NAME"
        },
        album: { 
            type: DataTypes.TEXT,
            field: "ALBUM" 
        },
        artista: { 
            type: DataTypes.TEXT,
            field: "ARTIST_NAME" 
        },
        compositor: { 
            type: DataTypes.TEXT,
            field: "COMPOSER" 
        },
        duracion: { 
            type: DataTypes.TEXT,
            field: "MILLISECONDS" 
        },
        genero: { 
            type: DataTypes.TEXT,
            field: "GENRE" 
        },
        tipoAudio: { 
            type: DataTypes.REAL,
            field: "MEDIA_TYPE" 
        },
    },
    {
        sequelize,
        tableName: "Tracks_Data",
        timestamps: false
    }
);