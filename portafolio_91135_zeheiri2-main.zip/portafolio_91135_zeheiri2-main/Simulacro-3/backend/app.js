import express from "express";
import dotenv from "dotenv";
import cors from "cors";

import dbInit from "./data/db-init.js";

import { GestorCanciones } from './services/canciones.service.js';

dotenv.config();

const app = express();

const gestor = new GestorCanciones();

app.use(cors());

app.get("/status", (req, res) => {
    res.json({ respuesta: "API iniciada y escuchando..." });
});

app.get('/tracks', async (req, res) => {
    const cancionesAmor = await gestor.cancionesDeAmor()
    res.send(cancionesAmor)
})

async function start() {
    const PORT = process.env.PORT || 3000;

    // Inicializar la conexión a la base de datos
    await dbInit();

    // Iniciar el servidor
    app.listen(PORT, () => {
        console.log(`Servidor iniciado y escuchando en el puerto ${PORT}`);
    });
}
start();
