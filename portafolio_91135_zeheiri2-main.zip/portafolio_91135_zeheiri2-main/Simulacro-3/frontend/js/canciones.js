const URL_API = 'http://localhost:3001'


const mostrarCancionesAmor = async () => {
    const tableBody = document.getElementById('datos');

    const res = await fetch(`${URL_API}/tracks`);

    const cancionesAmor = await res.json();

    if (tableBody) {

        tableBody.innerHTML = ``;

        cancionesAmor.forEach(cancion => {
            let fila = `
                <tr>
                    <th scope="row">${cancion.id}</th>
                    <td>${cancion.nombre}</td>
                    <td>${cancion.album}</td>
                    <td>${cancion.artista}</td>
                    <td>${cancion.genero}</td>
                    <td>${cancion.duracion}</td>
                </tr>
            `;

            tableBody.innerHTML += fila
        });
    }
}



document.addEventListener('DOMContentLoaded', async () => { mostrarCancionesAmor(); console.log('CARGA'); })