const express = require('express');
const cors = require('cors');
const PORT = 3000;

const app = express();
app.use(cors());


// ----- Esto en archivo db.js ----
const { Sequelize, DataTypes } = require('sequelize');
const sequelize = new Sequelize({
    dialect: 'sqlite',
    storage: './cursos.sqlite'
});
// --------------------------------

const Cursos = sequelize.define('Cursos', {
    id: {type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true},
    nombre: {type: DataTypes.TEXT},
    nivel: {type: DataTypes.INTEGER}
});

const initDb = async () => {
    await sequelize.sync();
    await Cursos.truncate();
    await Cursos.bulkCreate([
        {nombre: 'Curso 1', nivel: 2},
        {nombre: 'Curso 2', nivel: 2},
        {nombre: 'Curso 3', nivel: 1},
        {nombre: 'Curso 4', nivel: 2},
        {nombre: 'Curso 5', nivel: 1},
        {nombre: 'Curso 6', nivel: 1},
        {nombre: 'Curso 7', nivel: 2},
        {nombre: 'Curso 8', nivel: 2},
        {nombre: 'Curso 9', nivel: 2},
        {nombre: 'Curso 10', nivel: 2},
        {nombre: 'Curso 11', nivel: 1},
        {nombre: 'Curso 12', nivel: 2},
        {nombre: 'Curso 13', nivel: 1},
        {nombre: 'Curso 14', nivel: 1},
        {nombre: 'Curso 15', nivel: 1},
        {nombre: 'Curso 16', nivel: 1},
    ])
};

initDb();

app.get('/', (req, res) => {
    res.end('<h1>HOME</h1>');
});

app.get('/cursos', async (req, res) => {
    const datos = await Cursos.findAll();
    res.json(datos);
});

app.get('/cursos/:nivel', async (req, res) => {
    const pNivel = req.params.nivel;
    let filtro = {where: {nivel: pNivel}};
    if (pNivel == 0) {
        filtro = {} // No hay filtro porque el nivel 0 era "todos", así que busca TODOS los niveles que hay
    };

    const datos = await Cursos.findAll(filtro);
    res.json(datos);
});

app.listen(PORT, () => { console.log(`Servidor corriendo en http://localhost:${PORT}`)});

