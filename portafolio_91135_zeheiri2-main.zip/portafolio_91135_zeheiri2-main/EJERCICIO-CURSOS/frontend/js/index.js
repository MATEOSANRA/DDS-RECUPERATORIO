const cargarDatos = async () => {
    const contenedorCursos = document.getElementById('contenedorCursos');
    if (contenedorCursos) {
        let nivel = 0;
        const opcNivel = document.getElementById('opcNivel');
        if (opcNivel) {
            nivel = opcNivel.value;
        }

        const res = await fetch(`http://localhost:3000/cursos/${nivel}`);
        const datos = await res.json();
        let contenido = `<table class="table">`;
        contenido += `
        <thead>
            <tr>
                <th class="bg-info-subtle">Id</th>
                <th class="bg-info-subtle">Nombre</th>
                <th class="bg-info-subtle">Nivel</th>
            </tr>
        </thead>
        <tbody>
        `

        datos.forEach(curso => {
            contenido += `
                <tr>
                    <td>${curso.id}</td>
                    <td>${curso.nombre}</td>
                    <td>${curso.nivel}</td>
                </tr>
            `
        });

        contenido += `
            </tbody>
        </table>
        `

        contenedorCursos.innerHTML = contenido;
    }
};

const btnCargarCursos = document.getElementById('btnCargarCursos');
if (btnCargarCursos) {
    btnCargarCursos.addEventListener('click', () => { cargarDatos() })
}