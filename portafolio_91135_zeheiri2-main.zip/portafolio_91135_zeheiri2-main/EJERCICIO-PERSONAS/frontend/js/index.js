// Función que se llama cada vez que se hace click sobre el botón buscar
const cargarDatos = async () => {

    // Traemos el elemento (un div) que va a contener los otros elementos a agregar desde esta función para mostrar los resultados (una tabla)
    const contenedorTabla = document.getElementById('contenedorTabla');

    // Preguntamos si el contenedor existe
    if (contenedorTabla) {

        // Traemos el elemento input del apellido de la página HTML
        const inputApellido = document.getElementById('inputApellido');

        // Guardamos su valor en la  variable apellido
        // Lo convertimos en mayúsculas para que lo busque aún cuando se lo escribió en minúscula (en la DB están con mayúsculas)
        const apellido = inputApellido.value.toUpperCase();


        // LLamamos al servidor del backend, pasando como parámetro el apellido a buscar
        // (Esa ruta es la que aparece en el endpoint app.get del archivo index.js del backend)
        const res = await fetch(`http://localhost:8000/personas/${apellido}`);

        // Guardamos en la variable datos la respuesta del fetch
        // (Recibimos lo que manda la línea res.send(personasXapellido) dentro del endpoint)
        const datos = await res.json();

        // Creamos la tabla que se va a mostrar una vez que se obtengan los datos desde el back
        let contenido = `<table class="table">`

        // Esta es la cabecera de la tabla, los títulos que aparecen en cada columna
        // La apertura del tbody se pone acá porque tiene que envolver todas las filas juntas, si lo ponemos en el forEach se repetiría en cada fila
        contenido += `
        <thead class="table-light">
            <tr>
                <th class="bg-success-subtle">Documento</th>
                <th class="bg-success-subtle">Nombre</th>
                <th class="bg-success-subtle">Apellido</th>
                <th class="bg-success-subtle">Edad</th>
            </tr>
        </thead>
        <tbody class="table-group-divider">
        `

        // Acá se recorren los datos obtenidos desde el back
        // Para cada persona que se trajo, se crea una fila de la tabla con sus respectivos datos
        // Al "persona" lo podría haber llamado cualquier otra cosa, pero los atributos sí tienen que llamarse igual que en la base de datos
        datos.forEach(persona => {
            contenido += `
            <tr>
                <td>${persona.documento}</td>
                <td>${persona.nombre}</td>
                <td>${persona.apellido}</td>
                <td>${persona.edad}</td>
            </tr>
            `
        });

        // Cerramos las etiquetas que quedaban abiertas todavía
        contenido += `
        </tbody>
        </table>
        `
        // Anexamos la tabla generada en el contenedor (etiqueta div) que tenemos en index.html
        contenedorTabla.innerHTML = contenido;
    }
};


// Guardamos el botón del input en una variable
const btnBuscar = document.getElementById('btnBuscar');

if (btnBuscar) {
    // Si el botón existe, cada vez que se le hace click ejecuta la función cargarDatos()
    btnBuscar.addEventListener('click', () => { cargarDatos() }); // Si no se pone dentro de otra función, no se ejecuta
}