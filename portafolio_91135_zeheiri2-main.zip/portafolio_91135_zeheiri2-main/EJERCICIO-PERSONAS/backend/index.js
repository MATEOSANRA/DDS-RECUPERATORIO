// Este vendría a ser nuestro servidor, el archivo principal de nuestra app donde codeamos todo lo que tiene que hacer


// Guardamos toda la librería de express en la variable para poder usarla
import express from 'express';

// Traemos la definición de la DB
import { sequelize } from './db.js';

// Traemos el gestor de la clase Persona para poder usar sus métodos
import { GestorPersonas } from './personas.service.js';

// CORS permite que el navegador del cliente (front) compruebe con los servidores de terceros (back) si la solicitud está autorizada antes de realizar cualquier transferencia de datos
import cors from 'cors';

// Indicamos el puerto a usar
const PORT = 8000;


// Guardamos todo lo que tiene que hacer la app en la función main()
async function main() {

    // Inicializamos la app de express
    const app = express();

    // Realizamos la conexión a la DB
    await sequelize.sync();

    // Esto genera el middleware de CORS desde express
    app.use(cors());

    // Creamos una instancia del gestor mediante su constructor, porque si lo usamos directamente, devuelve undefined y da error
    const gestor = new GestorPersonas();


    // (A este endpoint lo accedemos desde el frontend sólo cuando no se escribe ningún apellido en el input y se hace click en Buscar)
    // Cuando se dirija a la ruta http://localhost:${PORT}/personas va a mostrar todas las personas de la DB
    app.get('/personas', async (req, res) => {

        // Ejecuta el método del gestor de la clase persona
        const todas = await gestor.obtenerTodas()

        // Envía los datos de todas las personas (se reciben en el fetch del front para pasar a la tabla)
        res.send(todas)
    })

    // Cuando se dirija a la ruta http://localhost:${PORT}/personas/{un apellido} va a mostrar todas las personas con ese mismo apellido
    app.get('/personas/:apellido', async (req, res) => {

        // Guardo en la variable el valor del parámetro apellido pasado en la ruta
        const pApellido = req.params.apellido;

        // Ejecutamos el método del gestor para filtar por apellido
        const personasXapellido = await gestor.obtenerPorApellido(pApellido);

        // Envía los resultados de la búsqueda (se reciben en el fetch del front para pasar a la tabla)
        res.send(personasXapellido)
    });


    // Le indicamos a nuestro servidor en qué puerto debe correr
    // Hace un log de la ruta para poder acceder desde el link, pero no es necesario, se puede escribir la ruta en el navegador directamente
    app.listen(PORT, () => { console.log(`Servidor corriendo en http://localhost:${PORT}/personas`) })
}


// Llamamos a la función main() para que se ejecute nuestro servidor cuando ejecutemos este archivo
main();