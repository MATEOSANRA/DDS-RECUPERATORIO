// Acá definimos la clase Persona y un método

import { Model, DataTypes } from "sequelize";
import { sequelize } from "./db.js";


// Definimos la clase Persona
export const Persona = sequelize.define(
    "Persona", // Nombre de la clase
    {
        documento: { type: DataTypes.INTEGER, primaryKey: true },
        nombre: { type: DataTypes.STRING },
        apellido: { type: DataTypes.STRING },
        edad: { type: DataTypes.INTEGER },
    },
    {
        sequelize, // Le indicamos la base de datos donde se tiene que almacenar la nueva persona
        modelName: "persona", // Nombre de la tabla
        timestamps: false // Sirve para llevar un registro de cuándo se creó este nuevo objeto
    }
);


// Le agregamos un método a la clase Persona, se ejecuta cada vez que creamos una nueva persona
Persona.prototype.toString = function () {
    return `${this.nombre} ${this.apellido} ${this.edad}`;
};