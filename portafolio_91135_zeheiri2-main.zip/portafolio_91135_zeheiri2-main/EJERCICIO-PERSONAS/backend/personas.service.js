// Traemos la clase Persona para poder asignarle los métodos
import { Persona } from "./personas.js";
import { sequelize } from "./db.js";


// Este es el objeto de control (objeto Boundary), se lo llama desde el index.js del back
// El gestor tiene todos los métodos de la clase
export class GestorPersonas {
    // Método 1
    async obtenerTodas() {
        return await Persona.findAll() // Trae todas las personas de la DB
    }

    // Método 2
    async obtenerPorApellido(apellido) {
        return await Persona.findAll({
            where: { apellido: apellido }, // Va a filtrar todas las personas por el apellido pasado como parámetro
        })
    }
}
