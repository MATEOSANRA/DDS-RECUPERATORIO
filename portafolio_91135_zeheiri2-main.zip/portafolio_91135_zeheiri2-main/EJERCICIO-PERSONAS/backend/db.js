// Acá definimos nuestra DB y su manejo

// Importamos el módulo Sequelize de la librería "sequelize" --> 
// Como traemos solo un módulo específico y no toda la librería, tenemos que importarlo con las llaves {}
import { Sequelize } from 'sequelize';


// Crea el objeto Sequelize y lo exporta
export const sequelize = new Sequelize({
    dialect: 'sqlite', // Este es el lenguaje de la base de datos
    storage: './personas.sqlite' // Este es el archivo que sirve de almacenamiento de nuestros datos de la DB
});
