const express = require('express');
const cors = require('cors');

const PORT = 3001;

// Middlewares de Express.js
const app = express();
app.use(express.json());
app.use(cors());


// Iniciar base de datos
// Usar: db.iniciar(true) 
// para resetear estructura y datos
const db = require('./app/db/setup')
db.iniciar(true); // sincroniza a la fuerza y plancha los datos (sincroniza y la vuelve a creqar a la db)

// Rutas
const rutasHoteles = require("./app/routes/hoteles.routes");
rutasHoteles(app);
const rutasCategorias = require("./app/routes/categorias.routes");
rutasCategorias(app);

app.listen(PORT, () => {
    console.log(`
    El servidor está corriendo en el puerto ${PORT} 
    `)
});