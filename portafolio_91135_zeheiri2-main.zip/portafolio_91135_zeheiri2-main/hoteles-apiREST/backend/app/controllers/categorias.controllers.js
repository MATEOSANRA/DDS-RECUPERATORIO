const db = require('../db/setup')
const Categorias = db.Categorias;
const {Op} = require('sequelize');


// Recupera todos los categorias de la base de datos.
exports.findAll = (req, res) => {
  Categorias.findAll()
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Ocurrió algún error recuperando las categorias."
      });
    });
};