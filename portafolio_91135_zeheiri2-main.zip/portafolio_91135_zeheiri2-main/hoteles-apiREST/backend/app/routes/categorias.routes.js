module.exports = app => {
    const categoriasController = require('../controllers/categorias.controllers');
  
    var router = require("express").Router();
  
    //router.post("/", categoriasController.create);

    router.get("/", categoriasController.findAll);

    //router.get("/:id", categoriasController.findOne);

    //router.put("/:id", categoriasController.update);

    //router.delete("/:id", categoriasController.delete);
  
    app.use('/api/categorias', router);
};