const crearDatos = async (Hoteles, Categorias) => {
    await Categorias.truncate();
    await Categorias.bulkCreate([
        {nombre:"1 Estrella"},    
        {nombre:"2 Estrellas"},    
        {nombre:"3 Estrellas"},    
        {nombre:"4 Estrellas"},    
        {nombre:"5 Estrellas"},
        {nombre:"Cabaña"},    
        {nombre:"Camping"}
    ]);

    await Hoteles.truncate();
    await Hoteles.bulkCreate([
        {categoria_id: 1, nombre:"Yuna Porte-Maillot", ciudad:"Paris", plazas:"215"},
        {categoria_id: 3, nombre:"Villa Fontaine Haneda", ciudad:"Tokio", plazas:"320"},
        {categoria_id: 5, nombre:"Ours Inn Hankyu ", ciudad:"Tokio", plazas:"120"},
        {categoria_id: 2, nombre:"Hotel Des Deux Continents", ciudad:"Paris", plazas:"180"},
        {categoria_id: 1, nombre:"JR Shinjuku Station", ciudad:"Tokio", plazas:"426"},
        {categoria_id: 5, nombre:"Villa Royale Montsouris", ciudad:"Paris", plazas:"112"},
        {categoria_id: 1, nombre:"Native Kings Wardrobe", ciudad:"Londres", plazas:"146"},
        {categoria_id: 2, nombre:"Hôtel Saint-Pétersbourg Opéra & Spa", ciudad:"Paris", plazas:"230"},
        {categoria_id: 5, nombre:"Hotel & Resort Ryogoku Eki", ciudad:"Tokio", plazas:"142"},
        {categoria_id: 1, nombre:"Hotel Tokyo Shiodome", ciudad:"Tokio", plazas:"912"},
        {categoria_id: 2, nombre:"Hostal Santa Cruz", ciudad:"Madrid", plazas:"321"},
        {categoria_id: 6, nombre:"Sonder Camden Road", ciudad:"Londres", plazas:"118"},
        {categoria_id: 3, nombre:"Sonder Edgware Road", ciudad:"Londres", plazas:"230"},
        {categoria_id: 6, nombre:"Gem Langham Court Hotel", ciudad:"Londres", plazas:"235"},
        {categoria_id: 2, nombre:"Commodore Hotel", ciudad:"Londres", plazas:"224"},
        {categoria_id: 5, nombre:"Fuencarral Adeco", ciudad:"Madrid", plazas:"112"},
        {categoria_id: 1, nombre:"Castilla Vieja", ciudad:"Madrid", plazas:"98"},
        {categoria_id: 3, nombre:"Soho Boutique Opera", ciudad:"Madrid", plazas:"144"},
        {categoria_id: 2, nombre:"Gem Fitzrovia Hotel", ciudad:"Londres", plazas:"98"},
        {categoria_id: 5, nombre:"Hotel Gracery Shinjuku ", ciudad:"Tokio", plazas:"225"},
        {categoria_id: 6, nombre:"Villa Royale Montsouris", ciudad:"Paris", plazas:"118"},
        {categoria_id: 7, nombre:"Mayerling Hotel", ciudad:"Madrid", plazas:"241"},
        {categoria_id: 5, nombre:"Puerta del Sol Hotel", ciudad:"Madrid", plazas:"123"},
    
    ]);
}

module.exports = crearDatos;
