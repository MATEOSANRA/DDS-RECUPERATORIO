const Sequelize = require('sequelize')
const crearDatos = require('./init');
const HotelModel = require('../models/hotel.model');
const CategoriaModel = require('../models/categoria.model');

const sequelize = new Sequelize({
    dialect: 'sqlite',
    storage: './datos/hoteles.db'
});

const Hoteles = HotelModel(sequelize);
const Categorias = CategoriaModel(sequelize);

// asociaciones
Hoteles.belongsTo(Categorias, {foreignKey: 'categoria_id', as: 'categoria'});
Categorias.hasMany(Hoteles, {foreignKey: 'categoria_id', as: 'hoteles'})

const iniciar = async(reset = false) => {
    try {
        await sequelize.sync({force: reset});
        console.log(`Base de datos inicializada`);
        if (reset) {
            await crearDatos(Hoteles, Categorias);
        }
    }
    catch (err){
        console.log(`Error en la base de datos: ${err.message}`);
    }
}

const db = {iniciar, Hoteles, Categorias}
module.exports = db;

