import { Routes, Route } from 'react-router-dom';
import Menu from './components/Menu';
import Inicio from './components/Inicio';
import Hoteles from './components/Hoteles';
import Hotel from './components/Hotel';
import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap-icons/font/bootstrap-icons.css'

function App() {
  return (
    <>
      <Menu />
      <div className='container text-center'>
        <Routes>
          <Route path='/' element={<Inicio></Inicio>} />
          <Route path='/hoteles' element={<Hoteles></Hoteles>} />
          <Route path='/hotel/:id' element={<Hotel></Hotel>} />
        </Routes>
      </div>
    </>
  );
}

export default App;
