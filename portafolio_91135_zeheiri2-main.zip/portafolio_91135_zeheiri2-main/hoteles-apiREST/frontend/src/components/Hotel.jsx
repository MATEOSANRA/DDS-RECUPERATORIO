import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form'; // Nos devuelve funciones
import axios from 'axios';

const Hotel = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    // handleSubmit nos permite asignarle una función que usamos para recibir la info del submit, pasándole la data del form
    const { register, handleSubmit, formState: { errors }, setValue } = useForm();

    const [hotel, setHotel] = useState({});
    const [categorias, setCategorias] = useState();
    const [categoria_id, setCategoria_id] = useState(0);

    useEffect(() => {
        if (id > 0) {
            getHotel(id);
            getCategorias()
        } else {
            setHotel({
                nombre: '',
                ciudad: '',
                categoria: '',
                plazas: ''
            })
        }
    }, []);

    const getHotel = async (id) => {
        const { data } = await axios.get(`http://localhost:3001/api/hoteles/${id}`)
        setHotel(data);
        setValue('nombre', data.nombre);
        setValue('ciudad', data.ciudad);
        setValue('categoria_id', data.categoria_id);
        setValue('plazas', data.plazas);
        setCategoria_id(data.categoria_id)
        console.log(JSON.stringify(hotel));
    };

    const getCategorias = async () => {
        const { data } = await axios.get('http://localhost:3001/api/categorias');
        setCategorias(data)
    };

    const volver = () => {
        navigate('/hoteles')
    };

    const cancelar = () => {
        volver();
    };

    // Data contiene toda la info de los campos recogidos del form
    const onSubmit = async (data) => {
        console.log('Valores del form: ' + JSON.stringify(data));
        if (id > 0) {
            // Actualización
            await axios.put(`http://localhost:3001/api/hoteles/${id}`, data)
        } else {
            // Creación
            await axios.post(`http://localhost:3001/api/hoteles`, data);
            volver();
        }
    };

    return (
        <form onSubmit={handleSubmit(onSubmit)}>
            <h1 className='mb-5'>Contenido del componente Hotel</h1>
            <div className='row mb-3'>
                <div className="col-4">
                    <label htmlFor="nombre">Nombre: </label>
                </div>
                <div className="col-8">
                    <input
                        type="text"
                        id='nombre'
                        className='form-control'
                        placeholder='Nombre del hotel'
                        // Operador de propagación
                        {...register('nombre', { required: 'Debe ingresar un nombre' })}
                    />
                </div>
                {errors.nombre && <span className='text-danger'>{errors.nombre.message}</span>}
            </div>
            <div className='row mb-3'>
                <div className="col-4">
                    <label htmlFor="ciudad">Ciudad: </label>
                </div>
                <div className="col-8">
                    <input
                        type="text"
                        id='ciudad'
                        className='form-control'
                        placeholder='Nombre de la ciudad'
                        {...register('ciudad', { required: 'Debe ingresar una ciudad' })}
                    />
                </div>
                {errors.ciudad && <span className='text-danger'>{errors.ciudad.message}</span>}

            </div>
            <div className='row mb-3'>
                <div className="col-4">
                    <label htmlFor="categoria_id">Categoría: </label>
                </div>
                <div className="col-8">
                    <select 
                        className='form-select' 
                        defaultValue={categoria_id}
                        onChange={(e) => {setCategoria_id(e.target.value)}}
                        {...register('categoria_id')}>
                        {categorias && categorias.map(c => <option key={c.id} value={c.id}>{c.nombre}</option>)}
                    </select>
                </div>
                {errors.categoria && <span className='text-danger '>{errors.categoria.message}</span>}
            </div>
            <div className='row'>
                <div className="col-4">
                    <label htmlFor="plazas">Plazas: </label>
                </div>
                <div className="col-8">
                    <input
                        type="text"
                        id='plazas'
                        className='form-control'
                        placeholder='Cantidad de plazas'
                        {...register('plazas', {
                            required: 'Debe ingresar la cantidad de plazas',
                            validate: (value) => { return !isNaN(value) || 'Debe ser numérico' }
                        })}
                    />
                </div>
                {errors.plazas && <span className='text-danger '>{errors.plazas.message}</span>}

            </div>

            <button className='btn btn-danger ms-2 mt-5' onClick={cancelar}>Cancelar</button>
            <input className='btn btn-success ms-2 mt-5' type="submit" value={id > 0 ? 'Actualizar' : 'Crear'} />
        </form>
    );
}

export default Hotel;