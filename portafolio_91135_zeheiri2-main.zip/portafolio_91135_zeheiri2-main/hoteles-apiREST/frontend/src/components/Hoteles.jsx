import { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import { useForm } from 'react-hook-form';

function Hoteles() {
    const { register, handleSubmit } = useForm();

    const [hoteles, setHoteles] = useState(null);
    const [categorias, setCategorias] = useState(null);


    useEffect(() => {
        getHoteles();
        getCategorias()
    }, []);

    const getHoteles = async (queries = '') => {
        const hotelesDatos = await axios.get(`http://localhost:3001/api/hoteles?${queries}`);
        setHoteles(hotelesDatos.data);
    };

    const getCategorias = async () => {
        const { data } = await axios.get('http://localhost:3001/api/categorias');
        setCategorias(data)
    }

    const deleteHotel = async (id) => {
        if (window.confirm('¿Seguro que quiere eliminar este hotel?')) {
            await axios.delete(`http://localhost:3001/api/hoteles/${id}`);
            getHoteles();
        }
    };

    const onSubmit = async (data) => {
        console.log((data));
        let query = [];
        data.nombre && query.push(`nombre=${data.nombre}`);
        data.categoria_id && query.push(`categoria_id=${data.categoria_id}`);
        getHoteles(query.join('&'));
    };

    return (
        <div className="text-start">
            <h1 className="text-center text-info mt-3">Hoteles</h1>

            <form onSubmit={handleSubmit(onSubmit)}>
                <fieldset>
                    <legend>Buscar</legend>
                    <div className="row">
                        <div className="row">
                            <div className="col-5">
                                <input
                                    type="text"
                                    placeholder='Nombre'
                                    className='form-control'
                                    {...register('nombre')}
                                />
                            </div>
                            <div className="col-5">
                                <select className='form-select' {...register('categoria_id')}>
                                    <option value="0">Todas</option>
                                    {categorias && categorias.map(c => <option key={c.id} value={c.id}>{c.nombre}</option>)}
                                </select>
                            </div>
                            <div className="col-2">
                                <button type='submit' className='btn btn-primary'>
                                    Buscar
                                    <i className="bi bi-search ms-2"></i>
                                </button>
                            </div>

                        </div>
                    </div>
                </fieldset>
            </form>

            <table className="table mt-5">
                <thead className="table-dark">
                    <tr>
                        <th>Nombre</th>
                        <th>Ciudad</th>
                        <th>Categoría</th>
                        <th>Plazas</th>
                        <th>Eliminar</th>
                        <th>Editar</th>
                        <th><Link className='' to='/hotel/0'>Nuevo Hotel</Link></th>
                    </tr>
                </thead>
                <tbody>
                    {
                        hoteles && hoteles.map(h => {
                            return (
                                <tr key={h.id}>
                                    <td>{h.nombre}</td>
                                    <td>{h.ciudad}</td>
                                    <td>{h.categoria.nombre}</td>
                                    <td>{h.plazas}</td>
                                    <td>
                                        <button className="btn" onClick={() => deleteHotel(h.id)}>
                                            <i className='bi bi-trash text-danger'></i>
                                        </button>
                                    </td>
                                    <td>
                                        <Link className='btn btn-default' to={`/hotel/${h.id}`}>
                                            <i className='bi bi-pencil text-primary'></i>
                                        </Link>
                                    </td>
                                </tr>
                            )
                        }
                        )}
                </tbody>
            </table>
        </div>
    )
}

export default Hoteles;