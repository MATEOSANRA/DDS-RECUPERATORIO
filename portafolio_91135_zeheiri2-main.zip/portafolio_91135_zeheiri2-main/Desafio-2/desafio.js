// Importación del archivo JSON en una variable
const personas = require('./personas.json');


// Inicialización de variables para consigna 5
const letrasAL = 'ABCDEFGHIJKL';
const letrasMZ = 'MNÑOPQRSTUVWXYZ';


// Funciones
const sumarEdades = (personas) => {
    let sumaEdades = 0;
    personas.forEach(persona => {
        sumaEdades += persona.edad
    });
    return sumaEdades;
};

const calcularPromedio = (sumatoria, cantidad) => {
    return Math.round(sumatoria / cantidad)
};

const encontrarMenor = (personas) => {
    let menor
    for (let i = 0; i < personas.length; i++) {
        if (i === 0 || personas[i].edad < menor.edad) {
            menor = personas[i];
        }
    }
    return menor;
};

const encontrarGomez = (personas) => {
    let todosGomez = [];
    personas.forEach(persona => {
        if (persona.apellido === "GOMEZ") {
            todosGomez.push(persona.nombre)
        }
    });
    return todosGomez.sort()
};


const esPar = (cadena) => {
    if (cadena.length % 2 === 0) {
        return true;
    }
    return false;
};


const nombreParApellidoImpar = (personas) => {
    let nomParApeImpar = [];
    personas.forEach(persona => {
        if (esPar(persona.nombre) && !(esPar(persona.apellido))) {
            nomParApeImpar.push(persona)
        }
    });
    return nomParApeImpar
};


const mayoresYmenores18 = (personas) => {
    let mayores = 0;
    let menores = 0;
    personas.forEach(persona => {
        if (persona.edad > 18) {
            mayores++;
        } else {
            menores++;
        }
    });
    return { mayores, menores }
};


const apellidoAL = (personas) => {
    let cantidadAL = 0;
    personas.forEach(persona => {
        if (letrasAL.includes(persona.apellido[0])) {
            cantidadAL++
        }
    });
    return cantidadAL
};

const apellidoMZ = (personas) => {
    let cantidadMZ = 0;
    personas.forEach(persona => {
        if (letrasMZ.includes(persona.apellido[0])) {
            cantidadMZ++
        }
    });
    return cantidadMZ
};

const crearObjeto = (atributos, valores) => {
    if (atributos.length !== valores.length) {
        console.log("La cantidad de atributos debe ser igual a la cantidad de valores.");
        return
    }

    let objeto = {};
    atributos.forEach((atributo, indice) => {
        objeto[atributo] = valores[indice];
    });

    return objeto
};

const contarPorApellido = (personas, apellido) => {
    let cantPorApellido = 0;
    personas.forEach(persona => {
        if (persona.apellido === apellido) {
            cantPorApellido++;
        }
    });
    return cantPorApellido
};



// CONSIGNA 1
const sumaEdadesTodos = sumarEdades(personas);
const promedioEdades = calcularPromedio(sumaEdadesTodos, personas.length);
console.log("1- Promedio de edades de todas las personas: " + promedioEdades);


// CONSIGNA 2
const personaMenor = encontrarMenor(personas);
console.log(`2- Persona de menor edad: ${personaMenor.nombre} ${personaMenor.apellido}`);


// CONSIGNA 3
const losGomezOrdenados = encontrarGomez(personas)
console.log("3- Nombres de todos los Gomez ordenados alfabéticamente: ", losGomezOrdenados);


// CONSIGNA 4
const nomParApeImpar = nombreParApellidoImpar(personas);
const sumaEdadesNParAImpar = sumarEdades(nomParApeImpar);
console.log("4- Suma de edades de las personas con nombre par y apellido impar: ", sumaEdadesNParAImpar);


// CONSIGNA 5
const { mayores, menores } = mayoresYmenores18(personas);
const primeraMitad = apellidoAL(personas);
const segundaMitad = apellidoMZ(personas);
const atributos1 = ["mayores", "menores", "primeraMitad", "segundaMitad"];
const valores1 = [mayores, menores, primeraMitad, segundaMitad];
const objeto1 = JSON.stringify(crearObjeto(atributos1, valores1));;
console.log("5- Objeto 1: ", objeto1);


// CONSIGNA 6
const cantCastillo = contarPorApellido(personas, "CASTILLO");
const cantDiaz = contarPorApellido(personas, "DIAZ");
const cantFerrer = contarPorApellido(personas, "FERRER");
const cantPino = contarPorApellido(personas, "PINO");
const cantRomero = contarPorApellido(personas, "ROMERO");
const atributos2 = ["castillo", "diaz", "ferrer", "pino", "romero"];
const valores2 = [cantCastillo, cantDiaz, cantFerrer, cantPino, cantRomero];
const objeto2 = JSON.stringify(crearObjeto(atributos2, valores2));
console.log("6- Objeto 2: ", objeto2);
