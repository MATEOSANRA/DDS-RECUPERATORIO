// Voy a tener una rpomesa que me va a dar una respuesta
fetch('https://jsonplaceholder.typicode.com/todos')
    /* .then(respuesta => console.log(respuesta.ok)) */
/*     .then(respuesta => respuesta.json())
    .then(datos => {
        datos.forEach((item) => {
            console.log(`id:${item.id} --> ${item.title}`);
        });
    });
 */

const obtenerDatos = async () => {
    const respuesta = await fetch('https://jsonplaceholder.typicode.com/todos');
    console.log(respuesta);
    if (respuesta.ok) {
        // Como .json() es una promesa, tengo que poner el await adelante
        const datos= await respuesta.json();
        /* console.log(datos); */
        datos.forEach((item) => {
            console.log(`id:${item.id} --> ${item.title}`);
        });
    }
}

obtenerDatos()