const promesa = new Promise((resolve, reject) => {
    setTimeout(() => resolve(999), 3000)
});

promesa.then((dato_importante) => console.log(dato_importante))


const promesa2 = new Promise((resolve, reject) => {
    setTimeout(() => reject('Fallo de autenticación'), 1000)
});

promesa2
    .then((dato_importante) => console.log(dato_importante))
    .catch((error) => console.log('ERROR:', error));


