// FUMNCIONES FLECHA

const calcular = (a, b, operacion) => {
    return operacion(a, b)
}

const suma = (a, b) => {
    return a + b
}

console.log(calcular(3, 4, suma));


const saludar = () => console.log('HOLA');

saludar();


const saludarConNombre = (nombre) => {
    console.log('Hola ' + nombre);
}

saludarConNombre('Mica');


const sumar = (a, b) => {
    let resultado = a + b;
    console.log('Resultado de la suma: ', resultado);
}

sumar(4, 6);


// SET TIME OUT
// El tiempo se expresa en milisegundos (3000 son 3 segundos)
console.log('Sentencia 1');
console.log('Esperando que pase el tiempo...');
setTimeout(() => { console.log('Pasó el tiempo') }, 3000);

//Se ejecuta al último porque es asíncrona y el programa guarda en la pila de ejecución las síncronas primero.
/* setTimeout(() => { console.log('Pasó el tiempo') }, 0); */
console.log('Sentencia 2');
console.log('Sentencia 3');


// SET INTERVAL
setInterval(() => { console.log('TIC') }, 2000);
/* let cont = 0;
setInterval(() => { 
    if (cont % 2 === 0) {
        console.log('TIC'); 
    } else {
        console.log('TAC');
    };
    cont++
}
, 2000); */

