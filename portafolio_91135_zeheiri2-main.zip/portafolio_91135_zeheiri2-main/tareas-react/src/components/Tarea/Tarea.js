import { useState } from "react";

const Tarea = ({ tarea, removerTarea }) => {
  const [realizada, setRealizada] = useState(tarea.realizada);
  let estilo = {
    textDecoration: realizada && "line-through",
    color: realizada && "red",
  };
  return (
    <>
      <li className="list-group-item justify-content-center">
        <input
          className="form-check-input me-1 align-middle"
          id="firstCheckbox"
          type="checkbox"
          onChange={(e) => {
            setRealizada(e.target.checked);
          }}
          checked={realizada ? "checked" : ""}
        />
        <label
          className="form-check-label align-middle"
          htmlFor="firstCheckbox"
          style={estilo}
        >
          {tarea.nombre}
        </label>
        <button
          className="float-end btn"
          onClick={(e) => removerTarea(tarea.id)}
        >
          <i className="bi bi-trash3 text-danger"></i>
        </button>
      </li>
    </>
  );
};

export default Tarea;
