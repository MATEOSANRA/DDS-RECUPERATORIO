const Acerca = () => {
    return (
     <>
        <h1>Contenido del componente Acerca</h1>
     </>
    );
  }

export default Acerca;