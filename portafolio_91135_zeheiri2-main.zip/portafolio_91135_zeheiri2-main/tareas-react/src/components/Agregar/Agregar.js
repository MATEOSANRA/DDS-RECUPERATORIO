import { useState } from "react";

const Agregar = ({ agregarTarea }) => {
  const [nombre, setNombre] = useState("");

  const cambiarNombre = (e) => {
    setNombre(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    agregarTarea({
      id: window.crypto.randomUUID(),
      nombre: nombre,
      realizada: false,
    });
    setNombre("");
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className="input-group mb-3">
        <input
          type="text"
          id="txtNombreTarea"
          name="nombreTarea"
          className="form-control"
          placeholder="Ingrese una nueva tarea"
          onChange={cambiarNombre}
          value={nombre}
        />
        <button
          disabled={nombre === ""}
          className="btn btn-outline-success"
          type="submit"
          id="btnNuevaTarea"
        >
          <i className="bi bi-plus-circle"></i>
        </button>
      </div>
    </form>
  );
};

export default Agregar;
