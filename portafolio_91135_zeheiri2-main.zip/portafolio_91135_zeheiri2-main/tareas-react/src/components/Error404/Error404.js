const Error404 = () => {
    return (
     <>
        <h1>Contenido del componente Error404</h1>
     </>
    );
  }

export default Error404;