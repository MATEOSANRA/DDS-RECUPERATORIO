import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from 'axios';

const Posts = () => {
  const [posts, setPosts] = useState([])
  const { idUsuario } = useParams()
  const cargarPosts = async () => {
    const datosPosts = await axios.get(`https://jsonplaceholder.typicode.com/posts?userId=${idUsuario}`);
    setPosts(datosPosts.data)
  }

  useEffect(() => { cargarPosts() })

  return (
    <>
      <h1>Posts</h1>
      <div className="text-start">
        <ul>
          {posts.map(p => <li key={p.id}>{p.title} </li>)}
        </ul>
      </div>
    </>
  );
}

export default Posts;