import { Link } from 'react-router-dom';

const Navegacion = () => {
    return (
     <>
        <nav className="navbar navbar-expand-lg bg-body-tertiary bg-success-subtle">
        <div className="container-fluid">
          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav">
              <li className="nav-item">
                <Link to="/" className="nav-link active" aria-current="page">Inicio</Link>
              </li>
              <li className="nav-item">
                <Link to="/contador" className="nav-link">Contador</Link>
              </li>
              <li className="nav-item">
                <Link to="/tareas" className="nav-link">Lista de Tareas</Link>
              </li>
              <li className="nav-item">
                <Link to="/usuarios" className="nav-link">Usuarios</Link>
              </li>
              <li className="nav-item">
                <Link to="/acerca" className="nav-link">Acerca de nosotros</Link>
              </li>
            </ul>
          </div>
        </div>
      </nav>
     </>
    );
  }

export default Navegacion;