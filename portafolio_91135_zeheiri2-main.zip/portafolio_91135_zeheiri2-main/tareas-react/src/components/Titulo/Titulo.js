const Titulo = ({ children }) => {
  return (
    <>
      <div className="row">
        <h1 className="text-center p-5 text-success">{children}
          <i className="bi bi-clipboard2-plus"></i>
        </h1>
      </div>
    </>
  );
}

export default Titulo;