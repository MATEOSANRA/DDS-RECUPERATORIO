import Tarea from "../Tarea/Tarea";

const Lista = ({ lista, removerTarea }) => {
  return (
    <>
      <ul className="list-group">
        {lista.map((t) => (
          /* tarea, key y removerTarea son los nombres de los props con el que le va a llegar al hijo (Tarea) */
          /* t, t.id y removerTarea son los valores de los props que le llega a Tarea */
          /* removerTarea es el onClick del botón del tacho de eliminar */
          <Tarea tarea={t} key={t.id} removerTarea={removerTarea} />
        ))}
      </ul>
    </>
  );
};

export default Lista;
