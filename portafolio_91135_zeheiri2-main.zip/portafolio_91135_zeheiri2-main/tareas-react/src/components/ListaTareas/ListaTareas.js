import { useState } from "react";
import Titulo from "../Titulo/Titulo";
import Agregar from "../Agregar/Agregar";
import Lista from "../Lista/Lista";

const ListaTareas = () => {
  const [lista, setLista] = useState([]);

  const agregarTarea = (tarea) => {
    console.log("Agregando tarea: ", tarea);
    setLista([...lista, tarea]);
    console.log(lista);
  };

  const removerTarea = (id) => {
    let nuevaLista = lista.filter((t) => t.id !== id);
    setLista(nuevaLista);
  };

  return (
    <>
      <div className="container">
        <Titulo>Lista de Tareas</Titulo>
        <div className="row justify-content-center">
          <div className="card col-md-6">
            <div className="card-body">
              <Agregar agregarTarea={agregarTarea}></Agregar>
              <Lista lista={lista} removerTarea={removerTarea}></Lista>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ListaTareas;
