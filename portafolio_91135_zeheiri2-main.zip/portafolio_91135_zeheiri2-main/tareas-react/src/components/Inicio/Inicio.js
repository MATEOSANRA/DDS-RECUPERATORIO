const Inicio = () => {
    return (
     <>
        <h1>Contenido del componente Inicio</h1>
     </>
    );
  }

export default Inicio;