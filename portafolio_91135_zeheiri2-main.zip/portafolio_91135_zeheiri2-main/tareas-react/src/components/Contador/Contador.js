import { useState } from "react";

const Contador = () => {
    const [contador, setContador] = useState(0);
    
    const incrementarValor = () => {
        setContador(contador + 1);
        console.log('Contador: ', contador);
    };
    

    return (
        <>
            <button onClick={incrementarValor}>Presionado {contador} veces</button>
        </>
    );
}

export default Contador;

