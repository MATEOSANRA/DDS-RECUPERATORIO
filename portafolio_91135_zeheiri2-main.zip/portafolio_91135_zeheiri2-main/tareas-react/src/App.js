import { Routes, Route } from 'react-router-dom';
import Navegacion from './components/Navegacion/Navegacion';
import Contador from './components/Contador/Contador'
import ListaTareas from './components/ListaTareas/ListaTareas';
import Acerca from './components/Acerca/Acerca';
import Error404 from './components/Error404/Error404';
import Inicio from "./components/Inicio/Inicio";
import Usuarios from './components/Usuarios/Usuarios';
import Posts from './components/Posts/Posts';

const App = () => {
  return (
    <>
      <Navegacion />
      <div className='container mt-5'>
        <Routes >
          <Route path='/' element={<Inicio />}></Route>
          <Route path='/contador' element={<Contador />}></Route>
          <Route path='/tareas' element={<ListaTareas />}></Route>
          <Route path='/usuarios' element={<Usuarios />}></Route>
          <Route path='/posts/:idUsuario' element={<Posts />}></Route>
          <Route path='/acerca' element={<Acerca />}></Route>
          <Route path='/*' element={<Error404 />}></Route>
        </Routes>
      </div>

    </>
  );
}

export default App;


