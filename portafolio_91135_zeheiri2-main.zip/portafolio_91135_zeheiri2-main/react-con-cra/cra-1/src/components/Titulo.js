import '../css/titulo.css'


// reutilizamos el componente mediante los atributos enviados en el render

/* export default function Titulo(props) {
    return (
        <h1 className={props.color}>{props.texto}</h1>
    )
} */

/* export default function Titulo(props) {
    const { texto, color } = props
    return (
        <h1 className={color}>{texto}</h1>
    )
} */

export default function Titulo({ texto = 'N/D', color, children }) {
    return (
        <h1 className={color}>{texto} {children}</h1>
    )
}