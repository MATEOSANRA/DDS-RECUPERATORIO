/* export default function App() {
    return <h1>App</h1>
} */

/* export default function App() {
    const titulo = <h1>App con CRA</h1>
    return titulo
} */

import Titulo from "./Titulo"

export default function App() {

    return (
        <>
            <Titulo texto="App con CRA" color="violeta" />
            <Titulo texto="Segundo título" color="celeste" />
            <Titulo color="rojo"></Titulo> {/* Muestra N/D por el valor por defecto */}
            <Titulo>Este es el valor de children</Titulo>
            <h3>Probando componentes</h3>
        </>
    )
}