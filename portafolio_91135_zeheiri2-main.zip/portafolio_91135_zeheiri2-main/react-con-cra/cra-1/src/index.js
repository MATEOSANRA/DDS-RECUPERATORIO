import React from 'react';
import App from './components/App'

//import ReactDOM from 'react-dom/client';
import { createRoot } from 'react-dom/client';


const root = createRoot(document.getElementById('root'));
root.render(
    <>
        <App />
        <h2>
            Título 2
        </h2>
        <p>3 + 5 = {3 + 5}</p>
    </>
)