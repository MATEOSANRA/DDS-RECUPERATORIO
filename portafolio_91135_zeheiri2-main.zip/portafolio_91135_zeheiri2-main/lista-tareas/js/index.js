let tareas = [];
let contador = 0;

/* const btnNuevaTarea = document.querySelector('#btnNuevaTarea'); */
const btnNuevaTarea = document.getElementById('btnNuevaTarea');
const txtNombreTarea = document.getElementById('txtNombreTarea');

const agregarTarea = function (nombreTarea) {

    let nuevaTarea = new Tarea(nombreTarea);
    tareas.push(nuevaTarea);

    renderTarea();

    // Muestra el array como tabla
    console.table(tareas);

}


/* const nuevaTarea = {
    id: ++contador,
    nombre: nombre,
    realizada: false
};

const nuevaTarea = new Object();
nuevaTarea.id = ++contador,
    nuevaTarea.nombre = nombre,
    nuevaTarea.realizada = false */

function Tarea(nombre) {
    this.id = ++contador;
    this.nombre = nombre;
    this.realizada = false;
}


if (btnNuevaTarea && txtNombreTarea) {
    btnNuevaTarea.addEventListener('click', () => {
        if (txtNombreTarea.value) {
            agregarTarea(txtNombreTarea.value);
            txtNombreTarea.value = '';
        }
    })
}


const renderTarea = () => {
    const listaTareas = document.querySelector('#listaTareas');
    if (listaTareas) {
        let contenido = '';
        for (let i = 0; i < tareas.length; i++) {
            contenido += `
            <li class="list-group-item">
                <input class="form-check-input me-1" type="checkbox" value="" id="firstCheckbox">
                <label class="form-check-label" for="firstCheckbox">${tareas[i].nombre}</label>
                <i class="bi bi-trash3 text-danger float-end"></i>
            </li>`;
        }
        listaTareas.innerHTML = contenido;
    }
};