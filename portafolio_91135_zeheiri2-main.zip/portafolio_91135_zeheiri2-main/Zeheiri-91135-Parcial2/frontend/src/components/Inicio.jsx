function Inicio() {
    return (
        <>
            <h1 className="mt-5 text-primary">Administración de Álbumes Musicales</h1>
            <h2 className="mt-3 text-primary">Mi colección de audio</h2>
        </>
    )
}

export default Inicio;