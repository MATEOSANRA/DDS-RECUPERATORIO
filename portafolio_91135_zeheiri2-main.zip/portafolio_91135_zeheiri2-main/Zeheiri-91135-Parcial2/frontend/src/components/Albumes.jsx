import { useState, useEffect } from 'react';
import axios from 'axios';
import { useForm } from 'react-hook-form';

function Albumes() {
    const { register, handleSubmit } = useForm();

    const [albumes, setAlbumes] = useState(null);
    const [generos, setGeneros] = useState(null);


    // Cada vez que se refresca la página, realiza la llamada a las apis
    useEffect(() => {
        getAlbumes();
        getGeneros();
    }, []);


    // Trae los álbumes con sus respectivos filtros
    // Si no se seleccionó ninguno, trae todos los álbumes (la primera vez que se renderiza el componente también)
    const getAlbumes = async (queries = '') => {

        // Hace la llamada a la api del back, si se utilizó algún filtro lo pasa como parámetro en la ruta
        const datosAlbumes = await axios.get(`http://localhost:3001/api/albumes?${queries}`);

        // Guarda los datos de la api en la variable albumes
        setAlbumes(datosAlbumes.data);
    };


    // Trae los géneros de los álbumes 
    const getGeneros = async () => {

        // Busca todos los géneros de la api de géneros del back
        const { data } = await axios.get('http://localhost:3001/api/generos');

        // Guarda los datos en la variable géneros
        setGeneros(data);
    };


    // Borra el álbum seleccionado
    const deleteAlbum = async (id) => {

        // Permite confirmar la eliminación del álbum
        if (window.confirm('¿Está seguro que quiere eliminar este álbum?')) {

            // Realiza el borrado
            await axios.delete(`http://localhost:3001/api/albumes/${id}`);

            // Vuelve a traer la lista de los álbumes actualizada
            getAlbumes();
        };
    };


    // Maneja el envío de los datos a filtrar
    const onSubmit = async (data) => {
        let query = [];

        // Si se escribió un título, lo guarda en el array de la query
        data.titulo && query.push(`titulo=${data.titulo}`);

        // Si se seleccionó un género, lo guarda en el array de la query
        data.genero && query.push(`genero=${data.genero}`);

        // Pasa como parámetro a getAlbumes la query ya unida
        getAlbumes(query.join('&'));
    };

    return (
        <div className="text-start">
            <h1 className="text-center text-primary mt-5">Álbumes</h1>

            <form onSubmit={handleSubmit(onSubmit)}>
                <fieldset>
                    <legend>Filtrar</legend>
                    <div className="row">
                        <div className="row">
                            <div className="col-5">
                                <input
                                    type="text"
                                    placeholder='Título'
                                    className='form-control'
                                    {...register('titulo')}
                                />
                            </div>
                            <div className="col-5">
                                <select className='form-select' {...register('genero')}>
                                    <option value="">Todos los géneros</option>
                                    {generos && generos.map(g => <option key={g.distinct} value={g.distinct}>{g.distinct}</option>)}
                                </select>
                            </div>
                            <div className="col-2">
                                <button type='submit' className='btn btn-outline-primary'>
                                    Buscar
                                    <i className="bi bi-search ms-2"></i>
                                </button>
                            </div>

                        </div>
                    </div>
                </fieldset>
            </form>

            <table className="table mt-5">
                <thead className="table-dark">
                    <tr className='table-primary'>
                        <th>Título</th>
                        <th>Artista</th>
                        <th>Género</th>
                        <th>Soporte</th>
                        <th>Precio</th>
                        <th className='text-center'>Eliminar</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        albumes && albumes.map(a => {
                            return (
                                <tr key={a.id}>
                                    <td>{a.titulo}</td>
                                    <td>{a.artista}</td>
                                    <td>{a.genero}</td>
                                    <td>{a.soporte}</td>
                                    <td>${a.precio}</td>
                                    <td className='text-center'>
                                        <button className="btn" onClick={() => deleteAlbum(a.id)}>
                                            <i className='bi bi-trash text-danger'></i>
                                        </button>
                                    </td>
                                </tr>
                            )
                        }
                        )}
                </tbody>
            </table>
        </div>
    )
};

export default Albumes;