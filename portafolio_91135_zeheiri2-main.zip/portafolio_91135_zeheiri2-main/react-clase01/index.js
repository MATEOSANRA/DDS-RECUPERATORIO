const root = document.getElementById('root');

const titulo = React.createElement('h1', {className: 'left'}, 'Primera App React');
const boton = React.createElement('button', {}, 'Aceptar');

// Se podrían meter en el div todos los elementos
/* const div = React.createElement('div', {}, [ titulo, boton ]);
ReactDOM.createRoot(root).render(div); */


const fragment = React.createElement(React.Fragment, {}, [titulo, boton]);
ReactDOM.createRoot(root).render(fragment);
