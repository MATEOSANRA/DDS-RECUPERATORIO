const express = require('express');
const { Sequelize, DataTypes } = require('sequelize');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const sequelize = new Sequelize({
    dialect: 'sqlite',
    storage: './datos/tareas.sqlite'
});


const Tarea = sequelize.define(
    'Tarea',
    {
        id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
        nombre: { type: DataTypes.STRING },
        realizada: { type: DataTypes.BOOLEAN }
    },
    {
        sequelize,
        modelName: "tarea",
        timestamps: false
    }
);



async function inicializarBaseDeDatos() {
    await sequelize.sync({ force: true });
}


app.get('/api/tareas', async (req, res) => {
    const todasLasTareas = await Tarea.findAll();
    res.json(todasLasTareas);
})

app.post('/api/tareas', async (req, res) => {
    // recibir en el form de Agregar.js con -> method='post' action='http://localhost:5000/api/tareas'
    const nombreTarea = req.body.nombreTarea;
    console.log(nombreTarea);
    await Tarea.bulkCreate([
        {nombre: nombreTarea, realizada: false}
    ]);
    
})

app.get('/api/tareas/borrar/:id', async (req, res) => {
    const paramId = req.params.id;
    let filtro = { where: { id: paramId } };
    const borrarTarea = await Tarea.delete(filtro);
    res.json(borrarTarea);
})


inicializarBaseDeDatos().then(() => {
    app.listen(5000, () => console.log('Servidor en http://localhost:5000'));
});