const express = require('express')
const app = express()

// Esto iría en un archivo de gestor de códigos
const localidades = require('./cp.json')

app.get('/cp', (req, res) => {
    res.send(localidades);
})


// Esto iría en un archivo de gestor de códigos
//código del profe////////////////////////////////////////////
function buscarCodigo(codigo) {
    return localidades.filter(cadaUno => cadaUno.codigo_postal === codigo)
}

app.get('/cp/:codigo', (req, res) => {
    const cp = parseInt(req.params.codigo)
    const encontrados = buscarCodigo(cp)
    res.send(encontrados)
    //res.status(200)
})
//////////////////////////////////////////////////////////////


// Mi resolución :)
/* app.get('/cp/:codigo', (req, res) => {
    let filtroLoc = []
    const cp = parseInt(req.params.codigo)
    localidades.forEach(localidad => {
        if (localidad.codigo_postal === cp) {
            filtroLoc.push(localidad)
        } 
    });
    if (filtroLoc.length > 0) {
        res.json(filtroLoc)    
    } else {
        res.send(`No se encontraron localidades con el cp ${cp}`)
    }
})
 */

app.listen(9000)
console.log(`App listening on http://localhost:9000/cp`);