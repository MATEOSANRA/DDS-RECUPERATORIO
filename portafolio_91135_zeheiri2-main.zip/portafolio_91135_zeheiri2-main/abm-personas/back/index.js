import fs from 'fs'
import { Persona } from './personas.js'
import { sequelize } from './db.js'
import { servicio } from './personas.service.js'
import express from 'express'
import cors from 'cors'

function log_consola(request, response, next) {
    const ip = request.socket.remoteAddress
    console.log(ip)
    next()
}

function filtrar_9(request,response,next) {
    const ip = request.socket.remoteAddress
    if (ip.includes("9"))
        response.sendStatus(403)
    else
        next()
}

async function main1() {
    await sequelize.sync()

    const todas = await servicio.obtener_por_apellido("PEREZ")
    todas.forEach(p => console.log(`${p}`))
    
    const encontrada = await servicio.obtener_por_documento(90237512)
    console.log(`${encontrada}`)

    return

    encontrada.edad++;
    servicio.modificar(encontrada)

    const encontrada2 = await servicio.obtener_por_documento(90237512)
    console.log(`${encontrada2}`)

    const nueva = {
        documento: 1111113, 
        nombre: "DIEGO...",
        apellido: "SERRANO",
        edad: 45
    }

    
    //const creada = await servicio.agregar(nueva)
    //console.log(`${creada}`)
    console.log(await servicio.borrar(1111113)? "Borrada": "No encontrada")
    //console.log(`${encontrada2}`)

}

async function main() {

    const app = express()
    await sequelize.sync()
    //app.use(filtrar_9)
    app.use(cors())
    app.use(log_consola)

    app.get("/personas", async(request, response) => {
        const todas = await servicio.obtener_todas()
        response.send(todas)
    }) 
    
    app.get("/personas/:doc", async (request, response) => {
        const doc = parseInt(request.params.doc)
        if (!isNaN(doc)) {
            const personaEncontrada = await servicio.obtener_por_documento(doc)
            if (personaEncontrada) 
                response.status(200).send(personaEncontrada)
            else
                response.sendStatus(404)
        }
    })

    app.delete("/personas/:doc", async (request, response) => {
        const doc = parseInt(request.params.doc)
        console.log(request.params)
        if (!isNaN(doc)) {
            const personaEncontrada = await servicio.borrar(doc)
            if (personaEncontrada) 
                response.status(200).send(personaEncontrada)
            else
                response.sendStatus(404)
        }
    })

    app.listen(8001)
}

main()  