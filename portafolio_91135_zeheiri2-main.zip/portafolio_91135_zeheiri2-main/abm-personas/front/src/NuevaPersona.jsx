import { useForm } from "react-hook-form"
import { obtener } from "./personas.service"

function NuevaPersona({documento}) {

    const {register, handleSubmit, formState } = useForm({ defaultValues: async () => { 
        console.log("Buscando el documento" + documento)
        if (documento !== 0) 
            return await obtener(documento) 
        else 
            return null
    } } )


    
    const errors = formState.errors
    //async () => { await obtener(10988045)  }
    function guardar(datos) {
        alert(`${datos.documento} ${datos.nombre} ${datos.apellido} ${datos.edad } `)
    }


    return (
        <form onSubmit={handleSubmit(guardar)}>
            <table>
                <tr>
                    <td>Documento {documento}</td>
                    <td><input type="number" id="documento"
                     {...register("documento", { 
                        required: "El documento es obligatorio" 
                    })} /><br/>
                    
                    { errors.documento && errors.documento.message }

                    </td>
                </tr>
                <tr>
                    <td>Nombre</td>
                    <td><input type="text" id="nombre" value={documento} 
                    {...register("nombre", {
                        required: "El nombre es obligatorio",
                        minLength: {value: 3, message: "El nombre debe tener entre 3 y 15 letras"},
                        maxLength: {value: 15,message: "El nombre debe tener entre 3 y 15 letras"}
                    })} 
                    /><br/>
                    { errors.nombre && errors.nombre.message }
                
                    </td>
                </tr>
                <tr>
                    <td>Apellido</td>
                    <td><input type="text" id="apellido"  {...register("apellido", {})} /></td>
                </tr>
                <tr>
                    <td>Edad</td>
                    <td><input type="number" id="edad"  {...register("edad", {})} /></td>
                </tr>
                <tr>
                    <td></td>
                    <td><button type="submit">Guardar</button></td>
                </tr>
            </table>
        </form>
    )
}

export default NuevaPersona