import { useEffect, useState } from 'react'
import FilaPersona from './FilaPersona'
import NuevaPersona from './NuevaPersona'
import {obtener_todas, borrar} from './personas.service'


const ListadoPersonas = () => {

    async function buscar() {
        let data = await obtener_todas()
        setPersonas(data)
    }
        
    const [personas, setPersonas] = useState(null)
    const [documentoEnEdicion, setDocumentoEnEdicion] = useState(0)

    useEffect(() => {
        buscar()
        console.log("useEffect")
    },[])
    
    const detalleClick = function(p) {
        alert(p.nombre)
    }

    const borrarClick = async function(doc) {
        alert(await borrar(doc))
        await buscar()
    }

    const editarClick = function(doc) {
        console.log("Editando el documento" + doc)
        setDocumentoEnEdicion(doc)
    }

    return (
        <>
        <p>Nueva persona {documentoEnEdicion}</p>
        <NuevaPersona documento={documentoEnEdicion} />
    
        <p>Listado de personas</p>
        <table border="1">
        {
            personas && personas.map(p =>
               <FilaPersona p={p} detalleClick={detalleClick} borrarClick={borrarClick} editarClick={editarClick} />
            )
        }
        </table>
        </>
    )

}

export default ListadoPersonas