import './App.css';
import ListadoPersonas from './ListadoPersonas';
import NuevaPersona from './NuevaPersona';

function App() {
  return (
    <div className="App">
      <header className="App-header">
       
     
        <ListadoPersonas />
      </header>
    </div>
  );
}

export default App;
