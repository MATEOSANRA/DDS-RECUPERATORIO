import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { useParams, useNavigate } from 'react-router-dom';

import axios from 'axios';


const Actualizar = () => {

    const { register, handleSubmit, formState: { errors }, setValue } = useForm();
    const navigate = useNavigate();

    // Traemos los parámetros de la ruta
    const { titulo, director } = useParams();

    const [obra, setObra] = useState({});

    useEffect(() => {
        getObraAActualizar(titulo, director);
    }, []);

    const getObraAActualizar = async (titulo, director) => {

        try {
            // Buscamos la obra, pasándole como parámetros el título y director para que lo reciba el back.
            // Cuando se ejecuta el router.get, le pasa como parámetro req.query al servicio de getObrasTeatrales.
            // Esa función está definida en el archivo de service, y recibe como parámetro a "filtro"
            const { data } = await axios.get(`http://localhost:3001/api/obras-teatrales`, {
                // Esto es lo que recuperamos desde el back como req.query
                params: {
                    titulo,
                    director,
                }
            });

            setObra(data[0]);

            // Seteamos los atributos para que se vean los valores previos de la obra en el form
            setValue('Titulo', data[0].Titulo);
            setValue('Director', data[0].Director);
            setValue('FechaDesde', data[0].FechaDesde);
            setValue('FechaHasta', data[0].FechaHasta);
            setValue('PrecioEntrada', data[0].PrecioEntrada);

        } catch (error) {
            console.log('Error al buscar la obra: ', error);

            // Si no se encuentra la obra, lleva a página de error
            navigate('/error')
        }
    };

    const cancelar = () => {
        navigate('/obras-teatrales');
    };

    const onSubmit = async (data) => {

        try {
            const Id = obra.Id;
            navigate('/obras-teatrales');

            // Ejecuta el update de la obra
            await axios.put(`http://localhost:3001/api/obras-teatrales/${Id}`, data);

        } catch (error) {
            console.log('Error al buscar la obra: ', error);
            navigate('/error')
        }

    };


    return (
        <>
            <div className='container mt-5 mb-5'>
                <form onSubmit={handleSubmit(onSubmit)}>
                    <legend className="mb-3">Actualizar Obra</legend>

                    <div className="mb-3">
                        <label htmlFor="titulo" className="form-label">Título</label>
                        <input
                            type="text"
                            className="form-control"
                            id="titulo"
                            placeholder="Título de la obra"
                            {...register("Titulo", { required: 'Debe ingresar un título para la obra' })}
                        />
                        {errors.Titulo && <span className='text-danger'>{errors.Titulo.message}</span>}
                    </div>

                    <div className="mb-3">
                        <label htmlFor="director" className="form-label">Director</label>
                        <input
                            type="text"
                            className="form-control"
                            id="director"
                            placeholder="Nombre del director"
                            {...register("Director", { required: 'Debe ingresar el director de la obra' })}
                        />
                        {errors.Director && <span className='text-danger'>{errors.Director.message}</span>}
                    </div>

                    <div className="mb-3">
                        <label htmlFor="fechaDesde" className="form-label">Fecha Desde</label>
                        <input
                            type="date"
                            className="form-control"
                            id="fechaDesde"
                            {...register("FechaDesde", { required: 'Debe ingresar la fecha en que comienza' })}
                        />
                        {errors.FechaDesde && <span className='text-danger'>{errors.FechaDesde.message}</span>}
                    </div>

                    <div className="mb-3">
                        <label htmlFor="fechaHasta" className="form-label">Fecha Hasta</label>
                        <input
                            type="date"
                            className="form-control"
                            id="fechaHasta"
                            {...register("FechaHasta", { required: 'Debe ingresar la fecha en que termina' })}
                        />
                        {errors.FechaHasta && <span className='text-danger'>{errors.FechaHasta.message}</span>}
                    </div>

                    <div className='mb-3'>
                        <label htmlFor="precioEntrada" className="form-label">Precio de entrada</label>
                        <div className="input-group">
                            <span className="input-group-text">$</span>
                            <input
                                type="number"
                                className="form-control"
                                id="precioEntrada"
                                placeholder="Precio de la entrada"
                                {...register("PrecioEntrada", { required: 'Debe especificar cuánto costará la entrada' })}
                            />
                        </div>
                        {errors.PrecioEntrada && <span className='text-danger'>{errors.PrecioEntrada.message}</span>}
                    </div>

                    <div className="d-flex justify-content-center">
                        <button className='btn btn-outline-danger ms-2 mt-3 mb-5' onClick={cancelar}>Cancelar</button>

                        <button type='submit' className='btn btn-outline-primary ms-2 mt-3 mb-5'>Actualizar</button>
                    </div>

                </form>

            </div>

        </>
    );
}

export default Actualizar;