import { useState } from 'react';
import Obras from './Obras';

const Consultar = () => {

    // Creo esta variable para saber si se presionó el botón consultar o no
    const [mostrarTabla, setMostrarTabla] = useState(false);

    // Una bandera para saber si se tiene que recargar el componente Obras
    const [recargarObras, setRecargarObras] = useState(false);

    // Setea en true el  valor de mostrarTabla cuando se presiona Consultar
    const consultar = () => {
        // Cambiamos el valor de la bandera de recarga
        setRecargarObras(!recargarObras);
        setMostrarTabla(true);
    };

    return (
        <>
            <div className="d-flex justify-content-center">
                <button className='btn btn-outline-primary mt-5 mb-5' onClick={consultar}>Consultar</button>
            </div>

            {/* Solo renderiza el componente Obras si mostrarTabla es true */}
            {mostrarTabla && <Obras recargaTrigger={recargarObras} />}
        </>
    );
};

export default Consultar;