import { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from "react-router-dom";


const Obras = ({ recargaTrigger }) => {

    // Crear la variable obras
    const [obras, setObras] = useState([]);

    // Para que cada vez que se cargue el componente, automáticamente ejecute getObras()
    useEffect(() => {
        getObras();
    }, 
    // El efecto se ejecutará cada vez que recargaTrigger cambie
    // Si la lista de dependencias está vacía [], el efecto se ejecutará solo una vez cuando el componente se renderize
    [recargaTrigger]);


    // Hacemos la consulta de las obras a nuestro backend
    const getObras = async () => {
        // Usamos el verbo get porque es el que usa el back para traer todas las obras de la BD
        const obrasDatos = await axios.get(`http://localhost:3001/api/obras-teatrales`);
        // Guarda en la variable obras (un array de objetos), los datos obtenidos en la consulta al back
        setObras(obrasDatos.data);
    };


    return (
        <>
            <table className="table">
                <thead>
                    <tr className='table-primary'>
                        <th scope="col">#</th>
                        <th scope="col">Título</th>
                        <th scope="col">Director</th>
                        <th scope="col">Precio de Entrada</th>
                        <th scope="col">Fecha Desde</th>
                        <th scope="col">Fecha Hasta</th>
                        <th scope="col">Editar</th>
                    </tr>
                </thead>
                <tbody className="table-group-divider">
                    {
                        // Recorre la variable obras y crea una fila de la tabla por cada una con sus atributos
                        obras && obras.map(o => {
                            return (
                                <tr key={o.Id}>
                                    <td>{o.Id}</td>
                                    <td>{o.Titulo}</td>
                                    <td>{o.Director}</td>
                                    <td>${o.PrecioEntrada}</td>
                                    <td>{o.FechaDesde}</td>
                                    <td>{o.FechaHasta}</td>
                                    <td>
                                        <Link className='btn btn-default' to={`/obras-teatrales/actualizar/${o.Titulo}/${o.Director}`}>
                                            <i className='bi bi-pencil text-primary'></i>
                                        </Link>
                                    </td>
                                </tr>
                            )
                        }
                        )}
                </tbody>
            </table>
        </>
    );
}

export default Obras;