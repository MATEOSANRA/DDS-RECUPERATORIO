const Error = () => {
    return (
    <>
        <h1 className="mt-5 text-center text-danger">ERROR 404: Página no encontrada :(</h1>
    </>
    );
  }

export default Error;