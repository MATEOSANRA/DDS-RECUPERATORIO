import { useState } from 'react';
import { useForm } from 'react-hook-form';
import axios from 'axios';
import Obras from './Obras';


const Registrar = () => {

  const { register, handleSubmit, formState: { errors }, reset } = useForm();

  // Una bandera para saber si se tiene que recargar el componente Obras
  const [recargarObras, setRecargarObras] = useState(false);

  const crearObra = async (obra) => {
    // Usamos el verbo post porque es el que usa el back para crear una nueva obra
    await axios.post(`http://localhost:3001/api/obras-teatrales`, obra);
  }

  const onSubmit = async (data) => {
    // Mandamos los datos al back para que cree la nueva Obra
    crearObra(data);

    // Vaciamos el form luego de que se envió correctamente
    reset();

    // Cambiamos el valor de la bandera para recargar la tabla luego de agregar una nueva Obra
    setRecargarObras(!recargarObras);
  };


  return (
    <>
      <div className='container mt-5 mb-5'>
        <form onSubmit={handleSubmit(onSubmit)}>
          <legend className="mb-3">Registro de Obra</legend>

          <div className="mb-3">
            <label htmlFor="titulo" className="form-label">Título</label>
            <input
              type="text"
              className="form-control"
              id="titulo"
              placeholder="Título de la obra"
              {...register("Titulo", { required: 'Debe ingresar un título para la obra' })}
            />
            {errors.Titulo && <span className='text-danger'>{errors.Titulo.message}</span>}
          </div>

          <div className="mb-3">
            <label htmlFor="director" className="form-label">Director</label>
            <input
              type="text"
              className="form-control"
              id="director"
              placeholder="Nombre del director"
              {...register("Director", { required: 'Debe ingresar el director de la obra' })}
            />
            {errors.Director && <span className='text-danger'>{errors.Director.message}</span>}
          </div>

          <div className="mb-3">
            <label htmlFor="fechaDesde" className="form-label">Fecha Desde</label>
            <input
              type="date"
              className="form-control"
              id="fechaDesde"
              {...register("FechaDesde", { required: 'Debe ingresar la fecha en que comienza' })}
            />
            {errors.FechaDesde && <span className='text-danger'>{errors.FechaDesde.message}</span>}
          </div>

          <div className="mb-3">
            <label htmlFor="fechaHasta" className="form-label">Fecha Hasta</label>
            <input
              type="date"
              className="form-control"
              id="fechaHasta"
              {...register("FechaHasta", { required: 'Debe ingresar la fecha en que termina' })}
            />
            {errors.FechaHasta && <span className='text-danger'>{errors.FechaHasta.message}</span>}
          </div>

          <div className='mb-3'>
            <label htmlFor="precioEntrada" className="form-label">Precio de entrada</label>
            <div className="input-group">
              <span className="input-group-text">$</span>
              <input
                type="number"
                className="form-control"
                id="precioEntrada"
                placeholder="Precio de la entrada"
                {...register("PrecioEntrada", { required: 'Debe especificar cuánto costará la entrada' })}
              />
            </div>
            {errors.PrecioEntrada && <span className='text-danger'>{errors.PrecioEntrada.message}</span>}
          </div>

          <div className="d-flex justify-content-center">
            <button type='submit' className='btn btn-outline-primary mt-3 mb-5'>Registrar</button>
          </div>

        </form>

      </div>

      <Obras recargaTrigger={recargarObras} />
    </>
  );
}

export default Registrar;