import { Routes, Route } from 'react-router-dom';
import Navegacion from './components/Navegacion';
import Consultar from './components/Consultar';
import Registrar from './components/Registrar';
import Actualizar from './components/Actualizar';
import Error from './components/Error';

function App() {
  return (
    <>
      <Navegacion />

      <div className='container'>
        <Routes>
          <Route path='/' element={ <Consultar /> } />
          <Route path='/obras-teatrales' element={ <Consultar /> } />
          <Route path='/obras-teatrales/crear' element={ <Registrar /> } />
          <Route path='/obras-teatrales/actualizar/:titulo/:director' element={ <Actualizar /> } />
          <Route path='/*' element={ <Error /> } />
        </Routes>
      </div>

    </>
  );
}

export default App;