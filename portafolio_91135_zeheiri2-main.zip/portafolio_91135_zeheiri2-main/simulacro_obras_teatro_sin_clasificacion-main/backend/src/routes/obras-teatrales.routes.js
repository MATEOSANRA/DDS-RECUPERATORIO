import express from "express"
import obrasTetralesService from "../services/obras-teatrales.service.js";

const router = express.Router();

// Si hacés un GET a http://localhost:3001/api/obras-teatrales, 
// te devuelve todas las obras teatrales en la BD
router.get('', async (req, res) =>{
    // codigo
    const obras = await obrasTetralesService.getObrasTeatrales(req.query);
    // retorno respueta
    res.json(obras);
});

// Si hacés un POST a http://localhost:3001/api/obras-teatrales, 
// agrega una nueva obra teatral en la BD
router.post('', async (req, res) =>{
    const obra = await obrasTetralesService
    .insertarObraTeatral(req.body)
    return res.json(obra);
});

// Si hacés un PUT a http://localhost:3001/api/obras-teatrales/(algún id ya existente),
// modifica los datos de esa obra teatral en la BD 
router.put('/:id', async (req, res, next)=>{
    try {
        req.body.id = req.params.id
        const obra = await obrasTetralesService
        .editarObraTeatral(req.body)
        return res.json(obra);
    }catch(err){
        next(err)
    }
});

const obrasTeatralesRouter = {
    router
}


export default obrasTeatralesRouter;