import { Local } from "../models/locales.js";
import { Op } from 'sequelize'

export class GestorLocales {

    async todosLosLocalesDeArg() {
        return await Local.findAll({
            where: { country: 'AR' },
        })
    };

    async localesDelInteriorDeArg() {
        return await Local.findAll({
            where: {
                [Op.and]: [
                    { country: 'AR' },
                    { [Op.not]: { province: ['C', 'B'] } }
                ]
                ,
            }
        },
        )
    }
}
