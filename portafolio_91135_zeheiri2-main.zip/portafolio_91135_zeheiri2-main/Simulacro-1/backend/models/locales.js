// ESTE LO AGREGO YO

import { Model, DataTypes } from "sequelize";
import sequelize from "../data/db.js";

export const Local = sequelize.define(
    "STARBUCKS_DIRECTORY", 
    {
        numero: { 
            type: DataTypes.TEXT, 
            primaryKey: true,
            field: "STORE_NUMBER"
        },
        nombre: { 
            type: DataTypes.STRING,
            field: "STORE_NAME"
        },
        direccion: { 
            type: DataTypes.TEXT,
            field: "STREET_ADDRESS" 
        },
        ciudad: { 
            type: DataTypes.TEXT,
            field: "CITY" 
        },
        provincia: { 
            type: DataTypes.TEXT,
            field: "PROVINCE" 
        },
        pais: { 
            type: DataTypes.TEXT,
            field: "COUNTRY" 
        },
        codPostal: { 
            type: DataTypes.TEXT,
            field: "POSTCODE" 
        },
        longitud: { 
            type: DataTypes.REAL,
            field: "LONGITUDE" 
        },
        latitud: { 
            type: DataTypes.REAL,
            field: "LATITUDE" 
        },
    },
    {
        sequelize,
        tableName: "STARBUCKS_DIRECTORY",
        timestamps: false
    }
);


Local.prototype.toString = function () {
    return `${this.numero} 
            ${this.nombre}
            ${this.direccion} 
            ${this.ciudad} 
            ${this.provincia} 
            ${this.pais} 
            ${this.codPostal} 
            ${this.longitud} 
            ${this.latitud}`;
};