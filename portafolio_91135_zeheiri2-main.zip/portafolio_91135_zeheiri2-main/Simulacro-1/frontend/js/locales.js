const API_URL = "http://localhost:3001"

const obtenerLocales = async () => {
    const res = await fetch(`${API_URL}/locales`);
    const localesArg = await res.json()
    return localesArg
};


const obtenerLocalesInterior = async () => {
    const res = await fetch(`${API_URL}/locales/interior`);
    const localesInteriorArg = await res.json()
    return localesInteriorArg
};


const mostrarLocales = (locales) => {
    const tableBody = document.getElementById('datos');
    if (tableBody) {
        tableBody.innerHTML = ``;
        locales.forEach(local => {
            let contenido = `
                <tr>
                <th scope="row">${local.numero}</th>
                <td>${local.nombre}</td>
                <td>${local.direccion}</td>
                <td>${local.ciudad}</td>
                <td>${local.latitud}</td>
                <td>${local.longitud}</td>
                </tr>
            `;
            tableBody.innerHTML += contenido
        });
    }
};


const btnSoloInterior = document.getElementById('btnSoloInterior');
console.log('BOTON: ' + btnSoloInterior);
if (btnSoloInterior) {
    btnSoloInterior.addEventListener('click', async () => { 
        const localesInterior = await obtenerLocalesInterior();
        mostrarLocales(localesInterior)
     });
}



document.addEventListener('DOMContentLoaded', async () => {
    const locales = await obtenerLocales();
    mostrarLocales(locales);
});