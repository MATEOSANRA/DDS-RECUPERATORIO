// CLASE DEL VIERNES 05/04/24

/* Desarrollar un programa que llene un arreglo con 100 numeros aleatorios y calcular:
1. Promedio
2. Mayor
3. Menor
4. Cantidad de mayores a 0,5 */


let arreglo = [];
let suma = 0;
let cantMayor05 = 0;

for (let i = 0; i < 100; i++) {
    numero = Math.random()
    
    arreglo.push(numero);
    suma = suma + numero;
    
};

for (let j = 0; j < arreglo.length; j++) {
    if (j === 0) {
        let menor = numero;
        let mayor = numero;
        
    } else {
        if (numero > mayor) {
            mayor = numero
        }
    
        if (numero < menor) {
            menor = numero
        };
    }
    
    if (numero > 0.5) {
        cantMayor05++
    }

    
}

console.log(arreglo);

let promedio = suma / 100;



/*let numAleatorios = [];
let cantDeElementos = 100;
let suma = 0;
let promedio;
let may, men;
let cantMayores = 0;

for (let i = 0; i < cantDeElementos; i++) {
    numAleatorios.push(Math.random());   
}

men = numAleatorios[0];
may = numAleatorios[0];

for (let i = 0; i < cantDeElementos; i++) {
    suma += numAleatorios[i];  
    if (men > numAleatorios[i]) {
        men = numAleatorios[i];
    }
    if (may < numAleatorios[i]) {
        may = numAleatorios[i];
    }
    if (numAleatorios[i] > 0.5) {
        cantMayores++;
    }
}

promedio = suma / cantDeElementos;
*/



console.log('Promedio: ', promedio);
console.log('Mayor: ', mayor);
console.log('Menor: ', menor);
console.log('Cantidad de mayores a 0.5: ', cantMayor05);