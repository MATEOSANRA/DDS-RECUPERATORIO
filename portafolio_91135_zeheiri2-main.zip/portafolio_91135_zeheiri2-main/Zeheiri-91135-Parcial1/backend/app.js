const express = require('express');
const { Sequelize, DataTypes } = require('sequelize');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const sequelize = new Sequelize({
    dialect: 'sqlite',
    storage: './datos/hoteles.sqlite'
});

// Definir el modelo
const Hoteles = sequelize.define('Hoteles', {
    id: {type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true},
    nombre: {type: DataTypes.STRING},
    ciudad: {type: DataTypes.STRING},
    plazas: { type: DataTypes.INTEGER}
});


async function inicializarBaseDeDatos() {
    await sequelize.sync({ force: true });
    await Hoteles.truncate();
    await Hoteles.bulkCreate([
        {nombre:"Yuna Porte-Maillot", ciudad:"Paris", plazas:"215"},
        {nombre:"Villa Fontaine Haneda", ciudad:"Tokio", plazas:"320"},
        {nombre:"Ours Inn Hankyu ", ciudad:"Tokio", plazas:"120"},
        {nombre:"Hotel Des Deux Continents", ciudad:"Paris", plazas:"180"},
        {nombre:"JR Shinjuku Station", ciudad:"Tokio", plazas:"426"},
        {nombre:"Villa Royale Montsouris", ciudad:"Paris", plazas:"112"},
        {nombre:"Native Kings Wardrobe", ciudad:"Londres", plazas:"146"},
        {nombre:"Hôtel Saint-Pétersbourg Opéra & Spa", ciudad:"Paris", plazas:"230"},
        {nombre:"Hotel & Resort Ryogoku Eki", ciudad:"Tokio", plazas:"142"},
        {nombre:"Hotel Tokyo Shiodome", ciudad:"Tokio", plazas:"912"},
        {nombre:"Hostal Santa Cruz", ciudad:"Madrid", plazas:"321"},
        {nombre:"Sonder Camden Road", ciudad:"Londres", plazas:"118"},
        {nombre:"Sonder Edgware Road", ciudad:"Londres", plazas:"230"},
        {nombre:"Gem Langham Court Hotel", ciudad:"Londres", plazas:"235"},
        {nombre:"Commodore Hotel", ciudad:"Londres", plazas:"224"},
        {nombre:"Fuencarral Adeco", ciudad:"Madrid", plazas:"112"},
        {nombre:"Castilla Vieja", ciudad:"Madrid", plazas:"98"},
        {nombre:"Soho Boutique Opera", ciudad:"Madrid", plazas:"144"},
        {nombre:"Gem Fitzrovia Hotel", ciudad:"Londres", plazas:"98"},
        {nombre:"Hotel Gracery Shinjuku ", ciudad:"Tokio", plazas:"225"},
        {nombre:"Villa Royale Montsouris", ciudad:"Paris", plazas:"118"},
        {nombre:"Mayerling Hotel", ciudad:"Madrid", plazas:"241"},
        {nombre:"Puerta del Sol Hotel", ciudad:"Madrid", plazas:"123"},
    
    ]);
}


app.get('/api/hoteles', async (req, res) => {
    const todosLosHoteles = await Hoteles.findAll();
    res.json(todosLosHoteles);
})

app.get('/api/hoteles/:ciudad', async (req, res) => {
    const paramCiudad = req.params.ciudad;
    let filtro = { where: { ciudad: paramCiudad}};
    if( paramCiudad === 'Todas') {
        filtro = {}
    };
    const hotelesPorCiudad = await Hoteles.findAll(filtro);
    res.json(hotelesPorCiudad);
})


inicializarBaseDeDatos().then(() => {
    app.listen(3000, () => console.log('Servidor en http://localhost:3000'));
});
