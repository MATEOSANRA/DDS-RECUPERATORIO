const URL_API = "http://localhost:3000/api/hoteles";

const mostrarHotelesPorCiudad = async () => {

  const contenedorTabla = document.getElementById("divHoteles");

  if (contenedorTabla) {
    
    const opcCiudad = document.getElementById("ddlCiudad");
    const ciudad = opcCiudad.value;

    const res = await fetch(`${URL_API}/${ciudad}`);
    const hoteles = await res.json();

    let tabla = `
    <table class="table">
        <thead>
            <tr>
                <th class="bg-info-subtle">Id</th>
                <th class="bg-info-subtle">Nombre</th>
                <th class="bg-info-subtle">Ciudad</th>
                <th class="bg-info-subtle">Plazas</th>
            </tr>
        </thead>
        <tbody>`;

    hoteles.forEach(hotel => {
        tabla += `
            <tr>
                <td>${hotel.id}</td>
                <td>${hotel.nombre}</td>
                <td>${hotel.ciudad}</td>
                <td>${hotel.plazas}</td>
            </tr>
        `
    });

    tabla += `
        </tbody>
    </table>
    `;

    contenedorTabla.innerHTML = tabla;
  }
};


const btnCargarHoteles = document.getElementById("btnCargarHoteles");

if (btnCargarHoteles) {
  btnCargarHoteles.addEventListener("click", (req, res) => {
    mostrarHotelesPorCiudad();
  });
}
