const Sequelize = require('sequelize'); 

const crearDatos = require('./init');
const HotelModel = require('../models/hotel.model');
const CategoriaModel = require('../models')

const sequelize = new Sequelize({
    dialect: 'sqlite',
    storage: './datos/hoteles.db'
});

const Hoteles = HotelModel(sequelize);
const Categorias = CategoriaModel(sequelize);

// Creamos la relacion entre la tabla hotel y categoria 
Hoteles.belongsTo(Categorias);
Categorias.hasMany(Hoteles);

const iniciar = async(reset = false) => {
    try {
        await sequelize.sync({force: reset});
        console.log(`Base de datos inicializada`);
        if (reset) {
            await crearDatos(Hoteles);
        }
    }
    catch (err){
        console.log(`Error en la base de datos: ${err.message}`);
    }
}



const db = {iniciar, Hoteles}
module.exports = db;


