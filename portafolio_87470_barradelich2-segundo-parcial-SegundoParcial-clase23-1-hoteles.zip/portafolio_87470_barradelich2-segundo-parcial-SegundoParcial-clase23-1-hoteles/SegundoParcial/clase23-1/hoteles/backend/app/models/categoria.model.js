const {DataTypes} = require('sequelize');

const CategoriaModel = (sequelize) => {

    return sequelize.define(
      "categorias", {
        id: { 
            type: DataTypes.INTEGER, 
            autoIncrement: true, 
            primaryKey: true },
        nombre: { 
            type: DataTypes.STRING 
        },
        ciudad: { 
            type: DataTypes.STRING 
        },
        plazas: { 
            type: DataTypes.INTEGER 
        },
        }, 
        {
            timestamps: false
        }
    );
  
};