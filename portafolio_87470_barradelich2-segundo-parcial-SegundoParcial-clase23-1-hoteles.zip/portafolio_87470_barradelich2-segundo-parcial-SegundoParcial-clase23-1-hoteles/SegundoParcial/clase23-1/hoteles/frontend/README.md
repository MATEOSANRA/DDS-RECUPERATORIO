# CRUD Hoteles

## Backend

Iniciá el backend

#### `cd backend`

y luego 

#### `node server`

o 
#### `npx nodemon server`

## Frontend

#### `cd frontend`

Inicialo con:

#### `npm start`

El proyecto corre en: [http://localhost:3000](http://localhost:3000)
