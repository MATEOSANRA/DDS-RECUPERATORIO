import { useState, useEffect } from "react";
import {Link} from 'react-router-dom';
import axios from "axios";

function Hoteles() {
  const [hoteles, setHoteles] = useState(null);

  useEffect(() => {
    getHoteles();
  }, []);

  const getHoteles = async () => {
    const hotelesDatos = await axios.get("http://localhost:3001/api/hoteles");
    setHoteles(hotelesDatos.data);
  };

  const deleteHotel = async (id) => {
    if (window.confirm("¿Desea borrar este hotel?")) {
      await axios.delete(`http://localhost:3001/api/hoteles/${id}`);
      getHoteles();
    }
  };

  return (
    <div className="text-start">
      <h1 className="text-center">Hoteles</h1>
      <table className="table mt-5">
        <thead className="table-dark">
          <tr>
            <th>Nombre</th>
            <th>Ciudad</th>
            <th>Plazas</th>
            <th><Link className="btn text-white" to='/hotel/0'><i className="bi bi-plus-circle"></i> Nuevo hotel</Link></th>
          </tr>
        </thead>
        <tbody>
          {hoteles &&
            hoteles.map((h) => {
              return (
                <tr key={h.id}>
                  <td>{h.nombre}</td>
                  <td>{h.ciudad}</td>
                  <td>{h.plazas}</td>
                  <td>
                    <button
                      className="btn btn-default"
                      onClick={() => deleteHotel(h.id)}
                    >
                      <i className="bi bi-trash3 text-danger"></i>
                    </button>
                    <Link className="btn btn-default" to={`/hotel/${h.id}`} >
                        <i className="bi bi-pencil text-primary"></i>
                    </Link>
                  </td>
                </tr>
              );
            })}
        </tbody>
      </table>
    </div>
  );
}

export default Hoteles;
