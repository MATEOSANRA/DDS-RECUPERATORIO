function Inicio(){
    return(
        <>
        <h1>Administración de Hoteles</h1>
        <h2>CRUD de Hoteles</h2>
        </>
    )
}

export default Inicio;