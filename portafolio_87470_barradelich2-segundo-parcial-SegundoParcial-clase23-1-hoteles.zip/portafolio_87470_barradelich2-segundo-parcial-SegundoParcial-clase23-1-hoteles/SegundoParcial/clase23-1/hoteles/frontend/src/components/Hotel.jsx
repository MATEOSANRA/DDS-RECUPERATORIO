import {useState, useEffect} from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {useForm} from 'react-hook-form';
import axios from 'axios';

function Hotel(){
    const {id} = useParams();
    const navigate = useNavigate();
    const {register, handleSubmit, formState: {errors}} = useForm();
    const [hotel, setHotel] = useState({});

    useEffect(() => {getHotel(id)}, []);
    
    const getHotel = async (id) => {
        if (id > 0) {
            const hotelDatos = await axios.get(`http://localhost:3001/api/hoteles/${id}`);
            setHotel(hotelDatos.data);
        }
    };

    const volver = () => {
        navigate('/hoteles');
    }

    const cancelar = () =>{
        volver();
    }

    const onSubmit = async(data) => {
        if (id > 0) {
            await axios.put(`http://localhost:3001/api/hoteles/${id}`, data)
        }
        else {
            await axios.post('http://localhost:3001/api/hoteles', data);
        }
        volver();
    }


    return(
      <form onSubmit={handleSubmit(onSubmit)} className='mt-5'>
      <h1 className='mb-5'>Hotel {id > 0? hotel.nombre : 'nuevo'}</h1>
        <div className="row mt-3">
            <div className="col-4 text-end">
                <label htmlFor="nombre">Nombre:</label>
            </div>
            <div className="col-8 text-start">
                <input type="text" 
                    className='form-control'
                    defaultValue = {hotel?.nombre}
                    {...register('nombre', {required: 'El nombre es requerido'})}
                />
                {errors.nombre && <span className='text-danger'>{errors.nombre.message}</span>}
            </div>
        </div>
        <div className="row mt-3">
            <div className="col-4 text-end">
                <label htmlFor="ciudad">Ciudad:</label>
            </div>
            <div className="col-8 text-start">
                <input type="text" 
                    className='form-control'
                    defaultValue = {hotel?.ciudad}
                    {...register('ciudad', {required: 'La ciudad es requerida'})}
                />
                {errors.ciudad && <span className='text-danger'>{errors.ciudad.message}</span>}
            </div>
        </div>
        <div className="row mt-3">
            <div className="col-4 text-end">
                <label htmlFor="plazas">Plazas:</label>
            </div>
            <div className="col-8 text-start">
                <input type="text" 
                    className='form-control'
                    defaultValue = {hotel?.plazas}
                    {...register('plazas', {required: 'La candidad nombre es requerido', 
                        validate: (value) => {return !isNaN(value) || 'Debe ser numérico'} })}
                    />
                    {errors.plazas && <span className='text-danger'>{errors.plazas.message}</span>}
            </div>
            
        </div>
        <div className="mt-5 mb-5">
            <button className='btn btn-danger ms-2' onClick={cancelar}>Cancelar</button>
            <input className="btn btn-success ms-2" type="submit" value={id > 0? 'Actualizar' : 'Crear'} />
        </div>
      </form>
    )
}

export default Hotel;